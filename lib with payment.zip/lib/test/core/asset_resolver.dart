// Maps the original prototype asset paths to the embedded (base64) images,
// so the data layer can keep referencing 'assets/products/PW90.png' verbatim.

import 'package:flutter/widgets.dart';
import 'embedded_images.dart';

ImageProvider pwtImage(String assetPath) {
  switch (assetPath) {
    case 'assets/pwt-logo.png':
      return EmbeddedImages.pwt_logoImage;
    case 'assets/products/PW90.png':
      return EmbeddedImages.products_PW90Image;
    case 'assets/products/PW50.png':
      return EmbeddedImages.products_PW50Image;
    case 'assets/products/PW90CT.png':
      return EmbeddedImages.products_PW90CTImage;
    case 'assets/products/S4.png':
      return EmbeddedImages.products_S4Image;
    case 'assets/products/S18C.png':
      return EmbeddedImages.products_S18CImage;
    default:
      // Fallback to the logo so a typo never crashes a build.
      return EmbeddedImages.pwt_logoImage;
  }
}
