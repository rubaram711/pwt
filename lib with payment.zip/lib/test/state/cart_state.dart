// Cart state — ports CartProvider from proto/shared.jsx. One instance is
// provided per shell (individual / business have independent carts).

import 'package:flutter/foundation.dart';
import '../models/models.dart';

class CartState extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);
  int get totalQty => _items.fold(0, (sum, i) => sum + i.qty);
  bool get isEmpty => _items.isEmpty;

  int _indexOf(String productId, Plan plan) =>
      _items.indexWhere((i) => i.productId == productId && i.plan == plan);

  void addItem(String productId, {Plan plan = Plan.rent, int qty = 1}) {
    final idx = _indexOf(productId, plan);
    if (idx >= 0) {
      _items[idx] = _items[idx].copyWith(qty: _items[idx].qty + qty);
    } else {
      _items.add(CartItem(productId: productId, plan: plan, qty: qty));
    }
    notifyListeners();
  }

  void setPlan(String productId, Plan oldPlan, Plan newPlan) {
    final idx = _indexOf(productId, oldPlan);
    if (idx < 0) return;
    // If a line with the new plan already exists, merge quantities.
    final existing = _indexOf(productId, newPlan);
    if (existing >= 0 && existing != idx) {
      _items[existing] = _items[existing].copyWith(qty: _items[existing].qty + _items[idx].qty);
      _items.removeAt(idx);
    } else {
      _items[idx] = _items[idx].copyWith(plan: newPlan);
    }
    notifyListeners();
  }

  void setQty(String productId, Plan plan, int qty) {
    final idx = _indexOf(productId, plan);
    if (idx < 0) return;
    final clamped = qty < 0 ? 0 : qty;
    if (clamped == 0) {
      _items.removeAt(idx);
    } else {
      _items[idx] = _items[idx].copyWith(qty: clamped);
    }
    notifyListeners();
  }

  void removeItem(String productId, Plan plan) {
    _items.removeWhere((i) => i.productId == productId && i.plan == plan);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
