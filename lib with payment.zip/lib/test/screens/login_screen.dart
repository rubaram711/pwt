// Login — account-mode tabs + email/password. Ported from proto/login.jsx.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../widgets/form_field.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLogin, required this.onBack});
  final ValueChanged<AccountKind> onLogin;
  final VoidCallback onBack;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  AccountKind _mode = AccountKind.individual;
  final _email = TextEditingController(text: 'ahmed.m@gmail.com');
  final _password = TextEditingController(text: '••••••••••');
  bool _showPw = false;

  void _setMode(AccountKind m) {
    setState(() {
      _mode = m;
      _email.text = m == AccountKind.business ? 'layla.h@falcontrading.ae' : 'ahmed.m@gmail.com';
    });
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final isAr = app.isArabic;

    return Scaffold(
      backgroundColor: PwtColors.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -1),
                  radius: 1.0,
                  colors: [PwtColors.brand.withValues(alpha: 0.12), PwtColors.brand.withValues(alpha: 0)],
                  stops: const [0, 0.7],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Stack(
              children: [
                Positioned(
                  top: 8,
                  left: 16,
                  child: Container(
                    decoration: BoxDecoration(
                      color: PwtColors.surface,
                      shape: BoxShape.circle,
                      border: Border.all(color: PwtColors.hairline),
                    ),
                    child: IconButton(
                      onPressed: widget.onBack,
                      icon: const Icon(PwtIcons.back, size: 22),
                      color: PwtColors.textPri,
                    ),
                  ),
                ),
                SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(28, 64, 28, 30),
                  child: Column(
                    children: [
                      Image(image: pwtImage('assets/pwt-logo.png'), width: 68, height: 68),
                      const SizedBox(height: 14),
                      Text(s['welcomeBack']!, style: PwtType.headline(arabic: isAr).copyWith(fontSize: 26)),
                      const SizedBox(height: 6),
                      Text(s['signInToContinue']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec, arabic: isAr).copyWith(fontSize: 14)),
                      const SizedBox(height: 28),
                      ModeTabs(
                        mode: _mode,
                        onChanged: _setMode,
                        individualLabel: s['individual']!,
                        businessLabel: s['business']!,
                      ),
                      const SizedBox(height: 22),
                      PwtField(
                        label: s['email']!,
                        controller: _email,
                        leading: PwtIcons.message,
                        forceLtr: true,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 12),
                      PwtField(
                        label: isAr ? 'كلمة المرور' : 'Password',
                        controller: _password,
                        leading: PwtIcons.shield,
                        obscure: !_showPw,
                        forceLtr: true,
                        trailing: GestureDetector(
                          onTap: () => setState(() => _showPw = !_showPw),
                          child: Icon(_showPw ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 18, color: PwtColors.textTer),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Align(
                        alignment: isAr ? Alignment.centerLeft : Alignment.centerRight,
                        child: Text(
                          isAr ? 'نسيت كلمة المرور؟' : 'Forgot password?',
                          style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(height: 22),
                      PwtButton(label: s['signIn']!, full: true, onPressed: () => widget.onLogin(_mode)),
                      const SizedBox(height: 22),
                      Text.rich(
                        TextSpan(
                          style: PwtType.label(color: PwtColors.textSec),
                          children: [
                            TextSpan(text: isAr ? 'ليس لديك حساب؟ ' : "Don't have an account? "),
                            TextSpan(text: isAr ? 'تواصل معنا' : 'Contact us', style: const TextStyle(color: PwtColors.brand, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
