// Sign-up (phone → OTP → details) + onboarding carousel. Ported from
// proto/signup.jsx.

import 'dart:async';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../widgets/form_field.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key, required this.onBack, required this.onComplete});
  final VoidCallback onBack;
  final ValueChanged<AccountKind> onComplete;

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  static const _steps = ['phone', 'otp', 'details'];
  String _step = 'phone';
  AccountKind _mode = AccountKind.individual;
  final _phone = TextEditingController();

  // details
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _company = TextEditingController();
  final _license = TextEditingController();
  final _bizEmail = TextEditingController();
  final _address = TextEditingController();
  bool _agreed = true;

  @override
  void dispose() {
    for (final c in [_phone, _name, _email, _password, _company, _license, _bizEmail, _address]) {
      c.dispose();
    }
    super.dispose();
  }

  void _back() {
    if (_step == 'otp') {
      setState(() => _step = 'phone');
    } else if (_step == 'details') {
      setState(() => _step = 'otp');
    } else {
      widget.onBack();
    }
  }

  bool get _detailsValid => _mode == AccountKind.individual
      ? (_name.text.isNotEmpty && _email.text.isNotEmpty && _password.text.isNotEmpty && _agreed)
      : (_company.text.isNotEmpty && _license.text.isNotEmpty && _bizEmail.text.isNotEmpty && _address.text.isNotEmpty && _agreed);

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final prettyPhone = '+971 ${_phone.text}';
    final activeIndex = _steps.indexOf(_step);

    return Scaffold(
      backgroundColor: PwtColors.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -1),
                  radius: 1.0,
                  colors: [PwtColors.brand.withValues(alpha: 0.12), PwtColors.brand.withValues(alpha: 0)],
                  stops: const [0, 0.7],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // top bar
                SizedBox(
                  height: 56,
                  child: Row(
                    children: [
                      IconButton(onPressed: _back, icon: const Icon(PwtIcons.back, size: 24), color: PwtColors.textPri),
                      Expanded(child: Text(s['signUp']!, textAlign: TextAlign.center, style: PwtType.subtitle().copyWith(fontSize: 16))),
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
                // progress
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 4),
                  child: Row(
                    children: [
                      for (int i = 0; i < _steps.length; i++)
                        Expanded(
                          child: Container(
                            height: 3.5,
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(color: i <= activeIndex ? PwtColors.brand : PwtColors.hairline2, borderRadius: BorderRadius.circular(999)),
                          ),
                        ),
                    ],
                  ),
                ),
                Expanded(child: _stepBody(s, prettyPhone)),
                // sticky CTA
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 14, 24, 14),
                  child: _cta(s),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _cta(Map<String, String> s) {
    switch (_step) {
      case 'phone':
        return PwtButton(
          label: s['sendCode']!,
          full: true,
          trailing: PwtIcons.arrow,
          disabled: _phone.text.replaceAll(RegExp(r'\D'), '').length < 8,
          onPressed: () => setState(() => _step = 'otp'),
        );
      case 'otp':
        return PwtButton(label: s['verify']!, full: true, trailing: PwtIcons.arrow, onPressed: () => setState(() => _step = 'details'));
      default:
        return PwtButton(label: s['signUp']!, full: true, trailing: PwtIcons.arrow, disabled: !_detailsValid, onPressed: () => widget.onComplete(_mode));
    }
  }

  Widget _stepBody(Map<String, String> s, String prettyPhone) {
    switch (_step) {
      case 'phone':
        return ListView(
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 24),
          children: [
            Text(s['enterMobile']!, style: PwtType.headline().copyWith(fontSize: 26)),
            const SizedBox(height: 6),
            Text(s['enterMobileSub']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.5)),
            const SizedBox(height: 18),
            ModeTabs(mode: _mode, onChanged: (m) => setState(() => _mode = m), individualLabel: s['individual']!, businessLabel: s['business']!),
            const SizedBox(height: 22),
            PwtField(
              label: s['mobileNumber']!,
              controller: _phone,
              leading: PwtIcons.phone,
              prefix: '+971',
              forceLtr: true,
              keyboardType: TextInputType.phone,
              onChanged: (_) => setState(() {}),
            ),
          ],
        );
      case 'otp':
        return ListView(
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 24),
          children: [
            Text(s['verifyNumber']!, style: PwtType.headline().copyWith(fontSize: 26)),
            const SizedBox(height: 6),
            Text.rich(
              TextSpan(
                style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.5),
                children: [
                  TextSpan(text: '${s['otpSentTo']} '),
                  TextSpan(text: prettyPhone, style: const TextStyle(color: PwtColors.textPri, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            const SizedBox(height: 4),
            GestureDetector(
              onTap: () => setState(() => _step = 'phone'),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(s['changeNumber']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 13)),
              ),
            ),
            const SizedBox(height: 18),
            OtpInput(onComplete: () => setState(() => _step = 'details')),
            const OtpResend(),
          ],
        );
      default:
        return ListView(
          padding: const EdgeInsets.fromLTRB(24, 14, 24, 24),
          children: [
            Text(s['finishSignup']!, style: PwtType.headline().copyWith(fontSize: 26)),
            const SizedBox(height: 6),
            Text(s['finishSignupSub']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.5)),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(color: PwtColors.brandTint, border: Border.all(color: PwtColors.brandBorder), borderRadius: BorderRadius.circular(PwtRadius.md)),
              child: Row(
                children: [
                  const Icon(PwtIcons.check, size: 16, color: PwtColors.success),
                  const SizedBox(width: 10),
                  Directionality(textDirection: TextDirection.ltr, child: Text(prettyPhone, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13.5))),
                  const Spacer(),
                  GestureDetector(onTap: () => setState(() => _step = 'phone'), child: Text(s['changeNumber']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5))),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (_mode == AccountKind.individual) ...[
              PwtField(label: s['fullName']!, controller: _name, leading: PwtIcons.user, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              PwtField(label: s['email']!, controller: _email, leading: PwtIcons.message, forceLtr: true, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              PwtField(label: s['password']!, controller: _password, leading: PwtIcons.shield, obscure: true, onChanged: (_) => setState(() {})),
            ] else ...[
              PwtField(label: s['companyName']!, controller: _company, leading: PwtIcons.building, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              PwtField(label: s['licenseNumber']!, controller: _license, leading: PwtIcons.briefcase, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              PwtField(label: s['email']!, controller: _bizEmail, leading: PwtIcons.message, forceLtr: true, onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              PwtField(label: s['address']!, controller: _address, leading: PwtIcons.pin, onChanged: (_) => setState(() {})),
            ],
            const SizedBox(height: 18),
            GestureDetector(
              onTap: () => setState(() => _agreed = !_agreed),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    margin: const EdgeInsets.only(top: 1),
                    decoration: BoxDecoration(
                      color: _agreed ? PwtColors.brand : PwtColors.surface,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: _agreed ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
                    ),
                    child: _agreed ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(s['terms']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 12.5, height: 1.45))),
                ],
              ),
            ),
          ],
        );
    }
  }
}

// ─── 6-digit OTP ───
class OtpInput extends StatefulWidget {
  const OtpInput({super.key, required this.onComplete});
  final VoidCallback onComplete;

  @override
  State<OtpInput> createState() => _OtpInputState();
}

class _OtpInputState extends State<OtpInput> {
  static const _len = 6;
  final _controllers = List.generate(_len, (_) => TextEditingController());
  final _focusNodes = List.generate(_len, (_) => FocusNode());

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    for (final f in _focusNodes) {
      f.dispose();
    }
    super.dispose();
  }

  void _onChanged(int i, String v) {
    if (v.isNotEmpty && i < _len - 1) {
      _focusNodes[i + 1].requestFocus();
    }
    if (_controllers.every((c) => c.text.isNotEmpty)) {
      Future.delayed(const Duration(milliseconds: 180), widget.onComplete);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (int i = 0; i < _len; i++)
            SizedBox(
              width: 48,
              height: 58,
              child: TextField(
                controller: _controllers[i],
                focusNode: _focusNodes[i],
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 1,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: PwtType.title().copyWith(fontSize: 24, fontWeight: FontWeight.w700),
                onChanged: (v) => _onChanged(i, v),
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: PwtColors.surface,
                  contentPadding: EdgeInsets.zero,
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _controllers[i].text.isNotEmpty ? PwtColors.brand : PwtColors.hairline2, width: 1.5)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: PwtColors.brand, width: 1.5)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class OtpResend extends StatefulWidget {
  const OtpResend({super.key});
  @override
  State<OtpResend> createState() => _OtpResendState();
}

class _OtpResendState extends State<OtpResend> {
  int _secs = 30;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    _secs = 30;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_secs <= 0) {
        t.cancel();
      } else {
        setState(() => _secs--);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: Center(
        child: Text.rich(
          TextSpan(
            style: PwtType.label(color: PwtColors.textSec),
            children: [
              TextSpan(text: '${s['didntGetCode']} '),
              if (_secs > 0)
                TextSpan(text: '${s['resendIn']} ${_secs}s', style: const TextStyle(color: PwtColors.textTer, fontWeight: FontWeight.w600))
              else
                TextSpan(
                  text: s['resendCode'],
                  style: const TextStyle(color: PwtColors.brand, fontWeight: FontWeight.w700),
                  recognizer: (TapGestureRecognizer()..onTap = () => setState(_start)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Onboarding carousel ───
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.mode, required this.onDone});
  final AccountKind mode;
  final VoidCallback onDone;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _idx = 0;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final cards = widget.mode == AccountKind.business
        ? [
            (id: 'PW90', title: s['onbBrowseTitle']!, sub: s['onbBrowseSub']!),
            (id: 'S4', title: s['onbBizQuoteTitle']!, sub: s['onbBizQuoteSub']!),
            (id: 'PW50', title: s['onbBizFleetTitle']!, sub: s['onbBizFleetSub']!),
          ]
        : [
            (id: 'PW90', title: s['onbBrowseTitle']!, sub: s['onbBrowseSub']!),
            (id: 'S4', title: s['onbRentBuyTitle']!, sub: s['onbRentBuySub']!),
            (id: 'PW90CT', title: s['onbServiceTitle']!, sub: s['onbServiceSub']!),
          ];
    final card = cards[_idx];
    final product = MockData.productById(card.id)!;
    final isLast = _idx == cards.length - 1;

    return Scaffold(
      backgroundColor: PwtColors.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -1),
                  radius: 1.0,
                  colors: [PwtColors.brand.withValues(alpha: 0.16), PwtColors.brand.withValues(alpha: 0)],
                  stops: const [0, 0.7],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 10, 22, 0),
                  child: Row(
                    children: [
                      Image(image: pwtImage('assets/pwt-logo.png'), width: 26, height: 26),
                      const SizedBox(width: 8),
                      Text('PWT', style: PwtType.subtitle().copyWith(fontSize: 15)),
                      const Spacer(),
                      GestureDetector(onTap: widget.onDone, child: Text(s['skip']!, style: PwtType.label(color: PwtColors.textSec, weight: FontWeight.w600).copyWith(fontSize: 13.5))),
                    ],
                  ),
                ),
                Expanded(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        width: 360,
                        height: 360,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [product.tint.withValues(alpha: 0.19), product.tint.withValues(alpha: 0)], stops: const [0, 0.65]),
                        ),
                      ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 480),
                        transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: ScaleTransition(scale: Tween(begin: 0.94, end: 1.0).animate(anim), child: child)),
                        child: Image(key: ValueKey(card.id), image: pwtImage(product.img), height: 300, fit: BoxFit.contain),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(28, 0, 28, 28),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 130,
                        child: Column(
                          children: [
                            Text(card.title, textAlign: TextAlign.center, style: PwtType.headline(arabic: app.isArabic).copyWith(fontSize: 24, height: 1.2)),
                            const SizedBox(height: 10),
                            Text(card.sub, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec, arabic: app.isArabic).copyWith(fontSize: 13.5, height: 1.55)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          for (int i = 0; i < cards.length; i++)
                            GestureDetector(
                              onTap: () => setState(() => _idx = i),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 240),
                                margin: const EdgeInsets.symmetric(horizontal: 3),
                                width: i == _idx ? 22 : 6,
                                height: 6,
                                decoration: BoxDecoration(color: i == _idx ? PwtColors.brand : PwtColors.hairline2, borderRadius: BorderRadius.circular(999)),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      PwtButton(
                        label: isLast ? s['done']! : s['next']!,
                        full: true,
                        trailing: isLast ? null : PwtIcons.arrow,
                        onPressed: () => isLast ? widget.onDone() : setState(() => _idx++),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
