// Individual user shell: Devices (hero slider home) + Shop (catalogue).
// Ported from proto/individual.jsx. Overlays (PDP, cart, maintenance, account)
// are pushed as routes — see screens/overlays.dart and the *_screens files.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../widgets/empty_states.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/chrome.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import 'account_screens.dart';
import 'cart_screen.dart';
import 'overlays.dart';
import 'product_detail_screen.dart';

class IndividualShell extends StatefulWidget {
  const IndividualShell({super.key, required this.onLogout, this.isNew = false, this.forceEmpty = false});
  final VoidCallback onLogout;
  final bool isNew;

  /// Dev switch: render the empty state even when mock devices exist.
  final bool forceEmpty;

  @override
  State<IndividualShell> createState() => _IndividualShellState();
}

class _IndividualShellState extends State<IndividualShell> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String _tab = 'devices';
  final List<Device> _ordered = [];

  AppUser get _user => MockData.userIndividual;

  List<Device> get _devices => [...MockData.individualDevices, ..._ordered];

  void _onDrawerSelect(String key) {
    Navigator.of(context).pop(); // close drawer
    switch (key) {
      case 'logout':
        widget.onLogout();
      case 'profile':
        _push(ProfileScreen(user: _user, role: AccountKind.individual));
      case 'settings':
        _push(const SettingsScreen());
      case 'invoices':
        _push(InvoicesScreen(invoices: MockData.individualInvoices));
    }
  }

  void _push(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final showEmpty = widget.forceEmpty || (widget.isNew && _devices.isEmpty);

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: PwtColors.bg,
      endDrawer: ProfileDrawer(user: _user, onSelect: _onDrawerSelect),
      floatingActionButton: FloatingCart(onTap: () => _push(const CartScreen(role: AccountKind.individual))),
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _tab == 'devices' ? 0 : 1,
          children: [
            _tab == 'devices' && showEmpty
                ? _DevicesEmpty(user: _user, onProfile: () => _scaffoldKey.currentState?.openEndDrawer(), onBrowse: () => setState(() => _tab = 'products'))
                : IndividualHome(
                    devices: _devices,
                    user: _user,
                    onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
                    onMaintenance: (d) => _push(MaintenanceSheet(device: d)),
                    onTrackOrder: () => _push(OrdersScreen(orders: MockData.individualOrders, role: AccountKind.individual)),
                  ),
            ProductsScreen(
              user: _user,
              role: AccountKind.individual,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onOpenProduct: (p) => _push(ProductDetailScreen(product: p, role: AccountKind.individual)),
            ),
          ],
        ),
      ),
      bottomNavigationBar: PwtBottomNav(
        active: _tab,
        onChanged: (k) => setState(() => _tab = k),
        items: [
          PwtNavItem(key: 'devices', label: s['devices']!, icon: PwtIcons.drop),
          PwtNavItem(key: 'products', label: s['shop']!, icon: PwtIcons.cube),
        ],
      ),
    );
  }
}

class _BrandBackdrop extends StatelessWidget {
  const _BrandBackdrop({this.opacity = 0.18, required this.child});
  final double opacity;
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -1.0),
                radius: 0.9,
                colors: [PwtColors.brand.withValues(alpha: opacity), PwtColors.brand.withValues(alpha: 0)],
                stops: const [0, 0.7],
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

// ─── Individual home: device hero slider + detail card ───
class IndividualHome extends StatefulWidget {
  const IndividualHome({
    super.key,
    required this.devices,
    required this.user,
    required this.onProfile,
    required this.onMaintenance,
    required this.onTrackOrder,
  });

  final List<Device> devices;
  final AppUser user;
  final VoidCallback onProfile;
  final ValueChanged<Device> onMaintenance;
  final VoidCallback onTrackOrder;

  @override
  State<IndividualHome> createState() => _IndividualHomeState();
}

class _IndividualHomeState extends State<IndividualHome> {
  final _controller = PageController();
  int _idx = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final device = widget.devices[_idx];

    return _BrandBackdrop(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          AppHeader(user: widget.user, onProfile: widget.onProfile),
          const SizedBox(height: 8),
          // hero slider
          SizedBox(
            height: 320,
            child: PageView.builder(
              controller: _controller,
              itemCount: widget.devices.length,
              onPageChanged: (i) => setState(() => _idx = i),
              itemBuilder: (_, i) {
                final d = widget.devices[i];
                return Column(
                  children: [
                    SizedBox(height: 264, child: ProductImage(img: d.img, size: 240, accent: d.tint)),
                    const SizedBox(height: 8),
                    Text(d.name, style: PwtType.headline().copyWith(fontSize: 28)),
                    const SizedBox(height: 6),
                    if (d.isOrdered)
                      Pill(label: s['deviceOrdered']!, color: PwtColors.warning, dot: true)
                    else
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(d.id, style: PwtType.mono(size: 12, color: PwtColors.textTer)),
                      ),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          // dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (int i = 0; i < widget.devices.length; i++)
                GestureDetector(
                  onTap: () => _controller.animateToPage(i, duration: PwtMotion.normal, curve: PwtMotion.standard),
                  child: AnimatedContainer(
                    duration: PwtMotion.normal,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _idx ? 22 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: i == _idx ? PwtColors.brand : PwtColors.hairline2,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: device.isOrdered
                ? OrderedDeviceCard(device: device, onTrackOrder: widget.onTrackOrder)
                : _DeviceCard(device: device, onMaintenance: () => widget.onMaintenance(device)),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Center(child: Text(s['swipeForMore']!, style: PwtType.caption().copyWith(fontSize: 11.5))),
          ),
          // quick actions
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 10),
                  child: Eyebrow(app.isArabic ? 'إجراءات سريعة' : 'Quick actions'),
                ),
                Row(
                  children: [
                    _QuickAction(icon: PwtIcons.orders, label: s['orders']!),
                    const SizedBox(width: 10),
                    _QuickAction(icon: PwtIcons.cube, label: s['products']!),
                    const SizedBox(width: 10),
                    _QuickAction(icon: PwtIcons.message, label: app.isArabic ? 'تواصل معنا' : 'Contact us'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _DeviceCard extends StatelessWidget {
  const _DeviceCard({required this.device, required this.onMaintenance});
  final Device device;
  final VoidCallback onMaintenance;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final isRent = device.plan == Plan.rent;

    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          // purchase strip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              color: PwtColors.surface2,
              border: Border(bottom: BorderSide(color: PwtColors.hairline)),
            ),
            child: Row(
              children: [
                Pill(label: isRent ? s['rent']! : s['buy']!, color: isRent ? PwtColors.brand : PwtColors.success),
                const SizedBox(width: 10),
                if (isRent)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      const Dirham(size: 12),
                      const SizedBox(width: 4),
                      Text('${device.rent}', style: PwtType.body(weight: FontWeight.w700)),
                      const SizedBox(width: 4),
                      Text(s['perMonth']!, style: PwtType.caption()),
                    ],
                  )
                else
                  Text('${s['purchased']} · ${device.since}', style: PwtType.caption(color: PwtColors.textSec)),
                const Spacer(),
                Flexible(child: Text(device.location ?? '', style: PwtType.eyebrow().copyWith(fontSize: 11, letterSpacing: 0), textAlign: TextAlign.end, overflow: TextOverflow.ellipsis)),
              ],
            ),
          ),
          // service dates
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Expanded(child: _DateBlock(label: s['lastService']!, value: device.lastService ?? '—')),
                Expanded(child: _DateBlock(label: s['nextService']!, value: device.nextService ?? '—', accent: PwtColors.warning, divider: true)),
              ],
            ),
          ),
          // maintenance action
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: device.maintenanceScheduled != null
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: PwtColors.brandTint,
                      border: Border.all(color: PwtColors.brandBorder),
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                    ),
                    child: Row(
                      children: [
                        const Icon(PwtIcons.cal, size: 20, color: PwtColors.brand),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s['scheduledFor']!.toUpperCase(), style: PwtType.eyebrow(color: PwtColors.brand).copyWith(fontSize: 11, letterSpacing: 0.5, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(device.maintenanceScheduled!.date, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                              Text(device.maintenanceScheduled!.window, style: PwtType.caption(color: PwtColors.textSec)),
                            ],
                          ),
                        ),
                        PwtButton(label: s['reschedule']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.sm, onPressed: onMaintenance),
                      ],
                    ),
                  )
                : PwtButton(label: s['requestMaintenance']!, full: true, icon: PwtIcons.wrench, onPressed: onMaintenance),
          ),
          // pay rent
          if (isRent)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12)),
                    child: const Icon(PwtIcons.card, size: 18, color: PwtColors.textSec),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s['payRent']!, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13.5)),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Text(app.isArabic ? 'مستحق في ١ يونيو · ' : 'Due Jun 1 · ', style: PwtType.caption().copyWith(fontSize: 11.5)),
                            const Dirham(size: 10, color: PwtColors.textTer),
                            const SizedBox(width: 2),
                            Text('${device.rent}', style: PwtType.caption().copyWith(fontSize: 11.5)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  PwtButton(label: s['payNow']!, variant: PwtButtonVariant.secondary, size: PwtButtonSize.sm),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _DateBlock extends StatelessWidget {
  const _DateBlock({required this.label, required this.value, this.accent, this.divider = false});
  final String label;
  final String value;
  final Color? accent;
  final bool divider;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: divider ? 14 : 0),
      decoration: BoxDecoration(
        border: divider ? const Border(left: BorderSide(color: PwtColors.hairline)) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10.5, letterSpacing: 1.2)),
          const SizedBox(height: 4),
          Text(value, style: PwtType.subtitle(color: accent ?? PwtColors.textPri).copyWith(fontSize: 15)),
        ],
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
        decoration: BoxDecoration(
          color: PwtColors.surface,
          border: Border.all(color: PwtColors.hairline),
          borderRadius: BorderRadius.circular(16),
          boxShadow: PwtShadows.e1,
        ),
        child: Column(
          children: [
            Icon(icon, size: 20, color: PwtColors.brand),
            const SizedBox(height: 8),
            Text(label, textAlign: TextAlign.center, style: PwtType.label(weight: FontWeight.w500).copyWith(fontSize: 11.5)),
          ],
        ),
      ),
    );
  }
}

/// Awaiting-delivery card with a 4-step progress tracker.
class OrderedDeviceCard extends StatelessWidget {
  const OrderedDeviceCard({super.key, required this.device, required this.onTrackOrder});
  final Device device;
  final VoidCallback onTrackOrder;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final steps = [
      (label: app.isArabic ? 'تم الطلب' : 'Ordered', done: true),
      (label: app.isArabic ? 'التجهيز' : 'Preparing', done: true),
      (label: app.isArabic ? 'الشحن' : 'Shipping', done: false),
      (label: app.isArabic ? 'التسليم' : 'Delivered', done: false),
    ];
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              color: Color(0x1AF59E0B),
              border: Border(bottom: BorderSide(color: PwtColors.hairline)),
            ),
            child: Row(
              children: [
                const Icon(PwtIcons.truck, size: 20, color: PwtColors.warning),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s['deviceOrdered']!, style: PwtType.label(weight: FontWeight.w700).copyWith(fontSize: 13.5)),
                      Text(s['arrivingSoon']!, style: PwtType.caption(color: PwtColors.textSec).copyWith(fontSize: 11.5)),
                    ],
                  ),
                ),
                if (device.orderId != null)
                  Directionality(textDirection: TextDirection.ltr, child: Text(device.orderId!, style: PwtType.mono(size: 11, color: PwtColors.textTer))),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s['estDelivery']!.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10.5, letterSpacing: 1.2)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(PwtIcons.cal, size: 18, color: PwtColors.brand),
                    const SizedBox(width: 8),
                    Text(device.eta ?? '', style: PwtType.subtitle().copyWith(fontSize: 18, fontWeight: FontWeight.w700)),
                  ],
                ),
                const SizedBox(height: 4),
                Text(device.location ?? '', style: PwtType.caption().copyWith(fontSize: 12)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              children: [
                for (int i = 0; i < steps.length; i++) ...[
                  Column(
                    children: [
                      Container(
                        width: 14,
                        height: 14,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: steps[i].done ? PwtColors.brand : PwtColors.surface2,
                          border: steps[i].done ? null : Border.all(color: PwtColors.hairline2, width: 1.5),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(steps[i].label, style: PwtType.caption(color: steps[i].done ? PwtColors.textPri : PwtColors.textTer).copyWith(fontSize: 9.5, fontWeight: steps[i].done ? FontWeight.w600 : FontWeight.w500)),
                    ],
                  ),
                  if (i < steps.length - 1)
                    Expanded(
                      child: Container(
                        height: 1.5,
                        margin: const EdgeInsets.only(bottom: 18),
                        color: steps[i + 1].done ? PwtColors.brand : PwtColors.hairline2,
                      ),
                    ),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: PwtButton(label: s['trackOrder']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.md, full: true, icon: PwtIcons.truck, onPressed: onTrackOrder),
          ),
        ],
      ),
    );
  }
}

// ─── Products catalogue (shared by individual + business) ───
class ProductsScreen extends StatefulWidget {
  const ProductsScreen({
    super.key,
    required this.user,
    required this.role,
    required this.onProfile,
    required this.onOpenProduct,
  });

  final AppUser user;
  final AccountKind role;
  final VoidCallback onProfile;
  final ValueChanged<Product> onOpenProduct;

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  String _cat = 'All';
  static const _cats = ['All', 'Fill Station', 'Sparkling', 'Countertop'];

  String _catLabel(String c, bool ar) {
    if (!ar) return c;
    return const {'All': 'الكل', 'Fill Station': 'محطة تعبئة', 'Sparkling': 'مياه غازية', 'Countertop': 'فوق الطاولة'}[c] ?? c;
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;
    final filtered = _cat == 'All' ? MockData.products : MockData.products.where((p) => p.cat == _cat).toList();

    return _BrandBackdrop(
      opacity: 0.08,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          AppHeader(user: widget.user, onProfile: widget.onProfile),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow(s['catalogue']!),
                const SizedBox(height: 4),
                Text(s['products']!, style: PwtType.headline().copyWith(fontSize: 28)),
                if (widget.role == AccountKind.business) ...[
                  const SizedBox(height: 6),
                  Text(ar ? 'تصفّح المنتجات واطلب عرض سعر جديد.' : 'Browse products and request a new quotation.', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
                ],
              ],
            ),
          ),
          // search (display-only, like prototype)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Container(
              height: 48,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: PwtColors.surface,
                border: Border.all(color: PwtColors.hairline),
                borderRadius: BorderRadius.circular(PwtRadius.md),
              ),
              child: Row(
                children: [
                  const Icon(PwtIcons.search, size: 18, color: PwtColors.textTer),
                  const SizedBox(width: 10),
                  Text(ar ? 'بحث في المنتجات…' : 'Search products…', style: PwtType.body(color: PwtColors.textTer).copyWith(fontSize: 14)),
                ],
              ),
            ),
          ),
          // category chips
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
              children: [
                for (final c in _cats)
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: _CatChip(label: _catLabel(c, ar), on: c == _cat, onTap: () => setState(() => _cat = c)),
                  ),
              ],
            ),
          ),
          // grid
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
            child: GridView.count(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.72,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [for (final p in filtered) _ProductCard(product: p, onTap: () => widget.onOpenProduct(p))],
            ),
          ),
        ],
      ),
    );
  }
}

class _CatChip extends StatelessWidget {
  const _CatChip({required this.label, required this.on, required this.onTap});
  final String label;
  final bool on;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 32,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label, style: TextStyle(fontSize: 12.5, fontWeight: on ? FontWeight.w600 : FontWeight.w500, color: on ? PwtColors.brandDeep : PwtColors.textSec)),
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({required this.product, required this.onTap});
  final Product product;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: PwtColors.surface,
          border: Border.all(color: PwtColors.hairline),
          borderRadius: BorderRadius.circular(PwtRadius.card),
          boxShadow: PwtShadows.e1,
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Container(
                color: PwtColors.surface2,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    ProductImage(img: product.img, size: 90, accent: product.tint),
                    if (product.quoteOnly)
                      Positioned(
                        top: 10,
                        right: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: PwtColors.bgElev,
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: PwtColors.hairline),
                          ),
                          child: Text(app.isArabic ? 'عرض' : 'Quote', style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 9)),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Eyebrow(product.cat, color: product.tint),
                  const SizedBox(height: 4),
                  Text(product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                  const SizedBox(height: 4),
                  if (product.quoteOnly)
                    Text(s['quoteOnly']!, style: PwtType.caption(color: PwtColors.textPri).copyWith(fontSize: 11.5, fontWeight: FontWeight.w600))
                  else
                    Row(
                      children: [
                        Text('${s['fromPrice']} ', style: PwtType.caption().copyWith(fontSize: 11.5)),
                        const Dirham(size: 10, color: PwtColors.textPri),
                        const SizedBox(width: 2),
                        Text('${product.price}', style: PwtType.caption(color: PwtColors.textPri).copyWith(fontSize: 11.5, fontWeight: FontWeight.w600)),
                        Text(s['perMonth']!, style: PwtType.caption().copyWith(fontSize: 11.5)),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Empty devices state (first-time signup) ───
// NOTE: this is only the PAGE WRAPPER (header + greeting). The empty-state
// content itself lives in lib/widgets/empty_states.dart → DevicesEmptyState.
// See EMPTY_STATES.md for the full map.
class _DevicesEmpty extends StatelessWidget {
  const _DevicesEmpty({required this.user, required this.onProfile, required this.onBrowse});
  final AppUser user;
  final VoidCallback onProfile;
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    return _BrandBackdrop(
      child: ListView(
        children: [
          AppHeader(user: user, onProfile: onProfile),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow(s['welcomeBack']!),
                const SizedBox(height: 4),
                Text('${user.name.split(' ').first} 👋', style: PwtType.headline().copyWith(fontSize: 24)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          DevicesEmptyState(business: false, onBrowse: onBrowse),
        ],
      ),
    );
  }
}
