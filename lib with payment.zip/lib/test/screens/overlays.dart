// Maintenance request flow + request detail. Ported from proto/overlays.jsx
// (MaintenanceFlowScreen, RequestDetailScreen).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

class MaintenanceSheet extends StatefulWidget {
  const MaintenanceSheet({super.key, required this.device});
  final Device device;

  @override
  State<MaintenanceSheet> createState() => _MaintenanceSheetState();
}

class _MaintenanceSheetState extends State<MaintenanceSheet> {
  bool _success = false;
  late String _issue;
  String _date = '21';
  bool _init = false;

  List<String> _issues(bool ar) => ar
      ? ['الماء البارد لا يخرج', 'تغيير الفلتر', 'تنظيف عميق', 'انخفاض كمية الماء', 'تسرّب', 'أخرى']
      : ['Cold tap not dispensing', 'Filter replacement', 'Deep clean', 'Low water pressure', 'Leakage', 'Other'];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;
    final d = widget.device;
    final issues = _issues(ar);
    if (!_init) {
      _issue = issues.first;
      _init = true;
    }
    const dates = ['19', '20', '21', '22', '23'];

    return DetailScaffold(
      title: s['requestMaintenance'],
      onBack: _success ? () => Navigator.pop(context) : null,
      body: _success
          ? ListView(
              children: [
                SuccessView(
                  title: ar ? 'تم استلام طلبك' : 'Request received',
                  body: ar ? 'سيصل الفني في 21 مايو بين 10:00 و 13:00.' : 'A technician will arrive on May 21 between 10:00 and 13:00.',
                  accent: PwtColors.brand,
                  detail: PwtCard(
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: [
                        const ListRow(leading: PwtIcons.cal, title: 'May 21, 2026', sub: '10:00 – 13:00'),
                        ListRow(leading: PwtIcons.user, title: 'Tariq A.', sub: s['technician']),
                        ListRow(leading: PwtIcons.message, title: ar ? 'سنرسل تأكيداً عبر الواتساب' : 'You\u2019ll get a WhatsApp confirmation', last: true),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                  child: PwtButton(label: s['done']!, full: true, onPressed: () => Navigator.pop(context)),
                ),
              ],
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              children: [
                // device card
                PwtCard(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 56,
                        decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: PwtColors.hairline)),
                        alignment: Alignment.center,
                        child: Image(image: pwtImage(d.img), height: 42, fit: BoxFit.contain),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                            const SizedBox(height: 2),
                            Directionality(textDirection: TextDirection.ltr, child: Text(d.id, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                // issue
                _sectionTitle(ar ? 'ما هي المشكلة؟' : "What's the issue?"),
                for (final opt in issues)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: GestureDetector(
                      onTap: () => setState(() => _issue = opt),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: opt == _issue ? PwtColors.brandTint : PwtColors.surface,
                          border: Border.all(color: opt == _issue ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 18,
                              height: 18,
                              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: opt == _issue ? PwtColors.brand : PwtColors.hairline2, width: 2)),
                              child: opt == _issue ? const Center(child: SizedBox(width: 8, height: 8, child: DecoratedBox(decoration: BoxDecoration(color: PwtColors.brand, shape: BoxShape.circle)))) : null,
                            ),
                            const SizedBox(width: 12),
                            Expanded(child: Text(opt, style: PwtType.label(weight: opt == _issue ? FontWeight.w600 : FontWeight.w500).copyWith(fontSize: 14))),
                          ],
                        ),
                      ),
                    ),
                  ),
                // date
                _sectionTitle(ar ? 'اختر الموعد' : 'Pick a date'),
                SizedBox(
                  height: 60,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final dd in dates)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () => setState(() => _date = dd),
                            child: Container(
                              width: 64,
                              decoration: BoxDecoration(
                                color: dd == _date ? PwtColors.brand : PwtColors.surface,
                                border: Border.all(color: dd == _date ? PwtColors.brand : PwtColors.hairline, width: 1.5),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(ar ? 'مايو' : 'May', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1, color: dd == _date ? Colors.white70 : PwtColors.textTer)),
                                  Text(dd, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: dd == _date ? Colors.white : PwtColors.textPri)),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 12, left: 4),
                  child: Text(ar ? 'النافذة الزمنية: 10:00 – 13:00' : 'Time window: 10:00 – 13:00', style: PwtType.caption().copyWith(fontSize: 12)),
                ),
                const SizedBox(height: 28),
                PwtButton(label: s['confirm']!, full: true, onPressed: () => setState(() => _success = true)),
              ],
            ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(top: 24, bottom: 12),
        child: Eyebrow(t),
      );
}

// ─── Request detail (business) ───
class RequestDetailScreen extends StatelessWidget {
  const RequestDetailScreen({super.key, required this.request});
  final MaintenanceRequest request;

  Color _statusColor(String st) => switch (st) {
        'scheduled' => PwtColors.brand,
        'in_progress' => PwtColors.warning,
        'completed' => PwtColors.success,
        _ => PwtColors.textSec,
      };

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final r = request;
    return DetailScaffold(
      title: '#${r.id}',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          PwtCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(r.issue, style: PwtType.subtitle().copyWith(fontSize: 17, fontWeight: FontWeight.w700))),
                    Pill(label: r.statusLabel, color: _statusColor(r.status), dot: true),
                  ],
                ),
                const SizedBox(height: 6),
                Text(r.device, style: PwtType.body(color: PwtColors.textSec)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          PwtCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                ListRow(leading: PwtIcons.cal, title: r.schedule, sub: s['timeWindow']),
                ListRow(leading: PwtIcons.user, title: r.tech, sub: s['technician']),
                ListRow(leading: PwtIcons.cube, title: r.device, sub: r.deviceId),
                ListRow(leading: PwtIcons.info, title: r.raised, sub: app.isArabic ? 'تاريخ الطلب' : 'Raised on', last: true),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
