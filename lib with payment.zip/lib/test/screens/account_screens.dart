// Account area: Profile (individual + company), Settings, Invoices, Orders.
// Ported from proto/account.jsx. Edits are kept in-memory (swap useStore for a
// repository / shared_preferences when persistence is needed).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../widgets/form_field.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

// ═══════════════════════ PROFILE ═══════════════════════
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.user, required this.role});
  final AppUser user;
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final primary = MockData.paymentMethods.firstWhere((c) => c.primary, orElse: () => MockData.paymentMethods.first);

    return DetailScaffold(
      title: s['profile'],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            child: PwtCard(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [PwtColors.brand, PwtColors.brandDeep])),
                    alignment: Alignment.center,
                    child: Text(user.initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 20)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.name, style: PwtType.subtitle().copyWith(fontSize: 17)),
                        const SizedBox(height: 3),
                        Directionality(textDirection: TextDirection.ltr, child: Text(user.phone, style: PwtType.mono(size: 12, color: PwtColors.textTer))),
                        const SizedBox(height: 8),
                        Pill(label: role == AccountKind.business ? s['business']! : s['individual']!),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (role == AccountKind.business) const _CompanyProfile() else const _IndividualProfile(),
          Section(
            title: s['paymentDetails']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: ListRow(
                leading: PwtIcons.card,
                title: '${primary.kind == 'visa' ? 'Visa' : 'Mastercard'} ···· ${primary.last4}',
                sub: '${s['primary']} · ${MockData.paymentMethods.length} cards',
                trailing: const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
                last: true,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IndividualProfile extends StatefulWidget {
  const _IndividualProfile();
  @override
  State<_IndividualProfile> createState() => _IndividualProfileState();
}

class _IndividualProfileState extends State<_IndividualProfile> {
  bool _edit = false;
  late AppUser _u = MockData.userIndividual;
  late List<Address> _addresses = List.of(MockData.individualAddresses);

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return Column(
      children: [
        Section(
          title: s['personal']!,
          trailing: GestureDetector(
            onTap: () => setState(() => _edit = !_edit),
            child: Text(_edit ? s['saved']! : s['edit']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
          ),
          child: _edit
              ? Column(
                  children: [
                    PwtField(label: s['fullName']!, initialValue: _u.name),
                    const SizedBox(height: 10),
                    PwtField(label: s['email']!, initialValue: _u.email, forceLtr: true),
                    const SizedBox(height: 10),
                    PwtField(label: s['phoneNumber']!, initialValue: _u.phone, forceLtr: true),
                  ],
                )
              : PwtCard(
                  padding: EdgeInsets.zero,
                  child: Column(
                    children: [
                      ListRow(leading: PwtIcons.user, title: _u.name, sub: s['fullName']),
                      ListRow(leading: PwtIcons.phone, title: _u.phone, sub: s['phoneNumber']),
                      ListRow(leading: PwtIcons.message, title: _u.email, sub: s['email'], last: true),
                    ],
                  ),
                ),
        ),
        Section(
          title: s['savedAddresses']!,
          child: Column(
            children: [
              for (final a in _addresses)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _AddressCard(
                    address: a,
                    canRemove: _addresses.length > 1,
                    onSetDefault: () => setState(() => _addresses = _addresses.map((x) => x.copyWith(isDefault: x.id == a.id)).toList()),
                    onRemove: () => setState(() => _addresses = _addresses.where((x) => x.id != a.id).toList()),
                  ),
                ),
              PwtButton(label: s['addAddress']!, variant: PwtButtonVariant.secondary, full: true, icon: PwtIcons.plus),
            ],
          ),
        ),
      ],
    );
  }
}

class _AddressCard extends StatelessWidget {
  const _AddressCard({required this.address, required this.canRemove, required this.onSetDefault, required this.onRemove});
  final Address address;
  final bool canRemove;
  final VoidCallback onSetDefault;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(PwtIcons.pin, size: 16, color: PwtColors.brand),
                    const SizedBox(width: 8),
                    Text(address.label, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5)),
                    const SizedBox(width: 8),
                    if (address.isDefault) Pill(label: s['defaultAddr']!, color: PwtColors.success),
                  ],
                ),
                const SizedBox(height: 6),
                Text(address.line, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13, height: 1.5)),
                const SizedBox(height: 3),
                Text('${address.city}${address.phone.isNotEmpty ? ' · ${address.phone}' : ''}', style: PwtType.caption().copyWith(fontSize: 12)),
              ],
            ),
          ),
          Container(
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              children: [
                if (!address.isDefault) _addrAction(s['setDefault']!, null, onSetDefault),
                _addrAction(s['edit']!, PwtIcons.edit, () {}),
                if (canRemove) _addrAction(s['remove']!, PwtIcons.trash, onRemove, danger: true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _addrAction(String label, IconData? icon, VoidCallback onTap, {bool danger = false}) {
    final color = danger ? PwtColors.error : PwtColors.brand;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
          decoration: const BoxDecoration(border: Border(right: BorderSide(color: PwtColors.hairline))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[Icon(icon, size: 14, color: color), const SizedBox(width: 6)],
              Text(label, style: TextStyle(color: color, fontSize: 12.5, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CompanyProfile extends StatefulWidget {
  const _CompanyProfile();
  @override
  State<_CompanyProfile> createState() => _CompanyProfileState();
}

class _CompanyProfileState extends State<_CompanyProfile> {
  bool _edit = false;
  final Company _c = MockData.company;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return Section(
      title: s['companyInfo']!,
      trailing: GestureDetector(
        onTap: () => setState(() => _edit = !_edit),
        child: Text(_edit ? s['saved']! : s['edit']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
      ),
      child: _edit
          ? Column(
              children: [
                PwtField(label: s['companyName']!, initialValue: _c.name),
                const SizedBox(height: 10),
                PwtField(label: s['companyAddress']!, initialValue: _c.address),
                const SizedBox(height: 10),
                PwtField(label: 'Industry', initialValue: _c.industry),
                const SizedBox(height: 10),
                PwtField(label: 'TRN', initialValue: _c.trn, forceLtr: true),
                const SizedBox(height: 10),
                PwtField(label: 'Primary contact', initialValue: _c.contact),
                const SizedBox(height: 10),
                PwtField(label: s['email']!, initialValue: _c.email, forceLtr: true),
              ],
            )
          : PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  ListRow(leading: PwtIcons.building, title: _c.name, sub: s['companyName']),
                  ListRow(leading: PwtIcons.pin, title: _c.address, sub: s['companyAddress']),
                  ListRow(leading: PwtIcons.briefcase, title: _c.industry, sub: 'Industry'),
                  ListRow(leading: PwtIcons.shield, title: _c.trn, sub: 'TRN'),
                  ListRow(leading: PwtIcons.user, title: _c.contact, sub: 'Primary contact'),
                  ListRow(leading: PwtIcons.message, title: _c.email, sub: s['email'], last: true),
                ],
              ),
            ),
    );
  }
}

// ═══════════════════════ SETTINGS ═══════════════════════
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final Map<String, bool> _notifs = Map.of(MockData.notifDefaults);
  final _curPw = TextEditingController();
  final _newPw = TextEditingController();
  final _confPw = TextEditingController();
  bool _pwDone = false;

  @override
  void dispose() {
    _curPw.dispose();
    _newPw.dispose();
    _confPw.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final rows = [
      (k: 'maintenance', label: s['notifMaintenance']!, sub: s['notifMaintenanceSub']!, icon: PwtIcons.wrench),
      (k: 'billing', label: s['notifBilling']!, sub: s['notifBillingSub']!, icon: PwtIcons.card),
      (k: 'orders', label: s['notifOrders']!, sub: s['notifOrdersSub']!, icon: PwtIcons.orders),
      (k: 'offers', label: s['notifOffers']!, sub: s['notifOffersSub']!, icon: PwtIcons.bolt),
    ];

    return DetailScaffold(
      title: s['settings'],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Section(
            title: s['notifications']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  for (int i = 0; i < rows.length; i++)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(border: i == rows.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                      child: Row(
                        children: [
                          Icon(rows[i].icon, size: 18, color: PwtColors.textSec),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(rows[i].label, style: PwtType.label(weight: FontWeight.w500).copyWith(fontSize: 14)),
                                const SizedBox(height: 2),
                                Text(rows[i].sub, style: PwtType.caption().copyWith(fontSize: 11.5)),
                              ],
                            ),
                          ),
                          PwtSwitch(value: _notifs[rows[i].k] ?? false, onChanged: (v) => setState(() => _notifs[rows[i].k] = v)),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          Section(
            title: s['security']!,
            child: Column(
              children: [
                PwtField(label: s['currentPassword']!, controller: _curPw, obscure: true),
                const SizedBox(height: 10),
                PwtField(label: s['newPassword']!, controller: _newPw, obscure: true),
                const SizedBox(height: 10),
                PwtField(label: s['confirmNewPassword']!, controller: _confPw, obscure: true),
                const SizedBox(height: 8),
                Align(alignment: AlignmentDirectional.centerStart, child: Padding(padding: const EdgeInsets.only(left: 4), child: Text(s['passwordHint']!, style: PwtType.caption().copyWith(fontSize: 11.5)))),
                const SizedBox(height: 10),
                PwtButton(
                  label: _pwDone ? s['passwordUpdated']! : s['updatePassword']!,
                  variant: _pwDone ? PwtButtonVariant.soft : PwtButtonVariant.primary,
                  full: true,
                  icon: _pwDone ? PwtIcons.check : PwtIcons.lock,
                  onPressed: () {
                    setState(() => _pwDone = true);
                    Future.delayed(const Duration(milliseconds: 1800), () {
                      if (mounted) setState(() => _pwDone = false);
                    });
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════ INVOICES ═══════════════════════
class InvoicesScreen extends StatelessWidget {
  const InvoicesScreen({super.key, required this.invoices});
  final List<Invoice> invoices;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return DetailScaffold(
      title: s['invoices'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Eyebrow(s['allInvoices']!),
          const SizedBox(height: 4),
          Text(s['invoices']!, style: PwtType.headline().copyWith(fontSize: 26)),
          const SizedBox(height: 18),
          for (final inv in invoices)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _InvoiceCard(inv: inv),
            ),
        ],
      ),
    );
  }
}

class _InvoiceCard extends StatefulWidget {
  const _InvoiceCard({required this.inv});
  final Invoice inv;
  @override
  State<_InvoiceCard> createState() => _InvoiceCardState();
}

class _InvoiceCardState extends State<_InvoiceCard> {
  bool _dl = false;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final inv = widget.inv;
    final paid = inv.status == 'paid';
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12)),
                  child: const Icon(PwtIcons.file, size: 20, color: PwtColors.textSec),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Directionality(textDirection: TextDirection.ltr, child: Text(inv.id, style: PwtType.mono(size: 11.5, color: PwtColors.brand, weight: FontWeight.w600))),
                          const SizedBox(width: 8),
                          Pill(label: paid ? s['paid']! : s['dueStatus']!, color: paid ? PwtColors.success : PwtColors.warning, dot: true),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(inv.desc, style: PwtType.label(weight: FontWeight.w500).copyWith(fontSize: 13.5)),
                      const SizedBox(height: 2),
                      Text(inv.date, style: PwtType.caption().copyWith(fontSize: 12)),
                    ],
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    const Dirham(size: 12),
                    const SizedBox(width: 3),
                    Text(inv.amount.toStringAsFixed(2), style: PwtType.subtitle().copyWith(fontSize: 15, fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () {
              setState(() => _dl = true);
              Future.delayed(const Duration(milliseconds: 1500), () {
                if (mounted) setState(() => _dl = false);
              });
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(_dl ? PwtIcons.check : PwtIcons.file, size: 15, color: _dl ? PwtColors.success : PwtColors.brand),
                  const SizedBox(width: 8),
                  Text(_dl ? s['saved']! : s['download']!, style: TextStyle(color: _dl ? PwtColors.success : PwtColors.brand, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════ ORDERS ═══════════════════════
class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key, required this.orders, required this.role, this.onViewQuote});
  final List<Order> orders;
  final AccountKind role;
  final ValueChanged<Order>? onViewQuote;

  Color _statusColor(String status) => switch (status) {
        'active' => PwtColors.success,
        'delivered' => PwtColors.textSec,
        'quote_pending' => PwtColors.warning,
        'quote_sent' => PwtColors.info,
        'cancelled' => PwtColors.error,
        'approved' => PwtColors.success,
        _ => PwtColors.textSec,
      };

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return DetailScaffold(
      title: s['orders'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          for (final o in orders)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: PwtCard(
                padding: const EdgeInsets.all(16),
                onTap: (o.status == 'quote_sent' || o.status == 'quote_pending') && onViewQuote != null ? () => onViewQuote!(o) : null,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Directionality(textDirection: TextDirection.ltr, child: Text(o.id, style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
                        Pill(label: o.statusLabel, color: _statusColor(o.status), dot: true),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(o.items, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5)),
                    const SizedBox(height: 4),
                    Text('${s['placed']} ${o.date}', style: PwtType.caption().copyWith(fontSize: 12)),
                    if (o.amount != null) ...[
                      const SizedBox(height: 10),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.baseline,
                        textBaseline: TextBaseline.alphabetic,
                        children: [
                          Text('${s['total']}  ', style: PwtType.caption()),
                          const Dirham(size: 12),
                          const SizedBox(width: 3),
                          Text('${o.amount}', style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                          if (o.plan == Plan.rent) Text(s['perMonth']!, style: PwtType.caption()),
                        ],
                      ),
                    ],
                    if ((o.status == 'quote_sent') && onViewQuote != null) ...[
                      const SizedBox(height: 12),
                      PwtButton(label: s['viewQuotation']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.md, full: true, onPressed: () => onViewQuote!(o)),
                    ],
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
