// Cart, checkout and success flows. Ported from proto/cart.jsx. Checkout and
// the success screens are pushed as routes from the cart.

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

String _genOrderId(AccountKind role) {
  final n = 2300 + Random().nextInt(999);
  return role == AccountKind.business ? 'PWT-B-$n' : 'PWT-${1100 + Random().nextInt(99)}';
}

class _Row {
  _Row(this.item, this.product);
  final CartItem item;
  final Product product;
  int get qty => item.qty;
  Plan get plan => item.plan;
  bool get isQuote => plan == Plan.quote || product.quoteOnly;
  int get unit => plan == Plan.buy ? (product.buyPrice ?? 0) : (product.price ?? 0);
  int get lineTotal => isQuote ? 0 : unit * qty;
}

List<_Row> _rowsOf(CartState cart) => cart.items
    .map((i) => (i, MockData.productById(i.productId)))
    .where((p) => p.$2 != null)
    .map((p) => _Row(p.$1, p.$2!))
    .toList();

class CartScreen extends StatelessWidget {
  const CartScreen({super.key, required this.role});
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartState>();
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final rows = _rowsOf(cart);

    if (rows.isEmpty) {
      return DetailScaffold(
        title: s['yourCart'],
        body: Padding(
          padding: const EdgeInsets.fromLTRB(20, 60, 20, 0),
          child: Column(
            children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(color: PwtColors.surface2, shape: BoxShape.circle, border: Border.all(color: PwtColors.hairline)),
                child: const Icon(PwtIcons.cart, size: 36, color: PwtColors.textTer),
              ),
              const SizedBox(height: 18),
              Text(s['emptyCart']!, style: PwtType.title().copyWith(fontSize: 20)),
              const SizedBox(height: 8),
              Text(s['emptyCartSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
              const SizedBox(height: 24),
              PwtButton(label: s['browseProducts']!, onPressed: () => Navigator.pop(context)),
            ],
          ),
        ),
      );
    }

    final subtotal = rows.fold<int>(0, (sum, r) => sum + r.lineTotal);
    final hasQuote = rows.any((r) => r.isQuote);
    final vat = (subtotal * 0.05);
    final total = subtotal + vat;
    final quoteFlow = role == AccountKind.business || hasQuote;

    return DetailScaffold(
      title: s['yourCart'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text('${rows.length} ${rows.length == 1 ? s['item'] : s['items']}', style: PwtType.caption().copyWith(fontSize: 12)),
          ),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _CartItemCard(row: r, role: role),
            ),
          if (role == AccountKind.individual && !hasQuote) ...[
            const SizedBox(height: 6),
            PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, PwtColors.textSec)),
                  SummaryRow(label: s['shippingFee']!, value: Text(s['free']!, style: const TextStyle(color: PwtColors.success, fontWeight: FontWeight.w600))),
                  SummaryRow(label: s['vat']!, value: _money(vat, PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, PwtColors.textPri)),
                ],
              ),
            ),
          ],
          if (quoteFlow) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: PwtColors.brandTint,
                border: Border.all(color: PwtColors.brandBorder),
                borderRadius: BorderRadius.circular(PwtRadius.card),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(PwtIcons.info, size: 18, color: PwtColors.brand),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      app.isArabic
                          ? 'يتم تحديد الأسعار النهائية بناءً على متطلبات الشركة. سيتواصل معك فريقنا بعرض السعر خلال 24 ساعة.'
                          : 'Final pricing is determined based on your company\u2019s requirements. Our team will share a tailored quotation within 24 hours.',
                      style: PwtType.body(color: PwtColors.textPri).copyWith(fontSize: 12.5, height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
      bottomBar: quoteFlow
          ? PwtButton(
              label: s['requestQuotation']!,
              full: true,
              icon: PwtIcons.message,
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuotationSuccessScreen(rows: rows, role: role))),
            )
          : PwtButton(
              label: s['proceedToCheckout']!,
              full: true,
              trailing: PwtIcons.arrow,
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(rows: rows, subtotal: subtotal, vat: vat, total: total))),
            ),
    );
  }
}

Widget _money(num v, Color color, {double symbol = 11, double size = 14, FontWeight weight = FontWeight.w600}) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.baseline,
    textBaseline: TextBaseline.alphabetic,
    children: [
      Dirham(size: symbol, color: color),
      const SizedBox(width: 3),
      Text(_fmt(v), style: TextStyle(color: color, fontSize: size, fontWeight: weight)),
    ],
  );
}

String _fmt(num v) {
  final s = v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(2);
  // thousands separators
  final parts = s.split('.');
  final intPart = parts[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return parts.length > 1 ? '$intPart.${parts[1]}' : intPart;
}

class _CartItemCard extends StatelessWidget {
  const _CartItemCard({required this.row, required this.role});
  final _Row row;
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartState>();
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final p = row.product;

    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 76,
                  height: 88,
                  decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                  alignment: Alignment.center,
                  child: Image(image: pwtImage(p.img), height: 70, fit: BoxFit.contain),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Eyebrow(p.cat, color: p.tint),
                                const SizedBox(height: 4),
                                Text(p.name, style: PwtType.subtitle().copyWith(fontSize: 15)),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () => cart.removeItem(row.item.productId, row.plan),
                            child: const Icon(PwtIcons.close, size: 18, color: PwtColors.textTer),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (row.isQuote)
                        Text(s['quoteOnly']!, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13))
                      else
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            const Dirham(size: 12),
                            const SizedBox(width: 4),
                            Text(_fmt(row.unit), style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                            if (row.plan == Plan.rent) Text(s['perMonth']!, style: PwtType.caption().copyWith(fontSize: 12)),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // plan toggle (individual, non-quote)
          if (role == AccountKind.individual && !p.quoteOnly)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                child: Row(
                  children: [
                    _planTab(context, s['rent']!, p.price ?? 0, s['perMonth']!, row.plan == Plan.rent, () => cart.setPlan(row.item.productId, row.plan, Plan.rent)),
                    _planTab(context, s['buy']!, p.buyPrice ?? 0, '', row.plan == Plan.buy, () => cart.setPlan(row.item.productId, row.plan, Plan.buy)),
                  ],
                ),
              ),
            ),
          // qty stepper
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(s['quantity']!, style: PwtType.caption(color: PwtColors.textSec).copyWith(fontSize: 12)),
                Row(
                  children: [
                    _StepBtn(icon: PwtIcons.minus, enabled: row.qty > 1, onTap: () => cart.setQty(row.item.productId, row.plan, row.qty - 1)),
                    Container(
                      constraints: const BoxConstraints(minWidth: 44),
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text('${row.qty}', style: PwtType.mono(size: 15, weight: FontWeight.w600)),
                    ),
                    _StepBtn(icon: PwtIcons.plus, primary: true, onTap: () => cart.setQty(row.item.productId, row.plan, row.qty + 1)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _planTab(BuildContext context, String label, int price, String suffix, bool on, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: PwtMotion.fast,
          height: 40,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: on ? PwtColors.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            boxShadow: on ? const [BoxShadow(color: Color(0x1F0F172A), blurRadius: 4, offset: Offset(0, 1))] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: TextStyle(fontSize: 12, fontWeight: on ? FontWeight.w600 : FontWeight.w500, color: on ? PwtColors.textPri : PwtColors.textSec)),
              Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  const Dirham(size: 8, color: PwtColors.textTer),
                  const SizedBox(width: 2),
                  Text('${_fmt(price)}$suffix', style: PwtType.caption().copyWith(fontSize: 10.5)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.onTap, this.enabled = true, this.primary = false});
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.4,
      child: GestureDetector(
        onTap: enabled ? onTap : null,
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: primary ? PwtColors.brandTint : PwtColors.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: primary ? PwtColors.brandBorder : PwtColors.hairline2),
          ),
          child: Icon(icon, size: 16, color: primary ? PwtColors.brand : PwtColors.textPri),
        ),
      ),
    );
  }
}

// ─── Checkout ───
class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key, required this.rows, required this.subtotal, required this.vat, required this.total});
  final List<_Row> rows;
  final int subtotal;
  final double vat;
  final double total;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;
    final user = MockData.userIndividual;

    return DetailScaffold(
      title: s['checkout'],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Section(
            title: s['orderSummary']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  for (int i = 0; i < rows.length; i++)
                    _summaryItem(context, rows[i], s, ar, last: i == rows.length - 1),
                ],
              ),
            ),
          ),
          Section(
            title: s['shippingAddress']!,
            child: PwtCard(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(PwtIcons.pin, size: 20, color: PwtColors.brand),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                        const SizedBox(height: 4),
                        Text(ar ? 'مرسى دبي، برج المرجان 1، شقة 1402\nدبي، الإمارات' : 'Dubai Marina, Marjan Tower 1, Apt 1402\nDubai, United Arab Emirates', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 12.5, height: 1.5)),
                        const SizedBox(height: 4),
                        Directionality(textDirection: TextDirection.ltr, child: Text(user.phone, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Section(
            title: s['deliveryWindow']!,
            child: PwtCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  const Icon(PwtIcons.cal, size: 20, color: PwtColors.brand),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(ar ? 'الجمعة، 22 مايو' : 'Friday, May 22', style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                        const SizedBox(height: 2),
                        Text(ar ? 'بين 10:00 و 14:00 · شامل التركيب' : '10:00 – 14:00 · Installation included', style: PwtType.caption().copyWith(fontSize: 11.5)),
                      ],
                    ),
                  ),
                  const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
                ],
              ),
            ),
          ),
          Section(
            title: s['paymentMethod']!,
            child: PwtCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 32,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(6), gradient: const LinearGradient(colors: [Color(0xFF1A1F71), Color(0xFF4A52A3)])),
                    alignment: Alignment.center,
                    child: const Text('VISA', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Directionality(textDirection: TextDirection.ltr, child: Text('Visa ···· 4912', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: PwtColors.textPri))),
                        const SizedBox(height: 2),
                        Text('${s['primary']} · ${ar ? 'صلاحية' : 'Exp'} 09/27', style: PwtType.caption().copyWith(fontSize: 11.5)),
                      ],
                    ),
                  ),
                  const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
                ],
              ),
            ),
          ),
          Section(
            title: s['total']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, PwtColors.textSec)),
                  SummaryRow(label: s['shippingFee']!, value: Text(s['free']!, style: const TextStyle(color: PwtColors.success, fontWeight: FontWeight.w600))),
                  SummaryRow(label: s['vat']!, value: _money(vat, PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, PwtColors.textPri)),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomBar: PwtButton(
        label: s['placeOrder']!,
        full: true,
        trailing: PwtIcons.arrow,
        onPressed: () {
          context.read<CartState>().clear();
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => OrderSuccessScreen(rows: rows, subtotal: subtotal, vat: vat, total: total)));
        },
      ),
    );
  }

  Widget _summaryItem(BuildContext context, _Row r, Map<String, String> s, bool ar, {bool last = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 56,
            decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: PwtColors.hairline)),
            alignment: Alignment.center,
            child: Image(image: pwtImage(r.product.img), height: 42, fit: BoxFit.contain),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                const SizedBox(height: 2),
                Text('${r.plan == Plan.rent ? s['rent'] : s['buy']} · ${ar ? 'كمية' : 'Qty'} ${r.qty}', style: PwtType.caption().copyWith(fontSize: 11.5)),
              ],
            ),
          ),
          _money(r.unit * r.qty, PwtColors.textPri, size: 14),
        ],
      ),
    );
  }
}

// ─── Order confirmed (individual) ───
class OrderSuccessScreen extends StatelessWidget {
  const OrderSuccessScreen({super.key, required this.rows, required this.subtotal, required this.vat, required this.total});
  final List<_Row> rows;
  final int subtotal;
  final double vat;
  final double total;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final orderId = _genOrderId(AccountKind.individual);

    return DetailScaffold(
      title: s['orderConfirmed'],
      onBack: () => Navigator.of(context).popUntil((r) => r.isFirst),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          SuccessView(
            title: s['orderConfirmed']!,
            body: s['orderConfirmedSub']!,
            detail: Directionality(
              textDirection: TextDirection.ltr,
              child: Text('${s['orderId']}  $orderId', style: PwtType.mono(size: 12, color: PwtColors.brand, weight: FontWeight.w600)),
            ),
          ),
          Section(
            title: s['total']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, PwtColors.textSec)),
                  SummaryRow(label: s['vat']!, value: _money(vat, PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, PwtColors.textPri)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              children: [
                PwtButton(label: s['viewOrder']!, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
                const SizedBox(height: 10),
                PwtButton(label: s['continueShopping']!, variant: PwtButtonVariant.ghost, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Quotation submitted (business / quote items) ───
class QuotationSuccessScreen extends StatelessWidget {
  const QuotationSuccessScreen({super.key, required this.rows, required this.role});
  final List<_Row> rows;
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final orderId = _genOrderId(AccountKind.business);

    return DetailScaffold(
      title: s['quotationSubmitted'],
      onBack: () => Navigator.of(context).popUntil((r) => r.isFirst),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          SuccessView(
            title: s['quotationSubmitted']!,
            body: s['quotationSubmittedSub']!,
            icon: PwtIcons.message,
            accent: PwtColors.brand,
            detail: Directionality(
              textDirection: TextDirection.ltr,
              child: Text('${s['orderId']}  $orderId', style: PwtType.mono(size: 12, color: PwtColors.brand, weight: FontWeight.w600)),
            ),
          ),
          Section(
            title: app.isArabic ? 'العناصر المطلوبة' : 'Requested items',
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  for (int i = 0; i < rows.length; i++)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(border: i == rows.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 50,
                            decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(8), border: Border.all(color: PwtColors.hairline)),
                            alignment: Alignment.center,
                            child: Image(image: pwtImage(rows[i].product.img), height: 38, fit: BoxFit.contain),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Text(rows[i].product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13.5))),
                          Text('${app.isArabic ? 'كمية' : 'Qty'} ${rows[i].qty}', style: PwtType.caption().copyWith(fontSize: 11.5)),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: PwtBanner(
              variant: BannerVariant.info,
              title: app.isArabic ? 'الخطوات التالية' : 'What happens next',
              body: app.isArabic
                  ? 'سيراجع فريقنا متطلباتك ويرسل عرض السعر مع تفاصيل التركيب خلال 24 ساعة عمل.'
                  : 'Our team will review your requirements and send a tailored quote with installation details within 24 working hours.',
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              children: [
                PwtButton(label: s['viewOrder']!, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
                const SizedBox(height: 10),
                PwtButton(label: s['continueShopping']!, variant: PwtButtonVariant.ghost, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
