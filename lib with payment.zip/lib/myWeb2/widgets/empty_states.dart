// Empty states for the dashboard machines/orders lists — mirrors the
// DevicesEmptyState / OrdersEmptyState design from lib/myApp/widgets/empty_states.dart,
// restyled with myWeb2's web design tokens (AppColors/AppText/PwtButton).

import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import 'common.dart';

/// Circular brand medallion used as the illustration slot in every empty state.
class EmptyMedallion extends StatelessWidget {
  const EmptyMedallion({super.key, required this.icon, this.size = 72, this.iconSize = 32});
  final IconData icon;
  final double size;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.blue50,
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.blue200),
      ),
      alignment: Alignment.center,
      child: Icon(icon, size: iconSize, color: AppColors.blue700),
    );
  }
}

/// Machines / fleet empty state. `business: true` swaps the "7 days free
/// trial" banner for the three-step "how it works" list, since a company
/// fleet starts with a quotation rather than a self-serve purchase.
class DevicesEmptyState extends StatelessWidget {
  const DevicesEmptyState({super.key, required this.business, required this.onBrowse});
  final bool business;
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: business ? 28 : 36, horizontal: 12),
      child: Column(children: [
        EmptyMedallion(icon: Icons.water_drop_outlined, size: business ? 68 : 72, iconSize: business ? 30 : 32),
        const SizedBox(height: 18),
        Text(
          business ? 'Your fleet is empty' : 'No machines yet',
          textAlign: TextAlign.center,
          style: AppText.h2.copyWith(fontSize: 19),
        ),
        const SizedBox(height: 6),
        Text(
          business
              ? 'Request a quotation for your office or facility — we\'ll handle install + setup.'
              : 'Browse the PWT catalogue and add your first machine.',
          textAlign: TextAlign.center,
          style: AppText.muted,
        ),
        const SizedBox(height: 20),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: business ? const _HowItWorksSteps() : const _TrialBanner(),
        ),
        const SizedBox(height: 22),
        PwtButton(
          business ? 'Request Quotation' : 'Explore Products',
          icon: Icons.arrow_forward,
          onPressed: onBrowse,
        ),
      ]),
    );
  }
}

class _TrialBanner extends StatelessWidget {
  const _TrialBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.blue200),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.blue50, Colors.white],
        ),
      ),
      child: Row(children: [
        Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: AppColors.blue700, borderRadius: BorderRadius.circular(13)),
          child: const Text('7', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('7 days free, on us', style: AppText.label.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text('Try any device for a week — cancel anytime, no charge.', style: AppText.muted),
          ]),
        ),
      ]),
    );
  }
}

class _HowItWorksSteps extends StatelessWidget {
  const _HowItWorksSteps();

  @override
  Widget build(BuildContext context) {
    const steps = ['Request a quotation', 'Install & setup', 'Manage & maintain'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('HOW IT WORKS', style: AppText.muted.copyWith(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
        const SizedBox(height: 10),
        for (var i = 0; i < steps.length; i++)
          Padding(
            padding: EdgeInsets.only(bottom: i == steps.length - 1 ? 0 : 8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.line),
                boxShadow: const [BoxShadow(color: Color(0x0A0F1E50), blurRadius: 10, offset: Offset(0, 3))],
              ),
              child: Row(children: [
                Container(
                  width: 24,
                  height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: AppColors.blue50, shape: BoxShape.circle, border: Border.all(color: AppColors.blue200)),
                  child: Text('${i + 1}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.blue700)),
                ),
                const SizedBox(width: 12),
                Expanded(child: Text(steps[i], style: AppText.label)),
              ]),
            ),
          ),
      ],
    );
  }
}

/// Orders empty state (Orders tab, individual or company).
class OrdersEmptyState extends StatelessWidget {
  const OrdersEmptyState({super.key, required this.onBrowse});
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 12),
      child: Column(children: [
        const EmptyMedallion(icon: Icons.inventory_2_outlined, size: 64, iconSize: 28),
        const SizedBox(height: 16),
        Text('No orders yet', style: AppText.h2.copyWith(fontSize: 18)),
        const SizedBox(height: 6),
        Text('Orders you place will show up here.', textAlign: TextAlign.center, style: AppText.muted),
        const SizedBox(height: 18),
        ConstrainedBox(constraints: const BoxConstraints(maxWidth: 380), child: const _TrialBanner()),
        const SizedBox(height: 20),
        PwtButton('Explore Products', icon: Icons.arrow_forward, onPressed: onBrowse),
      ]),
    );
  }
}
