import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String _mode = 'buy';
  int _step = 2; // 2 Info, 3 Delivery/Rental, 4 Payment, 5 Review
  int _slot = 0;
  int _plan = 1; // 24/36/48 -> default 36 (Best Value)
  int _pay = 0; // card/apple/google
  bool _modeInit = false;

  late final _name = TextEditingController();
  late final _email = TextEditingController();
  late final _phone = TextEditingController();
  late final _countryCode = TextEditingController();
  final _addr1 = TextEditingController();
  final _city = TextEditingController();
  final _postcode = TextEditingController();

  @override
  void initState() {
    super.initState();
    final u = AppState.instance.user;
    if (u != null) {
      _name.text = u.name ?? '';
      _email.text = u.email ?? '';
      final code = u.phoneCountryCode ?? '+971';
      final rawPhone = u.phone ?? '';
      _countryCode.text = code;
      _phone.text = rawPhone.startsWith(code) ? rawPhone.substring(code.length) : rawPhone;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    _countryCode.dispose();
    _addr1.dispose();
    _city.dispose();
    _postcode.dispose();
    super.dispose();
  }

  final _plans = const [
    [24, 29, 'Most Popular'],
    [36, 25, 'Best Value'],
    [48, 22, 'Maximum Savings'],
  ];
  final _slots = const ['Morning · 8AM–12PM', 'Afternoon · 12PM–4PM', 'Evening · 4PM–7PM'];

  bool get isRent => _mode == 'rent';
  int get monthly => _plans[_plan][1] as int;

  @override
  Widget build(BuildContext context) {
    if (!_modeInit) {
      final arg = ModalRoute.of(context)?.settings.arguments;
      if (arg is String) _mode = arg;
      _modeInit = true;
    }
    final wide = MediaQuery.of(context).size.width > 900;
    return StoreScaffold(active: '/cart', showFooter: false, slivers: [
      SliverToBoxAdapter(
        child: Band(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _stepper(),
          const SizedBox(height: 24),
          Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: wide ? 3 : 0, child: _panel()),
            SizedBox(width: wide ? 22 : 0, height: wide ? 0 : 22),
            Expanded(flex: wide ? 2 : 0, child: _summary()),
          ]),
        ])),
      ),
    ]);
  }

  Widget _stepper() {
    final labels = ['Cart', 'Information', isRent ? 'Rental Plan' : 'Delivery', 'Payment', 'Review'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: List.generate(labels.length, (i) {
        final n = i + 1;
        final done = n < _step;
        final active = n == _step;
        return Row(children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(color: done ? AppColors.blue700 : active ? AppColors.blue700 : Colors.white, shape: BoxShape.circle, border: Border.all(color: done || active ? AppColors.blue700 : AppColors.line, width: 1.5)),
            child: done ? const Icon(Icons.check, size: 15, color: Colors.white) : Center(child: Text('$n', style: AppText.muted.copyWith(color: active ? Colors.white : AppColors.ink400, fontWeight: FontWeight.w700))),
          ),
          const SizedBox(width: 8),
          Text(labels[i], style: AppText.label.copyWith(color: active ? AppColors.ink900 : AppColors.ink400)),
          if (i < labels.length - 1) Container(width: 28, height: 1.5, margin: const EdgeInsets.symmetric(horizontal: 10), color: done ? AppColors.blue700 : AppColors.line),
        ]);
      })),
    );
  }

  Widget _card({required String title, Widget? action, required Widget child}) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Text(title, style: AppText.h3), const Spacer(), if (action != null) action]),
          const SizedBox(height: 16),
          child,
        ]),
      );

  Widget _panel() {
    switch (_step) {
      case 3:
        return isRent ? _rentPanel() : _deliveryPanel();
      case 4:
        return _paymentPanel();
      case 5:
        return _reviewPanel();
      default:
        return _infoPanel();
    }
  }

  Widget _field(String label, TextEditingController c, {String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: AppText.label),
          const SizedBox(height: 7),
          TextField(controller: c, decoration: InputDecoration(hintText: hint ?? label)),
        ]),
      );

  Widget _infoPanel() {
    final loggedIn = AppState.instance.user != null;
    return Column(children: [
      if (!loggedIn)
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.blue200)),
          child: Row(children: [
            const Icon(Icons.info_outline, size: 16, color: AppColors.blue700),
            const SizedBox(width: 10),
            Expanded(child: Text('Sign in to auto-fill your details.', style: AppText.muted.copyWith(color: AppColors.blue700))),
            TextButton(onPressed: () => Navigator.of(context).pushNamed('/login'), child: const Text('Sign in')),
          ]),
        ),
      _card(title: 'Contact Information', child: Column(children: [
        _field('Full Name', _name),
        _field('Email Address', _email),
        _phoneField(),
      ])),
      _card(title: 'Delivery Address', child: Column(children: [
        _field('Address Line 1', _addr1),
        Row(children: [Expanded(child: _field('City', _city)), const SizedBox(width: 12), Expanded(child: _field('Postcode / Area', _postcode))]),
      ])),
      _nav(backLabel: 'Back to Cart', onBack: () => Navigator.of(context).pushNamed('/cart'), nextLabel: 'Continue', onNext: () => setState(() => _step = 3)),
    ]);
  }

  Widget _phoneField() => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Phone Number', style: AppText.label),
          const SizedBox(height: 7),
          Row(children: [
            SizedBox(
              width: 90,
              child: TextField(
                controller: _countryCode,
                decoration: const InputDecoration(hintText: '+971'),
                keyboardType: TextInputType.phone,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _phone,
                decoration: const InputDecoration(hintText: '50 123 4567'),
                keyboardType: TextInputType.phone,
              ),
            ),
          ]),
        ]),
      );

  Widget _deliveryPanel() {
    return Column(children: [
      _card(title: 'Delivery Address', action: TextButton(onPressed: () => setState(() => _step = 2), child: const Text('Edit')), child: Align(
        alignment: Alignment.centerLeft,
        child: Text('${_name.text}\n${[_addr1.text, _city.text, _postcode.text].where((s) => s.isNotEmpty).join(', ')}', style: AppText.body.copyWith(height: 1.6)),
      )),
      _card(title: 'Installation Details', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Preferred Time Slot', style: AppText.label),
        const SizedBox(height: 10),
        Wrap(spacing: 10, runSpacing: 10, children: List.generate(_slots.length, (i) {
          final on = _slot == i;
          return GestureDetector(
            onTap: () => setState(() => _slot = i),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(color: on ? AppColors.blue50 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 1.5 : 1)),
              child: Text(_slots[i], style: AppText.label.copyWith(color: on ? AppColors.blue700 : AppColors.ink700)),
            ),
          );
        })),
      ])),
      _nav(backLabel: 'Back', onBack: () => setState(() => _step = 2), nextLabel: 'Continue to Payment', onNext: () => setState(() => _step = 4)),
    ]);
  }

  Widget _rentPanel() {
    return Column(children: [
      _card(title: 'Choose Your Rental Plan', child: Column(children: List.generate(_plans.length, (i) {
        final on = _plan == i;
        final p = _plans[i];
        return GestureDetector(
          onTap: () => setState(() => _plan = i),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: on ? AppColors.blue50 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 1.5 : 1)),
            child: Row(children: [
              Icon(on ? Icons.radio_button_checked : Icons.radio_button_off, color: on ? AppColors.blue700 : AppColors.ink300, size: 20),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${p[0]} Months', style: AppText.h3.copyWith(fontSize: 15)), Text(p[2] as String, style: AppText.muted)])),
              Text('£${p[1]} / mo', style: AppText.price.copyWith(fontSize: 17)),
            ]),
          ),
        );
      }))),
      _card(title: "What's Included", child: Column(children: ['Free installation', 'Regular maintenance', 'Filter replacements', '24/7 customer support', '2 years warranty'].map((t) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [const Icon(Icons.check, size: 18, color: AppColors.blue600), const SizedBox(width: 10), Text(t, style: AppText.body)]))).toList())),
      _nav(backLabel: 'Back', onBack: () => setState(() => _step = 2), nextLabel: 'Continue to Payment', onNext: () => setState(() => _step = 4)),
    ]);
  }

  Widget _paymentPanel() {
    final methods = [
      ['Credit / Debit Card', Icons.credit_card],
      ['Apple Pay', Icons.apple],
      ['Google Pay', Icons.account_balance_wallet_outlined],
    ];
    return Column(children: [
      _card(title: 'Payment Method', child: Column(children: [
        ...List.generate(methods.length, (i) {
          final on = _pay == i;
          return Column(children: [
            GestureDetector(
              onTap: () => setState(() => _pay = i),
              child: Container(
                padding: const EdgeInsets.all(14),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(color: on ? AppColors.blue50 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 1.5 : 1)),
                child: Row(children: [
                  Icon(on ? Icons.radio_button_checked : Icons.radio_button_off, color: on ? AppColors.blue700 : AppColors.ink300, size: 20),
                  const SizedBox(width: 12),
                  Icon(methods[i][1] as IconData, size: 20, color: AppColors.ink700),
                  const SizedBox(width: 10),
                  Text(methods[i][0] as String, style: AppText.label),
                ]),
              ),
            ),
            if (on && i == 0)
              Padding(padding: const EdgeInsets.only(bottom: 10), child: Column(children: [
                TextField(decoration: const InputDecoration(hintText: '1234 1234 1234 1234')),
                const SizedBox(height: 10),
                Row(children: const [Expanded(child: TextField(decoration: InputDecoration(hintText: 'MM / YY'))), SizedBox(width: 10), Expanded(child: TextField(decoration: InputDecoration(hintText: 'CVC')))]),
              ])),
          ]);
        }),
      ])),
      _nav(backLabel: 'Back', onBack: () => setState(() => _step = 3), nextLabel: 'Continue to Review', onNext: () => setState(() => _step = 5)),
    ]);
  }

  Widget _reviewPanel() {
    Widget rev(String h, String body, int editStep) => _card(title: h, action: TextButton(onPressed: () => setState(() => _step = editStep), child: const Text('Edit')), child: Align(alignment: Alignment.centerLeft, child: Text(body, style: AppText.body.copyWith(height: 1.6))));
    return Column(children: [
      rev('Contact', '${_name.text}\n${_email.text}\n${_countryCode.text} ${_phone.text}', 2),
      rev('Delivery Address', '${_name.text}\n${[_addr1.text, _city.text, _postcode.text].where((s) => s.isNotEmpty).join(', ')}', 2),
      if (!isRent) rev('Installation', 'Time: ${_slots[_slot]}', 3) else rev('Rental Plan', '${_plans[_plan][0]} Months · £$monthly / month · Cancel anytime', 3),
      rev('Payment Method', 'Visa •••• 4242', 4),
      _nav(backLabel: 'Back to Payment', onBack: () => setState(() => _step = 4)),
    ]);
  }

  Widget _nav({required String backLabel, required VoidCallback onBack, String? nextLabel, VoidCallback? onNext}) {
    return Row(children: [
      TextButton.icon(onPressed: onBack, icon: const Icon(Icons.arrow_back, size: 16), label: Text(backLabel)),
      const Spacer(),
      if (nextLabel != null) PwtButton(nextLabel, icon: Icons.arrow_forward, onPressed: onNext),
    ]);
  }

  Widget _summary() {
    final s = AppState.instance;
    final onReview = _step == 5;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text('Order Summary', style: AppText.h3), const Spacer(), TextButton(onPressed: () => Navigator.of(context).pushNamed('/cart'), child: const Text('Edit Cart'))]),
        const SizedBox(height: 8),
        ...s.cart.map((l) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: [
                Container(width: 46, height: 46, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.all(6), child: Image.asset(l.product.image, fit: BoxFit.contain)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l.product.name, style: AppText.label), Text('${l.mode == 'rent' ? 'Rent' : 'Buy'} · Qty ${l.qty}', style: AppText.muted)])),
              ]),
            )),
        const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(height: 1, color: AppColors.line)),
        if (!isRent) ...[
          _r('Subtotal', money(s.subtotal)),
          _r('Delivery', 'FREE', green: true),
          _r('Installation', 'FREE', green: true),
          _r('VAT (20%)', money(s.vat)),
          const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(height: 1, color: AppColors.line)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total', style: AppText.h3), Text(money(s.total), style: AppText.h2.copyWith(fontSize: 20))]),
        ] else ...[
          _r('Monthly Fee', '£$monthly / month'),
          _r('Delivery', 'FREE', green: true),
          _r('Installation', 'FREE', green: true),
          _r('VAT (20%)', 'Included'),
          const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(height: 1, color: AppColors.line)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total', style: AppText.h3), Text('£$monthly / mo', style: AppText.h2.copyWith(fontSize: 20))]),
        ],
        const SizedBox(height: 16),
        if (onReview)
          PwtButton('Place Order Securely', icon: Icons.lock_outline, fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/confirmation', arguments: 'individual'))
        else
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm)),
            child: Row(children: [const Icon(Icons.lock_outline, size: 15, color: AppColors.ink500), const SizedBox(width: 8), Text('Safe & Secure Checkout', style: AppText.muted)]),
          ),
      ]),
    );
  }

  Widget _r(String k, String v, {bool green = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(k, style: AppText.body.copyWith(color: AppColors.ink600)), Text(v, style: AppText.label.copyWith(color: green ? AppColors.green600 : AppColors.ink900))]),
      );
}
