import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'dashboard_shell.dart';
import '../../Models/address_model.dart';
import '../../Backend/Addresses/get_addresses.dart';
import '../../Backend/Addresses/create_address.dart';
import '../../Backend/Addresses/update_address.dart';
import '../../Backend/Addresses/delete_address.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late bool isCompany;
  int _seq = 1;
  bool _loadingAddresses = false;
  String? _addressError;
  List<AddressModel> _addresses = [];
  late List<PayCard> _cards;

  @override
  void initState() {
    super.initState();
    isCompany = AppState.instance.isCompany;
    _cards = [
      PayCard(id: 1, brand: 'VISA', last4: '4242', exp: '08 / 27', isDefault: true),
      PayCard(id: 2, brand: 'MC', last4: '8810', exp: '02 / 26'),
    ];
    _loadAddresses();
  }

  Future<void> _loadAddresses() async {
    setState(() { _loadingAddresses = true; _addressError = null; });
    final result = await getAddresses();
    if (!mounted) return;
    if (result.success && result.data != null) {
      setState(() { _addresses = result.data!; _loadingAddresses = false; });
    } else {
      setState(() { _loadingAddresses = false; _addressError = result.message ?? 'Failed to load addresses.'; });
    }
  }

  String _addressFull(AddressModel a) => [a.line1, a.line2, a.city, a.postcode, a.country?.name]
      .where((s) => s != null && s!.isNotEmpty)
      .cast<String>()
      .join(', ');

  String _memberSince(String? createdAt) {
    if (createdAt == null) return '';
    try {
      final dt = DateTime.parse(createdAt);
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return 'Member since ${months[dt.month - 1]} ${dt.year}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = AppState.instance.user;
    final wide = MediaQuery.of(context).size.width > 880;
    final nameParts = (u?.name ?? '').trim().split(RegExp(r'\s+'));
    final firstName = nameParts.first;
    final lastName = nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '';
    final code = u?.phoneCountryCode ?? '';
    final number = u?.phone ?? '';
    final phoneDisplay = number.isEmpty ? '' : (code.isNotEmpty && !number.startsWith(code)) ? '$code $number' : number;

    return DashboardShell(
      active: 'profile',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const DashHeader(title: 'Profile', subtitle: 'Manage your information, addresses and payment details'),
        Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: wide ? 1 : 0, child: Column(children: [
            DashCard(title: 'Personal Information', child: Column(children: [
              Row(children: [
                CircleAvatar(radius: 30, backgroundColor: AppColors.blue100, child: Text(u?.initials ?? 'PW', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: AppColors.blue800))),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(isCompany ? (u?.companyName ?? '') : (u?.name ?? ''), style: AppText.h3.copyWith(fontSize: 16)),
                  const SizedBox(height: 2),
                  Text(_memberSince(u?.createdAt), style: AppText.muted),
                ])),
                PwtButton('Change photo', variant: PwtBtn.outline, onPressed: () {}),
              ]),
              const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Divider(height: 1, color: AppColors.line)),
              Row(children: [
                Expanded(child: _field('First name', firstName.isEmpty ? '' : firstName)),
                const SizedBox(width: 12),
                Expanded(child: _field('Last name', lastName)),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _field('Email', u?.email ?? '')),
                const SizedBox(width: 12),
                Expanded(child: _field('Phone', phoneDisplay)),
              ]),
              const SizedBox(height: 16),
              Align(alignment: Alignment.centerLeft, child: PwtButton('Save Changes', onPressed: () => _toast('Changes saved'))),
            ])),
            const SizedBox(height: 16),
            DashCard(
              title: isCompany ? 'Address' : 'Addresses',
              action: isCompany ? null : PwtButton('Add new address', variant: PwtBtn.outline, icon: Icons.add, onPressed: () => _addressSheet()),
              child: _loadingAddresses
                  ? const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Center(child: CircularProgressIndicator(strokeWidth: 2)))
                  : _addressError != null
                      ? Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_addressError!, style: AppText.muted.copyWith(color: AppColors.danger)))
                      : _addresses.isEmpty
                          ? Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('No addresses saved.', style: AppText.muted))
                          : Column(children: _addresses.map(_addressItem).toList()),
            ),
          ])),
          SizedBox(width: wide ? 18 : 0, height: wide ? 0 : 16),
          Expanded(flex: wide ? 1 : 0, child: DashCard(
            title: 'Payment Details',
            action: PwtButton('Add card', variant: PwtBtn.outline, icon: Icons.add, onPressed: () => _cardSheet()),
            child: Column(children: _cards.isEmpty
                ? [Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('No saved cards. Add one with "Add card".', style: AppText.muted))]
                : _cards.map(_cardItem).toList()),
          )),
        ]),
      ]),
    );
  }

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, backgroundColor: AppColors.ink900));

  Widget _field(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: AppText.label),
        const SizedBox(height: 7),
        TextField(controller: TextEditingController(text: value), decoration: const InputDecoration()),
      ]);

  Widget _addressItem(AddressModel a) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.line)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.location_on_outlined, size: 20, color: AppColors.blue700),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(a.label ?? '', style: AppText.label),
              if (a.isDefault == true) ...[const SizedBox(width: 8), StatusBadge.green('Default')],
            ]),
            const SizedBox(height: 3),
            Text(_addressFull(a), style: AppText.muted),
          ])),
          IconButton(icon: const Icon(Icons.edit_outlined, size: 18, color: AppColors.ink400), onPressed: () => _addressSheet(edit: a)),
          if (!isCompany) IconButton(
            icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.danger),
            onPressed: () => _deleteAddress(a),
          ),
        ]),
      );

  void _deleteAddress(AddressModel a) {
    if (a.id == null) return;
    deleteAddress(a.id!).then((result) {
      if (!mounted) return;
      if (result.success) _loadAddresses();
    });
  }

  Widget _cardItem(PayCard c) {
    final grad = c.brand == 'VISA' ? const [Color(0xFF1A1F71), Color(0xFF2B3A8C)] : c.brand == 'MC' ? const [Color(0xFFEB5B2E), Color(0xFFCF4521)] : const [Color(0xFF334155), Color(0xFF1E293B)];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.line)),
      child: Row(children: [
        Container(width: 48, height: 32, alignment: Alignment.center, decoration: BoxDecoration(gradient: LinearGradient(colors: grad), borderRadius: BorderRadius.circular(6)), child: Text(c.brand, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${c.brand == 'VISA' ? 'Visa' : c.brand == 'MC' ? 'Mastercard' : 'Card'} •••• ${c.last4}', style: AppText.label),
          Text('Expires ${c.exp}${c.isDefault ? ' · Default' : ''}', style: AppText.muted),
        ])),
        if (c.isDefault) StatusBadge.green('Default') else TextButton(onPressed: () => setState(() {
              for (final x in _cards) x.isDefault = false;
              c.isDefault = true;
            }), child: const Text('Make default')),
        IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.danger), onPressed: () => setState(() => _cards.remove(c))),
      ]),
    );
  }

  void _addressSheet({AddressModel? edit}) {
    final label = TextEditingController(text: edit?.label ?? '');
    final l1    = TextEditingController(text: edit?.line1 ?? '');
    final l2    = TextEditingController(text: edit?.line2 ?? '');
    final city  = TextEditingController(text: edit?.city ?? '');
    final pc    = TextEditingController(text: edit?.postcode ?? '');
    bool def = edit?.isDefault ?? false;
    _sheet(
      title: edit == null ? 'Add new address' : 'Edit address',
      fields: [
        _sheetField('Label', label, hint: 'e.g. Home, Office'),
        _sheetField('Address line 1', l1),
        _sheetField('Address line 2 (optional)', l2),
        Row(children: [Expanded(child: _sheetField('City', city)), const SizedBox(width: 12), Expanded(child: _sheetField('Postcode', pc))]),
        if (!isCompany) StatefulBuilder(builder: (c, set) => Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [Expanded(child: Text('Set as default address', style: AppText.label)), PwtToggle(value: def, onChanged: (v) => set(() => def = v))]))),
      ],
      saveLabel: edit == null ? 'Save address' : 'Save changes',
      onSave: () {
        if (edit != null && edit.id != null) {
          updateAddress(
            addressId: edit.id!,
            label: label.text.trim(),
            line1: l1.text.trim(),
            line2: l2.text.trim().isEmpty ? null : l2.text.trim(),
            city: city.text.trim(),
            postcode: pc.text.trim().isEmpty ? null : pc.text.trim(),
            isDefault: def,
          ).then((_) { if (mounted) _loadAddresses(); });
        } else {
          createAddress(
            label: label.text.trim().isEmpty ? 'Address' : label.text.trim(),
            line1: l1.text.trim(),
            line2: l2.text.trim().isEmpty ? null : l2.text.trim(),
            city: city.text.trim(),
            postcode: pc.text.trim().isEmpty ? null : pc.text.trim(),
            isDefault: def,
          ).then((_) { if (mounted) _loadAddresses(); });
        }
      },
    );
  }

  void _cardSheet() {
    final num = TextEditingController();
    final exp = TextEditingController();
    bool def = false;
    _sheet(
      title: 'Add card',
      fields: [
        _sheetField('Card number', num, hint: '1234 1234 1234 1234'),
        Row(children: [Expanded(child: _sheetField('Expiry', exp, hint: 'MM / YY')), const SizedBox(width: 12), Expanded(child: _sheetField('CVC', TextEditingController(), hint: '123'))]),
        StatefulBuilder(builder: (c, set) => Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [Expanded(child: Text('Set as default card', style: AppText.label)), PwtToggle(value: def, onChanged: (v) => set(() => def = v))]))),
      ],
      saveLabel: 'Add card',
      onSave: () => setState(() {
        final digits = num.text.replaceAll(' ', '');
        final last4 = digits.length >= 4 ? digits.substring(digits.length - 4) : '0000';
        final brand = digits.startsWith('4') ? 'VISA' : digits.startsWith('5') ? 'MC' : 'CARD';
        if (def) for (final c in _cards) c.isDefault = false;
        _cards.add(PayCard(id: _seq++, brand: brand, last4: last4, exp: exp.text.trim().isEmpty ? '—' : exp.text.trim(), isDefault: def));
      }),
    );
  }

  void _sheet({required String title, required List<Widget> fields, required String saveLabel, required VoidCallback onSave}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [Expanded(child: Text(title, style: AppText.h2.copyWith(fontSize: 19))), IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx))]),
            const SizedBox(height: 12),
            ...fields.map((f) => Padding(padding: const EdgeInsets.only(bottom: 14), child: f)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: PwtButton('Cancel', variant: PwtBtn.outline, fullWidth: true, onPressed: () => Navigator.pop(ctx))),
              const SizedBox(width: 12),
              Expanded(child: PwtButton(saveLabel, fullWidth: true, onPressed: () { onSave(); Navigator.pop(ctx); })),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _sheetField(String label, TextEditingController c, {String? hint}) => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text(label, style: AppText.label),
        const SizedBox(height: 7),
        TextField(controller: c, decoration: InputDecoration(hintText: hint ?? label)),
      ]);
}
