import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../models/orders.dart';
import '../widgets/dash_kit.dart';

/// Individual → Orders. All orders (ongoing + completed + cancelled).
/// Rows open a detail page: ongoing → tracking, completed → full info.
class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  int _tab = 0;
  static const _tabs = ['All Orders', 'Ongoing', 'Completed', 'Cancelled'];

  bool _match(CustomerOrder o) {
    switch (_tab) {
      case 1:
        return o.state == OrderState.ongoing;
      case 2:
        return o.state == OrderState.completed;
      case 3:
        return o.state == OrderState.cancelled;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = kCustomerOrders.where(_match).toList();
    return DashScaffold(
      active: 'orders',
      isCompany: false,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashCrumb(const ['Dashboard', 'My Orders'], routes: const ['/dashboard', null]),
        const SizedBox(height: 6),
        PageHead(
          title: 'My Orders',
          subtitle: 'Track and manage all your orders in one place',
          action: NewOrderButton(label: 'New Order', onTap: () => Navigator.of(context).pushNamed('/shop')),
        ),
        // summary strip — Total Orders feature tile + supporting KPIs
        KpiRow(cards: [
          KpiFeatureCard(
            label: 'Total Orders',
            value: '12',
            link: 'View all orders',
            image: 'assets/images/order.png',
            onLink: () => setState(() => _tab = 0),
          ),
          const KpiCard(label: 'Delivered', value: '9', sub: 'Completed orders', numSize: 30),
          const KpiCard(label: 'Processing', value: '2', sub: 'In progress', numSize: 30),
          const KpiCard(label: 'Total Spent', value: '£3,510', sub: 'Lifetime value', numSize: 30),
        ]),
        const SizedBox(height: 18),
        // segmented tabs (d-tabs)
        Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(color: const Color(0xFFEEF2F9), borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisSize: MainAxisSize.min, children: List.generate(_tabs.length, (i) {
            final on = _tab == i;
            return GestureDetector(
              onTap: () => setState(() => _tab = i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                margin: EdgeInsets.only(right: i < _tabs.length - 1 ? 6 : 0),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
                decoration: BoxDecoration(
                  color: on ? Colors.white : Colors.transparent,
                  borderRadius: BorderRadius.circular(9),
                  boxShadow: on ? [BoxShadow(color: const Color(0xFF0F1E50).withOpacity(.08), blurRadius: 6, offset: const Offset(0, 2))] : null,
                ),
                child: Text(_tabs[i], style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: on ? AppColors.blue700 : AppColors.ink500)),
              ),
            );
          })),
        ),
        const SizedBox(height: 20),
        DCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const DCardHead('Order History'),
            if (rows.isEmpty)
              Padding(padding: const EdgeInsets.symmetric(vertical: 28), child: Center(child: Text('No orders in this category.', style: const TextStyle(fontSize: 13.5, color: AppColors.ink500))))
            else
              _table(rows),
          ]),
        ),
      ]),
    );
  }

  // responsive table; rows clickable → detail
  Widget _table(List<CustomerOrder> rows) {
    return LayoutBuilder(builder: (context, c) {
      if (c.maxWidth < 720) {
        return Column(children: rows.map((o) => _mobileCard(context, o)).toList());
      }
      const minW = 900.0;
      final table = SizedBox(
        width: c.maxWidth < minW ? minW : c.maxWidth,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Row(children: const [
              Expanded(flex: 3, child: _Th('PRODUCT')),
              Expanded(flex: 2, child: _Th('ORDER ID')),
              Expanded(flex: 2, child: _Th('DATE')),
              Expanded(flex: 1, child: _Th('TOTAL')),
              Expanded(flex: 2, child: _Th('STATUS')),
              SizedBox(width: 170, child: _Th('')),
            ]),
          ),
          Container(height: 1, color: AppColors.line),
          ...rows.map((o) => _dataRow(context, o)),
        ]),
      );
      return c.maxWidth < minW ? SingleChildScrollView(scrollDirection: Axis.horizontal, child: table) : table;
    });
  }

  Widget _dataRow(BuildContext context, CustomerOrder o) {
    final ongoing = o.state == OrderState.ongoing;
    return InkWell(
      onTap: () => Navigator.of(context).pushNamed('/orderDetail', arguments: o),
      child: Container(
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.line))),
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Row(children: [
          Expanded(flex: 3, child: ProdCellD(image: 'assets/images/${o.image}', name: o.name, sub: o.sub)),
          Expanded(flex: 2, child: Text(o.id, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink900))),
          Expanded(flex: 2, child: Text(o.date, style: const TextStyle(fontSize: 14, color: AppColors.ink700))),
          Expanded(flex: 1, child: Text(o.total, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink900))),
          Expanded(flex: 2, child: Align(alignment: Alignment.centerLeft, child: StBadge(o.status))),
          SizedBox(width: 170, child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            DBtn(ongoing ? 'Track' : 'Details', kind: DBtnKind.outline, small: true, onTap: () => Navigator.of(context).pushNamed('/orderDetail', arguments: o)),
            const SizedBox(width: 8),
            DBtn('Invoice', kind: DBtnKind.ghost, small: true, onTap: () {}),
          ])),
        ]),
      ),
    );
  }

  Widget _mobileCard(BuildContext context, CustomerOrder o) {
    final ongoing = o.state == OrderState.ongoing;
    return InkWell(
      onTap: () => Navigator.of(context).pushNamed('/orderDetail', arguments: o),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: ProdCellD(image: 'assets/images/${o.image}', name: o.name, sub: o.sub)),
            StBadge(o.status),
          ]),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${o.id} · ${o.date}', style: const TextStyle(fontSize: 12.5, color: AppColors.ink500)),
            Text(o.total, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink900)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            DBtn(ongoing ? 'Track' : 'Details', kind: DBtnKind.outline, small: true, onTap: () => Navigator.of(context).pushNamed('/orderDetail', arguments: o)),
            const SizedBox(width: 8),
            DBtn('Invoice', kind: DBtnKind.ghost, small: true, onTap: () {}),
          ]),
        ]),
      ),
    );
  }
}

class _Th extends StatelessWidget {
  final String t;
  const _Th(this.t);
  @override
  Widget build(BuildContext context) => Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.4, color: AppColors.ink400));
}

/// ============================================================
/// Order detail — branches on order state.
/// ============================================================
class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final o = ModalRoute.of(context)?.settings.arguments as CustomerOrder?;
    if (o == null) {
      return DashScaffold(active: 'orders', isCompany: false, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const PageHead(title: 'Order', subtitle: 'Order not found'),
        DCard(child: Column(children: [
          const SizedBox(height: 10),
          const Text('This order could not be found.', style: TextStyle(fontSize: 14, color: AppColors.ink500)),
          const SizedBox(height: 16),
          DBtn('Back to Orders', onTap: () => Navigator.of(context).pushReplacementNamed('/orders')),
          const SizedBox(height: 10),
        ])),
      ]));
    }
    final ongoing = o.state == OrderState.ongoing;
    return DashScaffold(
      active: 'orders',
      isCompany: false,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashCrumb(['Dashboard', 'My Orders', o.id], routes: const ['/dashboard', '/orders', null]),
        const SizedBox(height: 6),
        PageHead(
          title: 'Order ${o.id}',
          subtitle: '${ongoing ? 'Placed' : o.state == OrderState.cancelled ? 'Placed' : 'Completed'} · ${o.date}',
          action: DBtn('Back to Orders', kind: DBtnKind.outline, icon: Icons.arrow_back, onTap: () => Navigator.of(context).pushReplacementNamed('/orders')),
        ),
        LayoutBuilder(builder: (context, c) {
          final wide = c.maxWidth > 1000;
          final main = ongoing ? _ongoingMain(context, o) : _completedMain(context, o);
          final side = ongoing ? _ongoingSide(context, o) : _completedSide(context, o);
          if (wide) {
            return IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(flex: 16, child: main),
              const SizedBox(width: 18),
              Expanded(flex: 10, child: side),
            ]));
          }
          return Column(children: [main, const SizedBox(height: 18), side]);
        }),
      ]),
    );
  }

  // ---------------- ONGOING ----------------
  Widget _ongoingMain(BuildContext context, CustomerOrder o) {
    return Column(children: [
      DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DCardHead('Tracking · ${o.id}', trailing: StBadge(o.status)),
        DashTimeline(o.tracking.map((e) => TlStep(e.title, e.sub, done: e.done, pending: e.pending)).toList()),
      ])),
      const SizedBox(height: 18),
      _itemsCard(o),
    ]);
  }

  Widget _ongoingSide(BuildContext context, CustomerOrder o) {
    return Column(children: [
      DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const DCardHead('Delivery'),
        _kv('Recipient', o.deliveryName),
        _kv('Address', o.deliveryAddress),
        _kv('Estimated', o.etaSlot),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFFEEF4FF), borderRadius: BorderRadius.circular(11)),
          child: Row(children: const [
            Icon(Icons.local_shipping_outlined, size: 17, color: AppColors.blue700),
            SizedBox(width: 9),
            Expanded(child: Text('Free installation included on arrival.', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.blue700))),
          ]),
        ),
      ])),
      const SizedBox(height: 18),
      _summaryCard(o),
      const SizedBox(height: 18),
      _helpCard(context),
    ]);
  }

  // ---------------- COMPLETED / CANCELLED ----------------
  Widget _completedMain(BuildContext context, CustomerOrder o) {
    final cancelled = o.state == OrderState.cancelled;
    return Column(children: [
      DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(color: cancelled ? const Color(0xFFEEF2F9) : const Color(0xFFE7F7EF), borderRadius: BorderRadius.circular(12)),
            child: Icon(cancelled ? Icons.cancel_outlined : Icons.check_circle_outline, color: cancelled ? AppColors.ink500 : AppColors.green600, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(cancelled ? 'Order cancelled' : 'Order completed', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.ink900)),
            const SizedBox(height: 3),
            Text(cancelled ? 'Cancelled on ${o.cancelledOn}' : 'Installed ${o.installedOn}', style: const TextStyle(fontSize: 13, color: AppColors.ink500)),
          ])),
          StBadge(o.status),
        ]),
        if (cancelled && o.refund != null) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: const Color(0xFFE7F7EF), borderRadius: BorderRadius.circular(11)),
            child: Row(children: [
              const Icon(Icons.replay, size: 17, color: AppColors.green600),
              const SizedBox(width: 9),
              Expanded(child: Text(o.refund!, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.green700))),
            ]),
          ),
        ],
      ])),
      const SizedBox(height: 18),
      _itemsCard(o),
      if (!cancelled) ...[
        const SizedBox(height: 18),
        DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const DCardHead('Fulfilment details'),
          _kv('Delivered on', o.deliveredOn ?? '—'),
          _kv('Installed on', o.installedOn ?? '—'),
          _kv('Technician', o.technician ?? '—'),
          _kv('Warranty until', o.warrantyUntil ?? '—'),
        ])),
      ],
    ]);
  }

  Widget _completedSide(BuildContext context, CustomerOrder o) {
    return Column(children: [
      _summaryCard(o),
      const SizedBox(height: 18),
      DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const DCardHead('Delivery address'),
        _kv('Recipient', o.deliveryName),
        _kv('Address', o.deliveryAddress),
        const SizedBox(height: 6),
        const DCardHead('Payment'),
        Row(children: [
          Container(width: 44, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: AppColors.ink900, borderRadius: BorderRadius.circular(6)), child: const Text('VISA', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 9))),
          const SizedBox(width: 10),
          Text(o.paymentLabel, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.ink900)),
        ]),
      ])),
      const SizedBox(height: 18),
      DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const DCardHead('Documents'),
        _docRow(o.invoiceId ?? 'Invoice'),
        const SizedBox(height: 12),
        DBtn('Reorder', kind: DBtnKind.outline, fullWidth: true, onTap: () => Navigator.of(context).pushNamed('/shop')),
      ])),
    ]);
  }

  // ---------------- shared pieces ----------------
  Widget _itemsCard(CustomerOrder o) {
    return DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const DCardHead('Items'),
      ...o.items.map((it) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: const BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(11)), gradient: RadialGradient(center: Alignment(0, -0.4), radius: 0.7, colors: [Color(0xFFF6F9FF), Color(0xFFE6EEF9)])),
                padding: const EdgeInsets.all(7),
                child: Image.asset('assets/images/${it.image}', fit: BoxFit.contain),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(it.name, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
                const SizedBox(height: 2),
                Text('${it.sub} · ${it.mode} · Qty ${it.qty}', style: const TextStyle(fontSize: 12.5, color: AppColors.ink500)),
              ])),
              Text(it.price, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
            ]),
          )),
    ]));
  }

  Widget _summaryCard(CustomerOrder o) {
    return DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const DCardHead('Order summary'),
      if (o.subtotal.isNotEmpty) _row('Subtotal', o.subtotal),
      _row('Delivery', 'Free', green: true),
      _row('Installation', 'Free', green: true),
      if (o.vat.isNotEmpty) _row('VAT (20%)', o.vat),
      const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(height: 1, color: AppColors.line)),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Total', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.ink900)),
        Text(o.total, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.ink900)),
      ]),
    ]));
  }

  Widget _helpCard(BuildContext context) {
    return DCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const DCardHead('Need help?'),
      Row(children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFEEF4FF), borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.chat_bubble_outline, color: AppColors.blue700, size: 20)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('Question about this order?', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
          SizedBox(height: 2),
          Text('Our team responds within hours.', style: TextStyle(fontSize: 12.5, color: AppColors.ink500)),
        ])),
      ]),
      const SizedBox(height: 14),
      DBtn('Contact Support', fullWidth: true, onTap: () => Navigator.of(context).pushNamed('/support')),
    ]));
  }

  Widget _docRow(String name) => Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.description_outlined, size: 20, color: AppColors.blue700)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
          const Text('PDF invoice', style: TextStyle(fontSize: 12, color: AppColors.ink500)),
        ])),
        DBtn('Download', kind: DBtnKind.ghost, small: true, onTap: () {}),
      ]);

  Widget _kv(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 96, child: Text(k, style: const TextStyle(fontSize: 13, color: AppColors.ink500))),
          Expanded(child: Text(v, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.ink900))),
        ]),
      );

  Widget _row(String k, String v, {bool green = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: const TextStyle(fontSize: 13.5, color: AppColors.ink600)),
          Text(v, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: green ? AppColors.green600 : AppColors.ink900)),
        ]),
      );
}
