import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

class ConfirmationScreen extends StatelessWidget {
  const ConfirmationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final view = (ModalRoute.of(context)?.settings.arguments as String?) ?? 'individual';
    final company = view == 'company';
    final s = AppState.instance;
    return StoreScaffold(active: '/', showFooter: false, slivers: [
      SliverToBoxAdapter(
        child: Band(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 760), child: Column(children: [
          Container(width: 84, height: 84, decoration: const BoxDecoration(color: AppColors.badgeGreenBg, shape: BoxShape.circle), child: const Icon(Icons.check, size: 44, color: AppColors.green600)),
          const SizedBox(height: 18),
          Text(company ? 'Quotation Request Received!' : 'Order Confirmed!', style: AppText.headline(30), textAlign: TextAlign.center),
          const SizedBox(height: 10),
          Text(company
              ? 'Thank you. Your quotation request has been received. Your dedicated account manager will be in touch within 24 hours.'
              : 'Thank you. Your order has been placed successfully. A confirmation email is on its way with all the details.',
              style: AppText.bodyLg.copyWith(height: 1.6), textAlign: TextAlign.center),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.pill)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(company ? 'Reference number  ' : 'Order number  ', style: AppText.muted),
              Text(company ? 'PWT-Q-2026-00231' : 'PWT-2026-04871', style: AppText.label),
              const SizedBox(width: 8),
              const Icon(Icons.copy, size: 15, color: AppColors.ink400),
            ]),
          ),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(AppRadius.lg)),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: Icon(company ? Icons.schedule : Icons.local_shipping_outlined, color: AppColors.blue700)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(company ? 'Your Quote is Being Prepared' : 'Estimated Delivery & Installation', style: AppText.h3.copyWith(fontSize: 15)),
                const SizedBox(height: 3),
                Text(company ? 'Within 24 hours · a dedicated account manager will email your tailored quotation.' : 'Thursday, 4 June 2026 · Morning slot 8:00–12:00 · Free installation included', style: AppText.body.copyWith(color: AppColors.ink600)),
              ])),
            ]),
          ),
          const SizedBox(height: 20),
          // items
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(company ? 'Items Requested' : 'Items Ordered', style: AppText.h3),
              const SizedBox(height: 12),
              ...s.cart.map((l) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(children: [
                      Container(width: 48, height: 48, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.all(6), child: Image.asset(l.product.image, fit: BoxFit.contain)),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l.product.name, style: AppText.label), Text('${l.product.sub} · Qty ${l.qty}', style: AppText.muted)])),
                      Text(l.mode == 'rent' ? '${money(l.lineTotal)}/mo' : money(l.lineTotal), style: AppText.label),
                    ]),
                  )),
              if (!company) ...[
                const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(height: 1, color: AppColors.line)),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total Paid', style: AppText.h3), Text(money(s.total), style: AppText.h2.copyWith(fontSize: 20))]),
              ],
            ]),
          ),
          const SizedBox(height: 22),
          Wrap(spacing: 12, runSpacing: 12, alignment: WrapAlignment.center, children: [
            PwtButton(company ? 'Track Request' : 'Track Order', icon: Icons.location_on_outlined, onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/dashboard', (r) => false)),
            PwtButton('Go to Dashboard', variant: PwtBtn.outline, icon: Icons.grid_view_rounded, onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/dashboard', (r) => false)),
            PwtButton('Continue Shopping', variant: PwtBtn.ghost, onPressed: () => Navigator.of(context).pushNamed('/shop')),
          ]),
          const SizedBox(height: 18),
          Text('Need help with your order? Contact our support team or call 0800 123 4567.', style: AppText.muted, textAlign: TextAlign.center),
        ])))),
      ),
    ]);
  }
}
