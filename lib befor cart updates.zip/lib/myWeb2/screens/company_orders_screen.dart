import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../widgets/dash_kit.dart';

class CompanyOrdersScreen extends StatefulWidget {
  const CompanyOrdersScreen({super.key});
  @override
  State<CompanyOrdersScreen> createState() => _CompanyOrdersScreenState();
}

class _OrderRow {
  final String img, name, sub, po, qty, value, added;
  String status;
  bool agree;
  _OrderRow(this.img, this.name, this.sub, this.po, this.qty, this.value, this.added, this.status, {this.agree = false});
}

class _CompanyOrdersScreenState extends State<CompanyOrdersScreen> {
  final List<_OrderRow> _orders = [
    _OrderRow('s4.png', 'S18 UC Undercounter', '3-tap chilled & sparkling', '#PWT-Q-2026-0207', '12', '£14,900', '03 Jun 2026', 'Quotation sent', agree: true),
    _OrderRow('ct.png', 'PW90-R CT', 'Touchless countertop', '#PWT-B-2026-0188', '40', '£18,400', '28 May 2026', 'Confirmed'),
    _OrderRow('s4.png', 'S4 Sparkling', 'Touch-free sparkling', '#PWT-B-2026-0181', '24', '£21,600', '20 May 2026', 'In production'),
    _OrderRow('pw90.png', 'PW50-R', 'Hot & cold dispenser', '#PWT-B-2026-0174', '18', '£12,420', '14 May 2026', 'Installing'),
    _OrderRow('pw0ctr.png', 'Filter & Cartridge Sets', 'Quarterly resupply', '#PWT-B-2026-0166', '120', '£3,480', '02 May 2026', 'Delivered'),
    _OrderRow('pw50.png', 'PW90-R', 'Touchless floor unit', '#PWT-B-2026-0152', '10', '£8,900', '24 Apr 2026', 'Delivered'),
  ];

  @override
  Widget build(BuildContext context) {
    return DashScaffold(
      active: 'orders',
      isCompany: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min, // FIX: never fill infinite height
        children: [
          DashCrumb(const ['Dashboard', 'Orders'], routes: const ['/companyDashboard', null]),
          const SizedBox(height: 6),
          PageHead(
            title: 'Orders',
            subtitle: 'Your purchase orders and quotations, newest first',
            action: NewOrderButton(label: 'New Bulk Order', onTap: () => Navigator.of(context).pushNamed('/rfq')),
          ),
          // FIX: KpiRow with Wrap — safe inside scroll, no Spacer issues
          const KpiRow(cards: [
            KpiFeatureCard(label: 'Open POs', value: '7', sub: '2 awaiting approval', image: 'assets/images/order.png'),
            KpiCard(label: 'Units on Order', value: '96', sub: 'across 4 sites', numSize: 30),
            KpiCard(label: 'Quotations', value: '3', sub: 'pending review', numSize: 30),
            KpiCard(label: 'Value on Order', value: '£55.9k', sub: 'Net 30 terms', numSize: 30),
          ]),
          const SizedBox(height: 18),
          DCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                DCardHead('Orders',
                    trailing: const Text(
                      'Sorted by date added · newest first',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.ink500),
                    )),
                _ordersTable(),
              ],
            ),
          ),
          const SizedBox(height: 18),
          // FIX: removed IntrinsicHeight — use crossAxisAlignment: start on Row
          LayoutBuilder(builder: (context, c) {
            final wide = c.maxWidth > 1000;
            final left = _scheduleCard();
            final right = _supportCard();
            if (wide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start, // FIX: not stretch
                children: [
                  Expanded(flex: 16, child: left),
                  const SizedBox(width: 18),
                  Expanded(flex: 10, child: right),
                ],
              );
            }
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [left, const SizedBox(height: 18), right],
            );
          }),
        ],
      ),
    );
  }

  static const _cols = [
    _Col('PRODUCT', 300, 3),
    _Col('PO NUMBER', 150, 0),
    _Col('QTY', 60, 0),
    _Col('VALUE', 90, 0),
    _Col('ADDED', 110, 0),
    _Col('STATUS', 140, 0),
    _Col('', 150, 0),
  ];

  Widget _ordersTable() {
    return LayoutBuilder(builder: (context, c) {
      if (c.maxWidth < 720) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: _orders.map(_mobileCard).toList(),
        );
      }
      const minTableW = 980.0;
      final tableW = c.maxWidth < minTableW ? minTableW : c.maxWidth;
      final table = SizedBox(
        width: tableW,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Row(
                children: _cols
                    .map((col) => col.flex > 0
                    ? Expanded(flex: col.flex, child: _th(col.label))
                    : SizedBox(width: col.width, child: _th(col.label)))
                    .toList(),
              ),
            ),
            Container(height: 1, color: AppColors.line),
            ..._orders.map(_dataRow),
          ],
        ),
      );
      if (c.maxWidth < minTableW) {
        return SingleChildScrollView(scrollDirection: Axis.horizontal, child: table);
      }
      return table;
    });
  }

  Widget _th(String t) => Text(t,
      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.4, color: AppColors.ink400));

  Widget _cell(int i, Widget child) {
    final col = _cols[i];
    return col.flex > 0 ? Expanded(flex: col.flex, child: child) : SizedBox(width: col.width, child: child);
  }

  Widget _dataRow(_OrderRow o) {
    return Container(
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.line))),
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        _cell(0, ProdCellD(image: 'assets/images/${o.img}', name: o.name, sub: o.sub)),
        _cell(1, Text(o.po, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink900))),
        _cell(2, Text(o.qty, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink900))),
        _cell(3, Text(o.value, style: const TextStyle(fontSize: 14, color: AppColors.ink700))),
        _cell(4, Text(o.added, style: const TextStyle(fontSize: 14, color: AppColors.ink700))),
        _cell(5, Align(alignment: Alignment.centerLeft, child: StBadge(o.status))),
        _cell(6, _rowActions(o)),
      ]),
    );
  }

  Widget _rowActions(_OrderRow o) {
    return Row(mainAxisAlignment: MainAxisAlignment.end, children: [
      if (o.agree) ...[
        DBtn('Agree', small: true, onTap: () => _agree(o)),
        const SizedBox(width: 8),
      ],
      DBtn('View', kind: DBtnKind.ghost, small: true, onTap: () {}),
    ]);
  }

  void _agree(_OrderRow o) => setState(() {
    o.status = 'Agreed · PO raised';
    o.agree = false;
  });

  Widget _mobileCard(_OrderRow o) {
    Widget kv(String k, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(k, style: const TextStyle(fontSize: 12, color: AppColors.ink400, fontWeight: FontWeight.w600)),
        Text(v, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.ink900)),
      ]),
    );
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        ProdCellD(image: 'assets/images/${o.img}', name: o.name, sub: o.sub),
        const SizedBox(height: 12),
        kv('PO Number', o.po),
        kv('Qty', o.qty),
        kv('Value', o.value),
        kv('Added', o.added),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: StBadge(o.status)),
        const SizedBox(height: 12),
        Row(children: [
          if (o.agree) ...[DBtn('Agree', small: true, onTap: () => _agree(o)), const SizedBox(width: 8)],
          DBtn('View', kind: DBtnKind.ghost, small: true, onTap: () {}),
        ]),
      ]),
    );
  }

  Widget _scheduleCard() {
    return DCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        DCardHead('Delivery & Install Schedule · PO #PWT-B-2026-0181',
            trailing: const StBadge('In production')),
        const DashTimeline([
          TlStep('Quotation approved', '20 May · PO raised', done: true),
          TlStep('Deposit invoiced (Net 30)', '21 May', done: true),
          TlStep('In production — 24 units', 'Batch QC in progress'),
          TlStep('Phased delivery to 3 sites', 'From 12 June', pending: true),
          TlStep('Installation & staff training', '16–20 June', pending: true),
        ]),
      ]),
    );
  }

  Widget _supportCard() {
    return DCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        const DCardHead('Bulk Order Support'),
        Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(color: const Color(0xFFEEF4FF), borderRadius: BorderRadius.circular(11)),
            child: const Icon(Icons.person_outline, color: AppColors.blue700, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: const [
              Text('James Whitfield · Account Manager',
                  style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
              SizedBox(height: 2),
              Text('Direct: 0800 123 4570 · james.w@pwt.com',
                  style: TextStyle(fontSize: 12.5, color: AppColors.ink500)),
            ]),
          ),
        ]),
        const SizedBox(height: 16),
        DBtn('Request a Quotation', fullWidth: true, onTap: () => Navigator.of(context).pushNamed('/rfq')),
        const SizedBox(height: 10),
        DBtn('Download Account Statement', kind: DBtnKind.outline, fullWidth: true,
            onTap: () => Navigator.of(context).pushReplacementNamed('/invoices')),
      ]),
    );
  }
}

class _Col {
  final String label;
  final double width;
  final int flex;
  const _Col(this.label, this.width, this.flex);
}