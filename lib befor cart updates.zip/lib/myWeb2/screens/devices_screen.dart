import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../models/product.dart';
import '../widgets/dash_kit.dart';

/// Individual → Devices. An individual holds a single active device plus,
/// optionally, one incoming order. Cards are narrow (fixed 320px) and pack
/// from the left — 1:1 with Dashboard.html (`.dev-grid` auto-fill, 320px).
class DevicesScreen extends StatelessWidget {
  const DevicesScreen({super.key});

  static const double _cardW = 320;

  @override
  Widget build(BuildContext context) {
    final devices = kIndividualDevices;
    return DashScaffold(
      active: 'devices',
      isCompany: false,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        PageHead(
          title: 'My Devices',
          subtitle: 'Your water systems at a glance.',
          action: NewOrderButton(label: 'Shop new device', onTap: () => Navigator.of(context).pushNamed('/shop')),
        ),
        Wrap(
          spacing: 18,
          runSpacing: 18,
          children: devices.map((d) => SizedBox(width: _cardW, child: _DeviceCard(d))).toList(),
        ),
      ]),
    );
  }
}

class _DeviceCard extends StatelessWidget {
  final Device d;
  const _DeviceCard(this.d);

  String get _image {
    switch (d.name) {
      case 'PW50-R':
        return 'assets/images/pw90.png';
      case 'PW-RO5':
        return 'assets/images/ct.png';
      case 'S4 Sparkling':
        return 'assets/images/s4.png';
      default:
        return 'assets/images/pw0ctr.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return DCard(
      // .dev-card.ordered → faint green tint + green border.
      border: d.ordered ? const Color(0xFFCDEADA) : AppColors.line,
      background: d.ordered ? const Color(0xFFFBFEFC) : Colors.white,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
            width: 60,
            height: 60,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              gradient: RadialGradient(center: Alignment(0, -0.4), radius: 0.7, colors: [Color(0xFFF6F9FF), Color(0xFFE6EEF9)]),
            ),
            padding: const EdgeInsets.all(9),
            child: Image.asset(_image, fit: BoxFit.contain),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d.name, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w700, color: AppColors.ink900)),
            const SizedBox(height: 3),
            Text(d.type, style: const TextStyle(fontSize: 12.5, color: AppColors.ink500)),
          ])),
          StBadge(d.ordered ? 'Ordered' : (d.rented ? 'Rented' : 'Purchased')),
        ]),

        // ---- ordered (incoming) device ----
        if (d.ordered) ...[
          const SizedBox(height: 16),
          _orderBanner('Order confirmed — arriving ${d.arriving}'),
          const SizedBox(height: 16),
          Container(height: 1, color: const Color(0xFFE9F2EC)),
          const SizedBox(height: 14),
          _row('Order', d.orderNo ?? '—'),
          const SizedBox(height: 10),
          _row('Type', d.orderType ?? 'Purchase'),
          const SizedBox(height: 18),
          const DBtn('Order details', kind: DBtnKind.outline, fullWidth: true),
        ]
        // ---- active rented / purchased device ----
        else ...[
          const SizedBox(height: 16),
          Container(height: 1, color: AppColors.line),
          const SizedBox(height: 14),
          if (d.maintenanceOn != null)
            _sched(Icons.calendar_today_outlined, 'Maintenance scheduled · ${d.maintenanceOn}')
          else if (d.rented) ...[
            _row('Rental plan', d.tenure),
            const SizedBox(height: 10),
            _row('Next payment', d.nextDue ?? '—', accent: true),
          ] else ...[
            _row('Purchased', d.tenure),
            const SizedBox(height: 10),
            _row('Warranty', '2 years'),
          ],
          const SizedBox(height: 18),
          DBtn(
            d.maintenanceOn != null ? 'Reschedule' : 'Request maintenance',
            kind: DBtnKind.outline,
            fullWidth: true,
            onTap: () => Navigator.of(context).pushReplacementNamed('/maintenance'),
          ),
        ],
      ]),
    );
  }

  Widget _row(String k, String v, {bool accent = false}) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(k, style: const TextStyle(fontSize: 13.5, color: AppColors.ink500)),
        Text(v, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: accent ? AppColors.blue700 : AppColors.ink900)),
      ]);

  // .dc-sched — blue scheduled-maintenance note.
  Widget _sched(IconData ic, String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
        decoration: BoxDecoration(color: const Color(0xFFEEF4FF), border: Border.all(color: const Color(0xFFD9E6FB)), borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Icon(ic, size: 16, color: AppColors.blue700),
          const SizedBox(width: 9),
          Expanded(child: Text(t, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.blue700))),
        ]),
      );

  // .dc-order-banner — green "order confirmed" note with a truck glyph.
  Widget _orderBanner(String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
        decoration: BoxDecoration(color: const Color(0xFFE8F6EE), border: Border.all(color: const Color(0xFFC2E6D1)), borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          const Icon(Icons.local_shipping_outlined, size: 17, color: AppColors.green700),
          const SizedBox(width: 9),
          Expanded(child: Text(t, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.green700))),
        ]),
      );
}
