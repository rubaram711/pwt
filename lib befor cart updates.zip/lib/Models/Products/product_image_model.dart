class ProductImageModel {

  final int? id;
  final String? url;
  final String? altText;
  final bool? isPrimary;

  ProductImageModel({
    this.id,
    this.url,
    this.altText,
    this.isPrimary,
  });

  factory ProductImageModel.fromJson(
      Map<String, dynamic> json,
      ) {

    return ProductImageModel(
      id: json['id'],
      url: json['url'],
      altText: json['alt_text'],
      isPrimary: json['is_primary'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'url': url,
      'alt_text': altText,
      'is_primary': isPrimary,
    };
  }
}