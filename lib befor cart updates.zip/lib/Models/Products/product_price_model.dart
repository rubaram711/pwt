class ProductPriceModel {

  final String term;
  final String amount;
  final String currency;
  final String? period;

  ProductPriceModel({
    required this.term,
    required this.amount,
    required this.currency,
    this.period,
  });

  factory ProductPriceModel.fromJson(
      Map<String, dynamic> json,
      ) {

    return ProductPriceModel(

      term: json['term'] ?? '',

      amount: json['amount'] ?? '',

      currency: json['currency'] ?? '',

      period: json['period'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'term': term,
      'amount': amount,
      'currency': currency,
      'period': period,
    };
  }
}