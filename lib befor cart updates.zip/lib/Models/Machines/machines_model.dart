import '../Maintenance/maintenance_request_model.dart';
import '../Products/products_model.dart';

class MachineModel {
  final int id;
  final String publicId;
  final String serialNumber;
  final ProductMiniModel product;
  final String locationLabel;
  final String countryCode;
  final String installedAt;
  final String nextMaintenanceDueAt;
  final bool isActive;
  final String term;

  MachineModel({
    required this.id,
    required this.publicId,
    required this.serialNumber,
    required this.product,
    required this.locationLabel,
    required this.countryCode,
    required this.installedAt,
    required this.nextMaintenanceDueAt,
    required this.isActive,
    required this.term,
  });

  factory MachineModel.fromJson(Map<String, dynamic> json) {
    return MachineModel(
      id: json['id'],
      publicId: json['public_id'],
      serialNumber: json['serial_number'],
      product: ProductMiniModel.fromJson(json['product']),
      locationLabel: json['location_label'],
      countryCode: json['country_code'],
      installedAt: json['installed_at'],
      nextMaintenanceDueAt: json['next_maintenance_due_at'],
      isActive: json['is_active'],
      term: json['term'],
    );
  }
}

class ProductMiniModel {
  final int id;
  final String code;
  final String name;

  ProductMiniModel({
    required this.id,
    required this.code,
    required this.name,
  });

  factory ProductMiniModel.fromJson(Map<String, dynamic> json) {
    return ProductMiniModel(
      id: json['id'],
      code: json['code'] ?? '',
      name: json['name'],
    );
  }
}




