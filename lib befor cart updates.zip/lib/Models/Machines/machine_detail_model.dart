import 'machines_model.dart';

class MachineDetailModel {
  final int id;
  final String publicId;
  final String serialNumber;
  final ProductMiniModel product;
  final MachineAddress address;
  final String installedAt;
  final int filterChangeIntervalMonths;
  final String nextMaintenanceDueAt;
  final List<MaintenanceLog> maintenanceLogs;
  final int totalLogsCount;

  MachineDetailModel({
    required this.id,
    required this.publicId,
    required this.serialNumber,
    required this.product,
    required this.address,
    required this.installedAt,
    required this.filterChangeIntervalMonths,
    required this.nextMaintenanceDueAt,
    required this.maintenanceLogs,
    required this.totalLogsCount,
  });

  factory MachineDetailModel.fromJson(Map<String, dynamic> json) {
    return MachineDetailModel(
      id: json['id'],
      publicId: json['public_id'],
      serialNumber: json['serial_number'],
      product: ProductMiniModel.fromJson(json['product']),
      address: MachineAddress.fromJson(json['address']),
      installedAt: json['installed_at'],
      filterChangeIntervalMonths: json['filter_change_interval_months'],
      nextMaintenanceDueAt: json['next_maintenance_due_at'],
      maintenanceLogs: (json['maintenance_logs'] as List)
          .map((e) => MaintenanceLog.fromJson(e))
          .toList(),
      totalLogsCount: json['total_logs_count'],
    );
  }
}


class MachineAddress {
  final String label;

  MachineAddress({required this.label});

  factory MachineAddress.fromJson(Map<String, dynamic> json) {
    return MachineAddress(
      label: json['label'],
    );
  }
}

class MaintenanceLog {
  final int id;
  final String scheduledAt;
  final String completedAt;
  final String status;
  final String? notes;

  MaintenanceLog({
    required this.id,
    required this.scheduledAt,
    required this.completedAt,
    required this.status,
    this.notes,
  });

  factory MaintenanceLog.fromJson(Map<String, dynamic> json) {
    return MaintenanceLog(
      id: json['id'],
      scheduledAt: json['scheduled_at'],
      completedAt: json['completed_at'],
      status: json['status'],
      notes: json['notes'],
    );
  }
}