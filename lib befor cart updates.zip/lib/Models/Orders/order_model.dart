class OrderModel {
  final int id;
  final String publicId;
  final String status;
  final String term;
  final String paymentMethod;
  final String currency;
  final String totalAmount;
  final int itemsCount;
  final String placedAt;

  OrderModel({
    required this.id,
    required this.publicId,
    required this.status,
    required this.term,
    required this.paymentMethod,
    required this.currency,
    required this.totalAmount,
    required this.itemsCount,
    required this.placedAt,
  });

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    return OrderModel(
      id: json['id'],
      publicId: json['public_id'],
      status: json['status'],
      term: json['term'],
      paymentMethod: json['payment_method'],
      currency: json['currency'],
      totalAmount: json['total_amount'].toString(),
      itemsCount: json['items_count'],
      placedAt: json['placed_at'],
    );
  }
}

class OrderItemModel {
  final int productId;
  final String productNameSnapshot;
  final int quantity;
  final String unitPrice;
  final String lineTotal;

  OrderItemModel({
    required this.productId,
    required this.productNameSnapshot,
    required this.quantity,
    required this.unitPrice,
    required this.lineTotal,
  });

  factory OrderItemModel.fromJson(Map<String, dynamic> json) {
    return OrderItemModel(
      productId: json['product_id'],
      productNameSnapshot: json['product_name_snapshot'],
      quantity: json['quantity'],
      unitPrice: json['unit_price'].toString(),
      lineTotal: json['line_total'].toString(),
    );
  }
}

class OrderDetailModel {
  final int id;
  final String publicId;
  final String status;
  final String term;
  final String paymentMethod;
  final String currency;

  final String subtotalAmount;
  final String discountAmount;
  final String taxAmount;
  final String totalAmount;

  final List<OrderItemModel> items;
  final List<dynamic>? statusHistory;
  final int? trackingProgress;

  OrderDetailModel({
    required this.id,
    required this.publicId,
    required this.status,
    required this.term,
    required this.paymentMethod,
    required this.currency,
    required this.subtotalAmount,
    required this.discountAmount,
    required this.taxAmount,
    required this.totalAmount,
    required this.items,
    this.statusHistory,
    this.trackingProgress,
  });

  factory OrderDetailModel.fromJson(Map<String, dynamic> json) {
    return OrderDetailModel(
      id: json['id'],
      publicId: json['public_id'],
      status: json['status'],
      term: json['term'],
      paymentMethod: json['payment_method'],
      currency: json['currency'],
      subtotalAmount: json['subtotal_amount'].toString(),
      discountAmount: json['discount_amount'].toString(),
      taxAmount: json['tax_amount'].toString(),
      totalAmount: json['total_amount'].toString(),
      items: (json['items'] as List)
          .map((e) => OrderItemModel.fromJson(e))
          .toList(),
      statusHistory: json['status_history'],
      trackingProgress: json['tracking_progress'],
    );
  }
}


