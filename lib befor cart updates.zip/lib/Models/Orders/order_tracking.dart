class OrderTrackingModel {
  final String status;
  final int trackingProgress;
  final String nextStep;
  final String? estimatedDeliveryWindow;
  final List<OrderTrackingEvent> timeline;

  OrderTrackingModel({
    required this.status,
    required this.trackingProgress,
    required this.nextStep,
    required this.estimatedDeliveryWindow,
    required this.timeline,
  });

  factory OrderTrackingModel.fromJson(Map<String, dynamic> json) {
    return OrderTrackingModel(
      status: json['status'],
      trackingProgress: json['tracking_progress'],
      nextStep: json['next_step'],
      estimatedDeliveryWindow: json['estimated_delivery_window'],
      timeline: (json['timeline'] as List)
          .map((e) => OrderTrackingEvent.fromJson(e))
          .toList(),
    );
  }
}

class OrderTrackingEvent {
  final String status;
  final String occurredAt;
  final String? note;

  OrderTrackingEvent({
    required this.status,
    required this.occurredAt,
    this.note,
  });

  factory OrderTrackingEvent.fromJson(Map<String, dynamic> json) {
    return OrderTrackingEvent(
      status: json['status'],
      occurredAt: json['occurred_at'],
      note: json['note'],
    );
  }
}

