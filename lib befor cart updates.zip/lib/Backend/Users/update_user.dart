import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';
import 'package:pwt_website/Models/Auth/user_model.dart';

import '../../../Services/dio_service.dart';
import '../../../const/urls.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';

Future<ApiResponse<User>> updateProfile({
  String? name,
  String? email,
  String? currentPassword,
  String? locale,
}) async {

final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<User>(

    request: () => di.patch(
      kProfileUrl,
      data: {
        if (name != null)
          "name": name,

        if (email != null)
          "email": email,

        if (currentPassword != null)
          "current_password": currentPassword,

        if (locale != null)
          "locale": locale,
      },
    ),

    parser: (data) => User.fromJson(data),
  );
}