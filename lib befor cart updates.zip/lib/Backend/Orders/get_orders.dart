import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';
import 'package:pwt_website/const/urls.dart';

import '../../../Services/dio_service.dart';
import '../../Models/Orders/order_model.dart';
import '../../Models/Pagination/paginated_response_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/paginated_api_handler.dart';


Future<ApiResponse<PaginatedResponse<OrderModel>>> getOrders({
  int page = 1,
  int perPage = 15,
  String? status,
  String? dateFrom,
  String? dateTo,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return PaginatedApiHandler.handleRequest<OrderModel>(
    request: () => di.get(
      kOrdersUrl,
      queryParameters: {
        'page': page,
        'per_page': perPage,
        if (status != null) 'status': status,
        if (dateFrom != null) 'date_from': dateFrom,
        if (dateTo != null) 'date_to': dateTo,
      },
    ),
    itemParser: (data) => OrderModel.fromJson(data),
  );
}