
import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../../Services/dio_service.dart';
import '../../Models/Orders/order_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';
import '../../const/urls.dart';

Future<ApiResponse<OrderDetailModel>> placeOrder({
  required List<Map<String, dynamic>> items,
  required int deliveryAddressId,
  required String paymentMethod,
  String? notes,
  String? promoCode,
  required String idempotencyKey,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<OrderDetailModel>(
    request: () => di.post(
      kOrdersUrl,
      data: {
        "items": items,
        "delivery_address_id": deliveryAddressId,
        "payment_method": paymentMethod,
        if (notes != null) "notes": notes,
        if (promoCode != null) "promo_code": promoCode,
      },
      options: dio.Options(
        headers: {
          'Idempotency-Key': idempotencyKey,
        },
      ),
    ),
    parser: (data) => OrderDetailModel.fromJson(data),
  );
}