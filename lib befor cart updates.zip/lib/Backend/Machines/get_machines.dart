import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../Models/Machines/machines_model.dart';
import '../../Models/Pagination/paginated_response_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/dio_service.dart';
import '../../Services/paginated_api_handler.dart';
import '../../const/urls.dart';



Future<ApiResponse<PaginatedResponse<MachineModel>>> getMachines({
  int page = 1,
  int perPage = 15,
  String? search,
  bool? needsMaintenance,
  String? countryCode,
  bool? isActive,
  String? sort,
  String? order,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return PaginatedApiHandler.handleRequest<MachineModel>(
    request: () => di.get(
      kMachinesUrl,
      queryParameters: {
        'page': page,
        'per_page': perPage,
        if (search != null) 'search': search,
        if (needsMaintenance != null) 'needs_maintenance': needsMaintenance,
        if (countryCode != null) 'country_code': countryCode,
        if (isActive != null) 'is_active': isActive,
        if (sort != null) 'sort': sort,
        if (order != null) 'order': order,
      },
    ),
    itemParser: (data) => MachineModel.fromJson(data),
  );
}