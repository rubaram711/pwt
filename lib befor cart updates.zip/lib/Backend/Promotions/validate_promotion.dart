import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../../Services/dio_service.dart';
import '../../Models/Promotion/validate_promotion_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';
import '../../const/urls.dart';

Future<ApiResponse<
    ValidatePromotionModel
>> validatePromotion({

  required String code,

  required double subtotal,

  required String currency,

  required List<int> productIds,

  required List<int> categoryIds,

}) async {

final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler
      .handleRequest<
      ValidatePromotionModel>(

    request: () => di.post(

      kValidatePromotionUrl,

      data: {

        "code": code,

        "subtotal": subtotal,

        "currency": currency,

        "product_ids": productIds,

        "category_ids": categoryIds,
      },
    ),

    parser: (data) =>

        ValidatePromotionModel
            .fromJson(data),
  );
}