class MaintenanceRequestModel {
  final int id;
  final String publicId;
  final String issueType;
  final String description;
  final String status;
  final String priority;
  final String preferredDate;
  final MachineMiniModel machine;
  final String createdAt;

  MaintenanceRequestModel({
    required this.id,
    required this.publicId,
    required this.issueType,
    required this.description,
    required this.status,
    required this.priority,
    required this.preferredDate,
    required this.machine,
    required this.createdAt,
  });

  factory MaintenanceRequestModel.fromJson(Map<String, dynamic> json) {
    return MaintenanceRequestModel(
      id: json['id'],
      publicId: json['public_id'],
      issueType: json['issue_type'],
      description: json['description_excerpt']?.toString() ?? json['description']?.toString() ?? '',
      status: json['status'],
      priority: json['priority'],
      preferredDate: json['preferred_date'],
      machine: MachineMiniModel.fromJson(json['machine']),
      createdAt: json['created_at'],
    );
  }
}

class MachineMiniModel {
  final int id;
  final String serialNumber;

  MachineMiniModel({
    required this.id,
    required this.serialNumber,
  });

  factory MachineMiniModel.fromJson(Map<String, dynamic> json) {
    return MachineMiniModel(
      id: json['id'],
      serialNumber: json['serial_number'],
    );
  }
}