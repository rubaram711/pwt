import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../Models/Maintenance/maintenance_request_model.dart';
import '../../Models/Pagination/paginated_response_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/dio_service.dart';
import '../../Services/paginated_api_handler.dart';
import '../../const/urls.dart';


Future<ApiResponse<PaginatedResponse<MaintenanceRequestModel>>>
getMaintenanceRequests({
  int page = 1,
  int perPage = 15,
  String? status,
  String? dateFrom,
  String? dateTo,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return PaginatedApiHandler.handleRequest<MaintenanceRequestModel>(
    request: () => di.get(
      kMaintenanceUrl,
      queryParameters: {
        'page': page,
        'per_page': perPage,
        if (status != null) 'status': status,
        if (dateFrom != null) 'date_from': dateFrom,
        if (dateTo != null) 'date_to': dateTo,
      },
    ),
    itemParser: (data) => MaintenanceRequestModel.fromJson(data),
  );
}