import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../Models/Maintenance/maintenance_detail_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';
import '../../Services/dio_service.dart';
import '../../const/urls.dart';
Future<ApiResponse<MaintenanceDetailModel>> submitMaintenanceRequest({
  required int machineId,
  required String issueType,
  required String description,
  required String preferredDate,
  List<int>? mediaFileIds,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<MaintenanceDetailModel>(
    request: () => di.post(
      kMaintenanceUrl,
      data: {
        "machine_id": machineId,
        "issue_type": issueType,
        "description": description,
        "preferred_date": preferredDate,
        "media_file_ids": mediaFileIds ?? [],
      },
    ),
    parser: (data) => MaintenanceDetailModel.fromJson(data),
  );
}