// Business shell: Fleet (devices) · Requests (maintenance schedules) · Orders
// (with quotations) · Shop. Ported from proto/business.jsx, plus the
// ScheduleMaintenance + Quotation flows from proto/account.jsx.

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/chrome.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import 'account_screens.dart';
import 'cart_screen.dart';
import 'individual_screens.dart';
import 'overlays.dart';
import 'product_detail_screen.dart';

/// A maintenance schedule created via the schedule flow.
class ScheduleEntry {
  ScheduleEntry({required this.id, required this.deviceIds, required this.date, required this.window});
  final String id;
  final List<String> deviceIds;
  final String date;
  final String window;
}

class BusinessShell extends StatefulWidget {
  const BusinessShell({super.key, required this.onLogout, this.isNew = false});
  final VoidCallback onLogout;
  final bool isNew;

  @override
  State<BusinessShell> createState() => _BusinessShellState();
}

class _BusinessShellState extends State<BusinessShell> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String _tab = 'devices';
  final List<ScheduleEntry> _schedules = [];
  final Map<String, String> _quoteStatus = {}; // orderId -> approved|cancelled

  AppUser get _user => MockData.userBusiness;

  void _onDrawerSelect(String key) {
    Navigator.of(context).pop();
    switch (key) {
      case 'logout':
        widget.onLogout();
      case 'profile':
        _push(ProfileScreen(user: _user, role: AccountKind.business));
      case 'settings':
        _push(const SettingsScreen());
      case 'invoices':
        _push(InvoicesScreen(invoices: MockData.businessInvoices));
    }
  }

  void _push(Widget screen) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));

  Future<void> _openSchedule({List<String>? presetIds}) async {
    final result = await Navigator.of(context).push<ScheduleEntry>(
      MaterialPageRoute(builder: (_) => ScheduleMaintenanceScreen(presetIds: presetIds ?? const [])),
    );
    if (result != null) setState(() => _schedules.insert(0, result));
  }

  void _openQuote(Order o) {
    _push(QuotationScreen(
      order: o,
      onDecision: (decision) => setState(() => _quoteStatus[o.id] = decision),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final tabs = ['devices', 'requests', 'orders', 'products'];

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: PwtColors.bg,
      endDrawer: ProfileDrawer(user: _user, onSelect: _onDrawerSelect),
      floatingActionButton: FloatingCart(onTap: () => _push(const CartScreen(role: AccountKind.business))),
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: tabs.indexOf(_tab),
          children: [
            widget.isNew
                ? _BusinessEmpty(user: _user, onProfile: () => _scaffoldKey.currentState?.openEndDrawer(), onBrowse: () => setState(() => _tab = 'products'))
                : BusinessDevicesScreen(
                    user: _user,
                    openRequests: _schedules.length,
                    onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
                    onMaintenance: (id) => _openSchedule(presetIds: [id]),
                  ),
            BusinessRequestsScreen(
              user: _user,
              schedules: _schedules,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onSchedule: () => _openSchedule(),
            ),
            BusinessOrdersScreen(
              user: _user,
              quoteStatus: _quoteStatus,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onViewQuote: _openQuote,
            ),
            ProductsScreen(
              user: _user,
              role: AccountKind.business,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onOpenProduct: (p) => _push(ProductDetailScreen(product: p, role: AccountKind.business)),
            ),
          ],
        ),
      ),
      bottomNavigationBar: PwtBottomNav(
        active: _tab,
        onChanged: (k) => setState(() => _tab = k),
        items: [
          PwtNavItem(key: 'devices', label: s['devices']!, icon: PwtIcons.drop),
          PwtNavItem(key: 'requests', label: s['requests']!, icon: PwtIcons.wrench),
          PwtNavItem(key: 'orders', label: s['orders']!, icon: PwtIcons.orders),
          PwtNavItem(key: 'products', label: s['shop']!, icon: PwtIcons.cube),
        ],
      ),
    );
  }
}

// ─── Fleet ───
class BusinessDevicesScreen extends StatelessWidget {
  const BusinessDevicesScreen({super.key, required this.user, required this.openRequests, required this.onProfile, required this.onMaintenance});
  final AppUser user;
  final int openRequests;
  final VoidCallback onProfile;
  final ValueChanged<String> onMaintenance;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final devices = MockData.businessDevices;
    final monthly = devices.where((d) => d.plan == Plan.rent).fold<int>(0, (sum, d) => sum + (d.rent ?? 0));
    final rentCount = devices.where((d) => d.plan == Plan.rent).length;
    final buyCount = devices.where((d) => d.plan == Plan.buy).length;

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: user, onProfile: onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Pill(label: s['business']!),
                  const SizedBox(width: 10),
                  Expanded(child: Text(user.company!.name, overflow: TextOverflow.ellipsis, style: PwtType.caption().copyWith(fontSize: 12))),
                ],
              ),
              const SizedBox(height: 14),
              PwtCard(
                padding: EdgeInsets.zero,
                child: Row(
                  children: [
                    _stat(s['devicesCount']!, Text('${devices.length}', style: _statStyle), '$rentCount ${s['rent']} · $buyCount ${s['buy']}'),
                    _stat(s['monthlyTotal']!, Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [const Dirham(size: 14), const SizedBox(width: 4), Text(_fmt(monthly), style: _statStyle)]), s['perMonth']!.replaceAll('/', ''), divider: true),
                    _stat(s['openRequests']!, Text('$openRequests', style: _statStyle.copyWith(color: openRequests > 0 ? PwtColors.brand : PwtColors.textTer)), s['scheduleMaintenance']!.toLowerCase(), divider: true),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(s['allDevices']!, style: PwtType.subtitle().copyWith(fontSize: 17)),
              Text('${devices.length}', style: PwtType.mono(size: 12, color: PwtColors.textTer)),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            children: [
              for (final d in devices)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _BusinessDeviceCard(device: d, onMaintenance: () => onMaintenance(d.id)),
                ),
            ],
          ),
        ),
      ],
    );
  }

  static const _statStyle = TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -0.4, color: PwtColors.textPri);

  Widget _stat(String label, Widget value, String sub, {bool divider = false}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        decoration: BoxDecoration(border: divider ? const Border(left: BorderSide(color: PwtColors.hairline)) : null),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            value,
            const SizedBox(height: 2),
            Text(sub, style: PwtType.caption().copyWith(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _BusinessDeviceCard extends StatelessWidget {
  const _BusinessDeviceCard({required this.device, required this.onMaintenance});
  final Device device;
  final VoidCallback onMaintenance;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final overdue = device.nextService?.startsWith('04 May') ?? false;
    final isRent = device.plan == Plan.rent;

    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 72,
                  decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                  alignment: Alignment.center,
                  child: Image(image: pwtImage(device.img), height: 56, fit: BoxFit.contain),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Pill(label: isRent ? s['rent']! : s['buy']!, color: isRent ? PwtColors.brand : PwtColors.success),
                          if (isRent) ...[
                            const SizedBox(width: 6),
                            const Dirham(size: 10, color: PwtColors.textSec),
                            const SizedBox(width: 2),
                            Text('${device.rent}', style: PwtType.caption(color: PwtColors.textPri).copyWith(fontSize: 12, fontWeight: FontWeight.w600)),
                            Text(' ${s['perMonth']}', style: PwtType.caption().copyWith(fontSize: 12)),
                          ],
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(device.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: PwtType.subtitle().copyWith(fontSize: 15)),
                      const SizedBox(height: 2),
                      Directionality(textDirection: TextDirection.ltr, child: Text(device.id, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              children: [
                Expanded(child: _svc(s['lastService']!, device.lastService ?? '—', false)),
                Expanded(child: _svc(s['nextService']!, '${device.nextService}${overdue ? ' · ${app.isArabic ? 'متأخر' : 'overdue'}' : ''}', overdue, divider: true)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              children: [
                Expanded(child: PwtButton(label: s['scheduleVisit']!, variant: overdue ? PwtButtonVariant.primary : PwtButtonVariant.ghost, size: PwtButtonSize.sm, icon: PwtIcons.wrench, onPressed: onMaintenance)),
                if (isRent) ...[
                  const SizedBox(width: 8),
                  Expanded(child: PwtButton(label: s['payNow']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.sm, icon: PwtIcons.card)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _svc(String label, String value, bool overdue, {bool divider = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(border: divider ? const Border(left: BorderSide(color: PwtColors.hairline)) : null),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10, letterSpacing: 1, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(value, style: PwtType.label(color: overdue ? PwtColors.error : PwtColors.textPri, weight: FontWeight.w600).copyWith(fontSize: 13)),
        ],
      ),
    );
  }
}

// ─── Requests ───
class BusinessRequestsScreen extends StatelessWidget {
  const BusinessRequestsScreen({super.key, required this.user, required this.schedules, required this.onProfile, required this.onSchedule});
  final AppUser user;
  final List<ScheduleEntry> schedules;
  final VoidCallback onProfile;
  final VoidCallback onSchedule;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: user, onProfile: onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Eyebrow(s['requests']!),
              const SizedBox(height: 4),
              Text(s['maintenanceRequests']!, style: PwtType.headline().copyWith(fontSize: 28)),
            ],
          ),
        ),
        if (schedules.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(30, 60, 30, 0),
            child: Column(
              children: [
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(color: PwtColors.brandTint, shape: BoxShape.circle, border: Border.all(color: PwtColors.brandBorder)),
                  child: const Icon(PwtIcons.wrench, size: 48, color: PwtColors.brand),
                ),
                const SizedBox(height: 22),
                Text(s['noRequestsYet']!, style: PwtType.title().copyWith(fontSize: 22)),
                const SizedBox(height: 8),
                Text(s['noRequestsSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
                const SizedBox(height: 24),
                PwtButton(label: s['scheduleMaintenance']!, full: true, icon: PwtIcons.plus, onPressed: onSchedule),
              ],
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${schedules.length} ${s['upcoming']!.toLowerCase()}', style: PwtType.caption().copyWith(fontSize: 13)),
                    PwtButton(label: s['scheduleMaintenance']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.sm, icon: PwtIcons.plus, onPressed: onSchedule),
                  ],
                ),
                const SizedBox(height: 12),
                for (final sch in schedules)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _ScheduleCard(schedule: sch),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class _ScheduleCard extends StatelessWidget {
  const _ScheduleCard({required this.schedule});
  final ScheduleEntry schedule;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final devs = schedule.deviceIds.map((id) => MockData.businessDevices.firstWhere((d) => d.id == id, orElse: () => MockData.businessDevices.first)).toList();
    return Container(
      decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(PwtRadius.card), boxShadow: PwtShadows.e1),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Directionality(textDirection: TextDirection.ltr, child: Text(schedule.id, style: PwtType.mono(size: 11.5, color: PwtColors.brand, weight: FontWeight.w600))),
                const SizedBox(width: 10),
                Pill(label: s['scheduledTitle']!, color: PwtColors.brand, dot: true),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                const Icon(PwtIcons.cal, size: 16, color: PwtColors.textTer),
                const SizedBox(width: 8),
                Text(schedule.date, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13)),
                const SizedBox(width: 6),
                Directionality(textDirection: TextDirection.ltr, child: Text('· ${schedule.window}', style: PwtType.label(color: PwtColors.textTer).copyWith(fontSize: 13))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${devs.length} ${s['devicesLabel']}'.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10.5, letterSpacing: 1, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                for (final d in devs)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Container(width: 30, height: 38, decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(8), border: Border.all(color: PwtColors.hairline)), alignment: Alignment.center, child: Image(image: pwtImage(d.img), height: 28, fit: BoxFit.contain)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13)),
                              Directionality(textDirection: TextDirection.ltr, child: Text(d.id, style: PwtType.mono(size: 11, color: PwtColors.textTer))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Orders (sortable, with quotations) ───
class BusinessOrdersScreen extends StatefulWidget {
  const BusinessOrdersScreen({super.key, required this.user, required this.quoteStatus, required this.onProfile, required this.onViewQuote});
  final AppUser user;
  final Map<String, String> quoteStatus;
  final VoidCallback onProfile;
  final ValueChanged<Order> onViewQuote;

  @override
  State<BusinessOrdersScreen> createState() => _BusinessOrdersScreenState();
}

class _BusinessOrdersScreenState extends State<BusinessOrdersScreen> {
  bool _sortDesc = true;

  Color _statusColor(String st) => switch (st) {
        'quote_pending' => PwtColors.warning,
        'quote_sent' => PwtColors.info,
        'active' => PwtColors.success,
        'approved' => PwtColors.success,
        'cancelled' => PwtColors.error,
        _ => PwtColors.textSec,
      };

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final orders = [...MockData.businessOrders];
    // demo sort: keep mock order but allow reversing
    if (!_sortDesc) orders.sort((a, b) => a.date.compareTo(b.date));

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: widget.user, onProfile: widget.onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Eyebrow(context.watch<AppState>().isArabic ? 'طلبيات شركتك' : 'Company orders'),
                  const SizedBox(height: 4),
                  Text(s['orders']!, style: PwtType.headline().copyWith(fontSize: 28)),
                ],
              ),
              GestureDetector(
                onTap: () => setState(() => _sortDesc = !_sortDesc),
                child: Container(
                  height: 36,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    children: [
                      const Icon(PwtIcons.sort, size: 15, color: PwtColors.textSec),
                      const SizedBox(width: 6),
                      Text(_sortDesc ? s['newestFirst']! : s['oldestFirst']!, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            children: [
              for (final o in orders)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _orderCard(context, o, s),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _orderCard(BuildContext context, Order o, Map<String, String> s) {
    final decided = widget.quoteStatus[o.id];
    final isQuote = o.status == 'quote_sent' && decided == null;
    final label = decided == 'approved' ? s['approvedStatus']! : decided == 'cancelled' ? s['cancelledStatus']! : o.statusLabel;
    final color = _statusColor(decided ?? o.status);

    return PwtCard(
      padding: const EdgeInsets.all(16),
      onTap: isQuote ? () => widget.onViewQuote(o) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Directionality(textDirection: TextDirection.ltr, child: Text(o.id, style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
              Pill(label: label, color: color, dot: true),
            ],
          ),
          const SizedBox(height: 8),
          Text(o.items, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5)),
          const SizedBox(height: 4),
          Text('${s['placed']} ${o.date}', style: PwtType.caption().copyWith(fontSize: 12)),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Divider(height: 1, color: PwtColors.hairline),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (o.amount != null)
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    const Dirham(size: 12),
                    const SizedBox(width: 4),
                    Text(_fmt(o.amount!), style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                    if (o.plan == Plan.rent) Text(s['perMonth']!, style: PwtType.caption()),
                  ],
                )
              else
                Text(o.status == 'quote_pending' ? s['awaitingQuote']! : (decided != null ? '' : s['quotationReceived']!), style: PwtType.caption(color: PwtColors.textSec).copyWith(fontStyle: FontStyle.italic, fontSize: 12.5)),
              if (isQuote)
                Row(
                  children: [
                    Text(s['viewQuote']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
                    const Icon(PwtIcons.caret, size: 15, color: PwtColors.brand),
                  ],
                )
              else
                const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Empty fleet ───
class _BusinessEmpty extends StatelessWidget {
  const _BusinessEmpty({required this.user, required this.onProfile, required this.onBrowse});
  final AppUser user;
  final VoidCallback onProfile;
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return ListView(
      children: [
        AppHeader(user: user, onProfile: onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(
            children: [
              Pill(label: s['business']!),
              const SizedBox(width: 10),
              Expanded(child: Text(user.company!.name, overflow: TextOverflow.ellipsis, style: PwtType.caption().copyWith(fontSize: 12))),
            ],
          ),
        ),
        const SizedBox(height: 40),
        Center(
          child: Container(
            width: 110,
            height: 110,
            decoration: BoxDecoration(color: PwtColors.brandTint, shape: BoxShape.circle, border: Border.all(color: PwtColors.brandBorder)),
            child: const Icon(PwtIcons.briefcase, size: 48, color: PwtColors.brand),
          ),
        ),
        const SizedBox(height: 22),
        Center(child: Text(s['noFleetYet']!, style: PwtType.title().copyWith(fontSize: 22))),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(s['noFleetSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: PwtButton(label: s['exploreProducts']!, full: true, icon: PwtIcons.cube, onPressed: onBrowse),
        ),
      ],
    );
  }
}

// ═══════════════ SCHEDULE MAINTENANCE (multi-step) ═══════════════
class ScheduleMaintenanceScreen extends StatefulWidget {
  const ScheduleMaintenanceScreen({super.key, this.presetIds = const []});
  final List<String> presetIds;

  @override
  State<ScheduleMaintenanceScreen> createState() => _ScheduleMaintenanceScreenState();
}

class _ScheduleMaintenanceScreenState extends State<ScheduleMaintenanceScreen> {
  String _step = 'select'; // select | when | success
  late List<String> _selected = List.of(widget.presetIds);
  String _date = '22';
  String _window = '10:00 – 13:00';

  static const _dates = ['20', '21', '22', '23', '24'];
  static const _windows = ['09:00 – 12:00', '10:00 – 13:00', '13:00 – 16:00', '16:00 – 19:00'];

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final devices = MockData.businessDevices;
    final selDevices = devices.where((d) => _selected.contains(d.id)).toList();

    return DetailScaffold(
      title: s['scheduleMaintenance'],
      onBack: _step == 'when' ? () => setState(() => _step = 'select') : () => Navigator.pop(context),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          if (_step == 'select') ...[
            Text(s['selectDevices']!, style: PwtType.title().copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text(s['selectDevicesSub']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
            const SizedBox(height: 14),
            for (final d in devices)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _deviceCheck(d, _selected.contains(d.id), () {
                  setState(() {
                    if (_selected.contains(d.id)) {
                      _selected.remove(d.id);
                    } else {
                      _selected.add(d.id);
                    }
                  });
                }),
              ),
          ],
          if (_step == 'when') ...[
            Text(s['pickDate']!, style: PwtType.title().copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text('${_selected.length} ${s['devicesLabel']!.toLowerCase()} · ${s['devicesSelectedN']}', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
            const SizedBox(height: 14),
            SizedBox(
              height: 60,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final d in _dates)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _dateChip(d),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Eyebrow(s['pickTimeWindow']!),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 3.2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [for (final w in _windows) _windowChip(w)],
            ),
            Section(
              title: s['devicesLabel']!,
              child: PwtCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: [
                    for (int i = 0; i < selDevices.length; i++)
                      ListRow(leading: PwtIcons.drop, title: selDevices[i].name, sub: selDevices[i].id, last: i == selDevices.length - 1),
                  ],
                ),
              ),
            ),
          ],
          if (_step == 'success')
            SuccessView(
              title: s['scheduledTitle']!,
              body: s['scheduledBody']!,
              accent: PwtColors.brand,
              detail: PwtCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    ListRow(leading: PwtIcons.cal, title: '$_date May 2026', sub: _window),
                    ListRow(leading: PwtIcons.drop, title: '${_selected.length} ${s['devicesLabel']}', sub: selDevices.map((d) => d.name).join(', '), last: true),
                  ],
                ),
              ),
            ),
        ],
      ),
      bottomBar: switch (_step) {
        'select' => PwtButton(
            label: '${s['continueLabel']}${_selected.isNotEmpty ? ' · ${_selected.length}' : ''}',
            full: true,
            disabled: _selected.isEmpty,
            onPressed: () => setState(() => _step = 'when'),
          ),
        'when' => PwtButton(
            label: s['scheduleVisitCta']!,
            full: true,
            onPressed: () => setState(() => _step = 'success'),
          ),
        _ => PwtButton(
            label: s['done']!,
            full: true,
            onPressed: () => Navigator.pop(context, ScheduleEntry(id: 'MR-${400 + Random().nextInt(599)}', deviceIds: _selected, date: '$_date May 2026', window: _window)),
          ),
      },
    );
  }

  Widget _deviceCheck(Device d, bool on, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(PwtRadius.md),
        ),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: on ? PwtColors.brand : PwtColors.surface,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
              ),
              child: on ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
            ),
            const SizedBox(width: 12),
            Container(width: 40, height: 50, decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(9), border: Border.all(color: PwtColors.hairline)), alignment: Alignment.center, child: Image(image: pwtImage(d.img), height: 38, fit: BoxFit.contain)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                  const SizedBox(height: 2),
                  Directionality(textDirection: TextDirection.ltr, child: Text(d.id, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dateChip(String d) {
    final on = d == _date;
    final ar = context.read<AppState>().isArabic;
    return GestureDetector(
      onTap: () => setState(() => _date = d),
      child: Container(
        width: 64,
        decoration: BoxDecoration(
          color: on ? PwtColors.brand : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(ar ? 'مايو' : 'May', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1, color: on ? Colors.white70 : PwtColors.textTer)),
            Text(d, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: on ? Colors.white : PwtColors.textPri)),
          ],
        ),
      ),
    );
  }

  Widget _windowChip(String w) {
    final on = w == _window;
    return GestureDetector(
      onTap: () => setState(() => _window = w),
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Text(w, style: TextStyle(fontSize: 13, fontWeight: on ? FontWeight.w600 : FontWeight.w500, color: on ? PwtColors.brandDeep : PwtColors.textPri)),
        ),
      ),
    );
  }
}

// ═══════════════ QUOTATION (view / approve / cancel) ═══════════════
class QuotationScreen extends StatefulWidget {
  const QuotationScreen({super.key, required this.order, required this.onDecision});
  final Order order;
  final ValueChanged<String> onDecision;

  @override
  State<QuotationScreen> createState() => _QuotationScreenState();
}

class _QuotationScreenState extends State<QuotationScreen> {
  String? _result; // approved | cancelled

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final o = widget.order;
    const subtotal = 8020;
    final vat = (subtotal * 0.05);
    final total = subtotal + vat;

    if (_result != null) {
      return DetailScaffold(
        title: s['viewQuote'],
        body: ListView(
          children: [
            SuccessView(
              title: _result == 'approved' ? s['quoteApproved']! : s['cancelledStatus']!,
              body: _result == 'approved'
                  ? (app.isArabic ? 'سيتواصل فريقنا لتحديد موعد التركيب.' : 'Our team will reach out to arrange installation.')
                  : (app.isArabic ? 'تم سحب طلب العرض.' : 'Your quotation request has been withdrawn.'),
              icon: _result == 'approved' ? PwtIcons.check : PwtIcons.close,
              accent: _result == 'approved' ? PwtColors.success : PwtColors.textSec,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
              child: PwtButton(label: s['done']!, full: true, onPressed: () => Navigator.pop(context)),
            ),
          ],
        ),
      );
    }

    return DetailScaffold(
      title: s['viewQuote'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          PwtCard(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Directionality(textDirection: TextDirection.ltr, child: Text(o.id, style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
                      const SizedBox(height: 4),
                      Text(o.items, style: PwtType.subtitle().copyWith(fontSize: 17, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text('${s['placed']} ${o.date}', style: PwtType.caption().copyWith(fontSize: 12)),
                    ],
                  ),
                ),
                Pill(label: s['quotationReceived']!, color: PwtColors.info, dot: true),
              ],
            ),
          ),
          Section(
            title: s['orderSummary']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: PwtColors.hairline))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text('1× ${o.items}', style: PwtType.label().copyWith(fontSize: 13.5))),
                        _money(subtotal),
                      ],
                    ),
                  ),
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, c: PwtColors.textSec)),
                  SummaryRow(label: s['vat']!, value: _money(vat, c: PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, c: PwtColors.textPri)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, left: 4),
            child: Text(app.isArabic ? 'يشمل التركيب وأول 3 أشهر إيجار' : 'Incl. installation + first 3 months rental', style: PwtType.caption().copyWith(fontSize: 12)),
          ),
        ],
      ),
      bottomBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          PwtButton(
            label: s['approveQuote']!,
            full: true,
            icon: PwtIcons.check,
            onPressed: () {
              widget.onDecision('approved');
              setState(() => _result = 'approved');
            },
          ),
          const SizedBox(height: 10),
          PwtButton(
            label: s['cancelQuote']!,
            variant: PwtButtonVariant.ghost,
            full: true,
            icon: PwtIcons.close,
            onPressed: () async {
              final ok = await showConfirmSheet(
                context,
                title: s['cancelConfirmTitle']!,
                body: s['cancelConfirmBody']!,
                keepLabel: s['keepIt']!,
                confirmLabel: s['yesCancel']!,
              );
              if (ok) {
                widget.onDecision('cancelled');
                setState(() => _result = 'cancelled');
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _money(num v, {Color c = PwtColors.textPri}) => Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [Dirham(size: 11, color: c), const SizedBox(width: 3), Text(_fmt(v), style: TextStyle(color: c, fontWeight: FontWeight.w600, fontSize: 14))],
      );
}

String _fmt(num v) => v.toInt().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
