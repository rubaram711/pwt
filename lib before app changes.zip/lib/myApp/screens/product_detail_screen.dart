// Rich product-detail page (PDP): gallery, rating, features, pricing,
// rent/buy selector, assurances and the overview/specs/box/reviews tabs.
// Ported from proto/overlays.jsx (ProductDetailScreen + StarRating).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pwt_website/myApp/widgets/chrome.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import 'cart_screen.dart';

class StarRating extends StatelessWidget {
  const StarRating({super.key, required this.value, this.size = 14});
  final double value;
  final double size;

  @override
  Widget build(BuildContext context) {
    final full = value.round();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int n = 1; n <= 5; n++)
          Icon(PwtIcons.star, size: size, color: n <= full ? const Color(0xFFF5A623) : PwtColors.hairline2),
      ],
    );
  }
}

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.product, required this.role});
  final Product product;
  final AccountKind role;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late Plan _plan = widget.product.quoteOnly ? Plan.quote : Plan.rent;
  bool _justAdded = false;
  String _tab = 'overview';
  int _heroIdx = 0;

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;
    final det = MockData.productDetails[p.id] ?? const ProductDetail(rating: 4.7, reviews: 60, sparkling: false, specs: []);
    final gallery = [p.img, ...MockData.products.where((x) => x.id != p.id).take(3).map((x) => x.img)];
    final features = det.sparkling
        ? ['Sparkling on demand', 'Chilled & ambient', 'Energy efficient', 'Compact design']
        : ['Instant hot & cold', 'Energy efficient', 'Child safety lock', 'Sleek modern design'];

    final tabs = [
      (k: 'overview', label: s['overview']!),
      (k: 'specs', label: s['specifications']!),
      (k: 'box', label: s['whatsInBox']!),
      (k: 'reviews', label: '${s['reviewsTab']} (${det.reviews})'),
    ];

    final isQuote = widget.role == AccountKind.business || p.quoteOnly;

    return DetailScaffold(
      title: p.name,
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          // gallery
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
            child: Column(
              children: [
                Container(
                  height: 280,
                  decoration: BoxDecoration(
                    color: PwtColors.surface,
                    border: Border.all(color: PwtColors.hairline),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      ProductImage(img: gallery[_heroIdx], size: 232, accent: p.tint),
                      if (det.badge != null)
                        Positioned(
                          top: 12,
                          left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: PwtColors.brand, borderRadius: BorderRadius.circular(999)),
                            child: Text(det.badge!, style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    for (int i = 0; i < gallery.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: GestureDetector(
                          onTap: () => setState(() => _heroIdx = i),
                          child: Container(
                            width: 60,
                            height: 60,
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: PwtColors.surface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: i == _heroIdx ? PwtColors.brand : PwtColors.hairline, width: 1.5),
                            ),
                            child: Image(image: pwtImage(gallery[i]), fit: BoxFit.contain),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow(p.cat, color: p.tint),
                const SizedBox(height: 4),
                Text(p.name, style: PwtType.headline().copyWith(fontSize: 26)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    StarRating(value: det.rating, size: 15),
                    const SizedBox(width: 8),
                    Text('${det.rating}', style: PwtType.label(weight: FontWeight.w700).copyWith(fontSize: 13.5)),
                    const SizedBox(width: 6),
                    Text('(${det.reviews} ${s['reviewsLabel']})', style: PwtType.caption().copyWith(fontSize: 12.5)),
                  ],
                ),
                const SizedBox(height: 10),
                Text(p.blurb, style: PwtType.body(color: PwtColors.textSec).copyWith(height: 1.5)),
                const SizedBox(height: 16),
                // feature chips
                GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 4.2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (final f in features)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: PwtColors.surface,
                          border: Border.all(color: PwtColors.hairline),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(PwtIcons.check, size: 15, color: PwtColors.brand),
                            const SizedBox(width: 8),
                            Expanded(child: Text(f, style: PwtType.caption(color: PwtColors.textPri).copyWith(fontSize: 12, fontWeight: FontWeight.w500))),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                // price card / quote banner
                if (!p.quoteOnly)
                  PwtCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Eyebrow(s['rent']!),
                                  const SizedBox(height: 6),
                                  Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
                                    const Dirham(size: 14),
                                    const SizedBox(width: 4),
                                    Text('${p.price}', style: PwtType.title().copyWith(fontSize: 22, fontWeight: FontWeight.w700)),
                                    Text(s['perMonth']!, style: PwtType.caption()),
                                  ]),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.only(left: 16),
                              decoration: const BoxDecoration(border: Border(left: BorderSide(color: PwtColors.hairline))),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Eyebrow(s['buy']!),
                                  const SizedBox(height: 6),
                                  Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
                                    const Dirham(size: 14),
                                    const SizedBox(width: 4),
                                    Text(_fmtInt(p.buyPrice ?? 0), style: PwtType.title().copyWith(fontSize: 22, fontWeight: FontWeight.w700)),
                                  ]),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(s['youSaveLine']!, style: PwtType.caption().copyWith(fontSize: 11.5)),
                      ],
                    ),
                  )
                else
                  PwtBanner(variant: BannerVariant.info, title: s['quoteOnly']!, body: ar ? 'يحدد السعر بناءً على متطلبات التركيب — فريقنا سيقترح حلاً مخصصاً.' : 'Pricing is determined by your installation requirements — our team will tailor a quote for you.'),
                // rent/buy selector (individual)
                if (widget.role == AccountKind.individual && !p.quoteOnly) ...[
                  const SizedBox(height: 16),
                  Eyebrow(s['rentOrBuy']!),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(14), border: Border.all(color: PwtColors.hairline)),
                    child: Row(
                      children: [
                        _planTab(s['rent']!, '${p.price}${s['perMonth']}', _plan == Plan.rent, () => setState(() => _plan = Plan.rent)),
                        _planTab(s['buy']!, _fmtInt(p.buyPrice ?? 0), _plan == Plan.buy, () => setState(() => _plan = Plan.buy)),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                // assurances
                Row(
                  children: [
                    _assurance(PwtIcons.truck, s['freeDelivery']!, s['freeDeliverySub']!),
                    const SizedBox(width: 8),
                    _assurance(PwtIcons.wrench, s['freeInstall']!, s['freeInstallSub']!),
                    const SizedBox(width: 8),
                    _assurance(PwtIcons.shield, s['warrantyTitle']!, s['warrantySub']!),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          // tabs
          Container(
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: PwtColors.hairline))),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  for (final tb in tabs)
                    GestureDetector(
                      onTap: () => setState(() => _tab = tb.k),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tb.k == _tab ? PwtColors.brand : Colors.transparent, width: 2))),
                        child: Text(tb.label, style: TextStyle(fontSize: 13.5, fontWeight: tb.k == _tab ? FontWeight.w700 : FontWeight.w500, color: tb.k == _tab ? PwtColors.brand : PwtColors.textSec)),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
            child: _tabContent(det, features, s, ar),
          ),
        ],
      ),
      bottomBar: PwtButton(
        label: _justAdded ? s['addedToCart']! : (isQuote ? s['requestQuote']! : s['addToCart']!),
        variant: _justAdded ? PwtButtonVariant.soft : PwtButtonVariant.primary,
        full: true,
        icon: _justAdded ? PwtIcons.check : PwtIcons.cart,
        onPressed: () {
          final plan = isQuote ? Plan.quote : _plan;
          context.read<CartState>().addItem(p.id, plan: plan);
          setState(() => _justAdded = true);
          Future.delayed(const Duration(milliseconds: 700), () {
            if (!mounted) return;
            setState(() => _justAdded = false);
            Navigator.push(context, MaterialPageRoute(builder: (_) => CartScreen(role: widget.role)));
          });
        },
      ),
    );
  }

  Widget _tabContent(ProductDetail det, List<String> features, Map<String, String> s, bool ar) {
    switch (_tab) {
      case 'specs':
        return PwtCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              for (int i = 0; i < det.specs.length; i++)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(border: i == det.specs.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(det.specs[i][0], style: PwtType.label(color: PwtColors.textSec).copyWith(fontSize: 13)),
                      Flexible(child: Text(det.specs[i][1], textAlign: TextAlign.end, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13))),
                    ],
                  ),
                ),
            ],
          ),
        );
      case 'box':
        return Column(
          children: [
            for (final b in MockData.boxContents)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Container(width: 30, height: 30, decoration: BoxDecoration(color: PwtColors.brandTint, borderRadius: BorderRadius.circular(8)), child: const Icon(PwtIcons.cube, size: 16, color: PwtColors.brand)),
                      const SizedBox(width: 12),
                      Text(b, style: PwtType.label().copyWith(fontSize: 13.5)),
                    ],
                  ),
                ),
              ),
          ],
        );
      case 'reviews':
        return Column(
          children: [
            PwtCard(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Column(
                    children: [
                      Text('${det.rating}', style: PwtType.display().copyWith(fontSize: 36, fontWeight: FontWeight.w800)),
                      StarRating(value: det.rating, size: 13),
                      const SizedBox(height: 4),
                      Text('${s['basedOn']} ${det.reviews}', style: PwtType.caption().copyWith(fontSize: 11)),
                    ],
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      children: [
                        for (final bar in [(5, 0.78), (4, 0.18), (3, 0.03), (2, 0.01), (1, 0.0)])
                          Padding(
                            padding: const EdgeInsets.only(bottom: 5),
                            child: Row(
                              children: [
                                SizedBox(width: 22, child: Text('${bar.$1}★', style: PwtType.caption(color: PwtColors.textSec).copyWith(fontSize: 11))),
                                Expanded(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: LinearProgressIndicator(value: bar.$2, minHeight: 6, backgroundColor: PwtColors.surface2, valueColor: const AlwaysStoppedAnimation(PwtColors.brand)),
                                  ),
                                ),
                                SizedBox(width: 30, child: Text('${(bar.$2 * det.reviews).round()}', textAlign: TextAlign.end, style: PwtType.caption().copyWith(fontSize: 11))),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (final r in MockData.reviews)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: PwtCard(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(width: 36, height: 36, decoration: BoxDecoration(color: PwtColors.surface2, shape: BoxShape.circle), alignment: Alignment.center, child: Text(r.initials, style: PwtType.label(weight: FontWeight.w700).copyWith(fontSize: 12, color: PwtColors.textSec))),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(r.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13.5)),
                                Text('${s['verifiedBuyer']} · ${r.date}', style: PwtType.caption().copyWith(fontSize: 11)),
                              ],
                            ),
                          ),
                          StarRating(value: r.stars.toDouble(), size: 12),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(r.text, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13, height: 1.5)),
                    ],
                  ),
                ),
              ),
          ],
        );
      default: // overview
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(ar ? 'ترطيب مميّز كل يوم.' : 'Premium hydration, every day.', style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              ar ? 'تصميم أنيق وأداء متقدم وتقنية موفّرة للطاقة — إضافة مثالية لأي مساحة.' : 'A sleek design, advanced filtration and energy-saving technology make this the perfect addition to any home or office.',
              style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.6),
            ),
            const SizedBox(height: 12),
            for (final f in features)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    const Icon(PwtIcons.check, size: 16, color: PwtColors.success),
                    const SizedBox(width: 10),
                    Text(f, style: PwtType.label().copyWith(fontSize: 13.5)),
                  ],
                ),
              ),
          ],
        );
    }
  }

  Widget _planTab(String label, String sub, bool on, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: PwtMotion.fast,
          height: 50,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: on ? PwtColors.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            boxShadow: on ? const [BoxShadow(color: Color(0x1F0F172A), blurRadius: 4, offset: Offset(0, 1))] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: TextStyle(fontSize: 13.5, fontWeight: on ? FontWeight.w700 : FontWeight.w600, color: on ? PwtColors.textPri : PwtColors.textSec)),
              Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  const Dirham(size: 9, color: PwtColors.textTer),
                  const SizedBox(width: 2),
                  Text(sub, style: PwtType.caption().copyWith(fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _assurance(IconData icon, String title, String sub) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Icon(icon, size: 18, color: PwtColors.brand),
            const SizedBox(height: 6),
            Text(title, textAlign: TextAlign.center, style: PwtType.label(weight: FontWeight.w700).copyWith(fontSize: 11)),
            const SizedBox(height: 2),
            Text(sub, textAlign: TextAlign.center, style: PwtType.caption().copyWith(fontSize: 9.5)),
          ],
        ),
      ),
    );
  }
}

String _fmtInt(int v) => v.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
