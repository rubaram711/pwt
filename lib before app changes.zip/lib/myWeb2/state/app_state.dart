import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Services/dio_service.dart';
import '../../Models/Auth/user_model.dart';
import '../../Backend/Promotions/validate_promotion.dart';
import '../../Backend/Reference/get_public_settings.dart';
import '../../Models/Products/products_model.dart';

/// One line in the cart.
class CartLine {
  final ProductModel product;
  int qty;
  final String mode; // 'buy' | 'rent'
  CartLine({required this.product, this.qty = 1, this.mode = 'buy'});

  double get unit {
    if (mode == 'rent') {
      final rentPrice = product.prices.where((p) => p.term == 'rent').firstOrNull;
      return double.tryParse(rentPrice?.amount ?? '0') ?? 0;
    }
    return double.tryParse(product.finalPrice ?? product.startingPrice?.amount ?? '0') ?? 0;
  }

  double get lineTotal => unit * qty;

  Map<String, dynamic> toJson() => {
        'product': product.toJson(),
        'qty': qty,
        'mode': mode,
      };

  static CartLine? fromJson(Map<String, dynamic> j) {
    try {
      final productData = j['product'];
      if (productData == null) return null;
      final p = ProductModel.fromJson(productData as Map<String, dynamic>);
      return CartLine(product: p, qty: j['qty'] ?? 1, mode: j['mode'] ?? 'buy');
    } catch (_) {
      return null;
    }
  }
}

/// A scheduled maintenance visit (mirrors the prototype's `pwt_maint`).
class MaintVisit {
  List<String> devices;
  String date; // ISO yyyy-mm-dd or ''
  String slot;
  String notes;
  String status; // 'Scheduled' | 'Cancellation requested'
  MaintVisit({required this.devices, this.date = '', this.slot = '', this.notes = '', this.status = 'Scheduled'});

  Map<String, dynamic> toJson() => {
        'devices': devices,
        'date': date,
        'slot': slot,
        'notes': notes,
        'status': status,
      };

  factory MaintVisit.fromJson(Map<String, dynamic> j) => MaintVisit(
        devices: (j['devices'] as List).map((e) => e.toString()).toList(),
        date: j['date'] ?? '',
        slot: j['slot'] ?? '',
        notes: j['notes'] ?? '',
        status: j['status'] ?? 'Scheduled',
      );
}

/// Saved address (Profile).
class Address {
  int id;
  String label, line1, line2, city, postcode, country;
  bool isDefault;
  Address({required this.id, required this.label, required this.line1, this.line2 = '', required this.city, required this.postcode, this.country = 'United Kingdom', this.isDefault = false});
  String get full => [line1, line2, city, postcode, country].where((s) => s.isNotEmpty).join(', ');
}

/// Saved card (Profile).
class PayCard {
  int id;
  String brand; // VISA | MC | CARD
  String last4;
  String exp;
  bool isDefault;
  PayCard({required this.id, required this.brand, required this.last4, required this.exp, this.isDefault = false});
}

/// Global app state — single source of truth, persisted to shared_preferences.
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState instance = AppState._();

  late final DioService dioService = DioService();
  static const _kAuth  = 'pwt_auth';
  static const _kToken = 'pwt_token';
  static const _kCart  = 'pwt_cart';
  static const _kMaint = 'pwt_maint';
  static const _kLang  = 'pwt_lang';
  static const _kWa    = 'pwt_wa';

  User? user;
  String? accessToken;
  String? currentPassword;
  String? whatsappNumber;
  final List<CartLine> cart = [];
  final List<MaintVisit> maintenance = [];

  String? _appliedPromoCode;
  double _promoDiscount = 0.0;
  bool _promoLoading = false;
  String? _promoError;
  bool _promoValid = false;

  String? get appliedPromoCode => _appliedPromoCode;
  double get promoDiscount => _promoDiscount;
  bool get promoLoading => _promoLoading;
  String? get promoError => _promoError;
  bool get promoValid => _promoValid;

  /// UI language ('en' | 'ar') — mirrors the prototype's localStorage pwt_lang.
  String lang = 'en';

  bool _loaded = false;
  bool get loaded => _loaded;

  bool get isCompany => user?.isCompany ?? false;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    // language
    lang = p.getString(_kLang) ?? 'en';
    // auth
    final a = p.getString(_kAuth);
    if (a != null) {
      try {
        user = User.fromJson(jsonDecode(a));
      } catch (_) {}
    }
    accessToken = p.getString(_kToken);
    // cart — seed with the prototype's default 2 items on first ever launch
    final c = p.getString(_kCart);
    cart.clear();
    if (c != null) {
      try {
        for (final e in (jsonDecode(c) as List)) {
          final line = CartLine.fromJson(e);
          if (line != null) cart.add(line);
        }
      } catch (_) {}
    }
    // maintenance
    final m = p.getString(_kMaint);
    maintenance.clear();
    if (m != null) {
      try {
        for (final e in (jsonDecode(m) as List)) {
          maintenance.add(MaintVisit.fromJson(e));
        }
      } catch (_) {}
    }
    // whatsapp number — serve from cache instantly, refresh in background
    whatsappNumber = p.getString(_kWa);
    _refreshPublicSettings(p);
    _loaded = true;
    notifyListeners();
  }

  Future<void> _refreshPublicSettings(SharedPreferences p) async {
    try {
      final result = await getPublicSettings();
      if (result.success && result.data?.whatsappNumber != null) {
        whatsappNumber = result.data!.whatsappNumber;
        await p.setString(_kWa, whatsappNumber!);
        notifyListeners();
      }
    } catch (_) {}
  }

  // ---- auth ----
  Future<void> signIn(User u, String token) async {
    user = u;
    accessToken = token;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kAuth, jsonEncode(u.toJson()));
    await p.setString(_kToken, token);
    notifyListeners();
  }

  Future<void> signOut() async {
    user = null;
    accessToken = null;
    currentPassword = null;
    final p = await SharedPreferences.getInstance();
    await p.remove(_kAuth);
    await p.remove(_kToken);
    notifyListeners();
  }

  // ---- language ----
  Future<void> setLang(String l) async {
    if (l == lang) return;
    lang = l;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kLang, l);
    notifyListeners();
  }

  // ---- cart ----
  int get cartCount => cart.fold(0, (s, l) => s + l.qty);
  double get subtotal => cart.fold(0, (s, l) => s + l.lineTotal);
  double get vat => subtotal * 0.2;
  double get total => subtotal + vat - _promoDiscount;

  void addToCart(ProductModel product, {String mode = 'buy', int qty = 1}) {
    final existing = cart.where((l) => l.product.id == product.id && l.mode == mode).cast<CartLine?>().firstWhere((l) => l != null, orElse: () => null);
    if (existing != null) {
      existing.qty += qty;
    } else {
      cart.add(CartLine(product: product, mode: mode, qty: qty));
    }
    _persistCart();
    notifyListeners();
  }

  void incQty(CartLine l) {
    l.qty++;
    _persistCart();
    notifyListeners();
  }

  void decQty(CartLine l) {
    if (l.qty > 1) {
      l.qty--;
      _persistCart();
      notifyListeners();
    }
  }

  void removeLine(CartLine l) {
    cart.remove(l);
    _persistCart();
    notifyListeners();
  }

  Future<void> _persistCart() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kCart, jsonEncode(cart.map((l) => l.toJson()).toList()));
  }

  Future<bool> applyPromo(String code) async {
    _promoLoading = true;
    _promoError = null;
    notifyListeners();

    final result = await validatePromotion(
      code: code.trim().toUpperCase(),
      subtotal: subtotal,
      currency: 'AED',
    );

    _promoLoading = false;

    if (result.success && result.data != null) {
      final promo = result.data!;
      if (promo.valid) {
        _appliedPromoCode = promo.code;
        _promoDiscount = double.tryParse(promo.appliedAmount ?? '0') ?? 0;
        _promoValid = true;
        _promoError = null;
      } else {
        _appliedPromoCode = null;
        _promoDiscount = 0;
        _promoValid = false;
        _promoError = _reasonMessage(promo.reasonCode);
      }
    } else {
      _appliedPromoCode = null;
      _promoDiscount = 0;
      _promoValid = false;
      _promoError = result.message ?? 'Could not validate code. Try again.';
    }

    notifyListeners();
    return _promoValid;
  }

  void clearPromo() {
    _appliedPromoCode = null;
    _promoDiscount = 0;
    _promoValid = false;
    _promoError = null;
    notifyListeners();
  }

  String _reasonMessage(String code) {
    switch (code) {
      case 'expired': return 'This promo code has expired.';
      case 'not_started': return 'This promo code is not active yet.';
      case 'usage_limit_reached': return 'This promo code has reached its usage limit.';
      case 'user_limit_reached': return 'You have already used this promo code.';
      case 'min_order_not_met': return 'Minimum order amount not reached.';
      case 'not_applicable': return 'This code does not apply to items in your cart.';
      case 'invalid_code': return 'Invalid promo code.';
      default: return 'Promo code could not be applied.';
    }
  }

  // ---- maintenance ----
  void addMaintenance(MaintVisit v) {
    maintenance.insert(0, v);
    _persistMaint();
    notifyListeners();
  }

  void updateMaintenance(int idx, MaintVisit v) {
    if (idx >= 0 && idx < maintenance.length) {
      maintenance[idx] = v;
      _persistMaint();
      notifyListeners();
    }
  }

  void removeMaintenance(int idx) {
    if (idx >= 0 && idx < maintenance.length) {
      maintenance.removeAt(idx);
      _persistMaint();
      notifyListeners();
    }
  }

  Future<void> _persistMaint() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kMaint, jsonEncode(maintenance.map((v) => v.toJson()).toList()));
  }
}
