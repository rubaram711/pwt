// Business shell: Fleet (devices) · Requests (maintenance schedules) · Orders
// (with quotations) · Shop. Ported from proto/business.jsx, plus the
// ScheduleMaintenance + Quotation flows from proto/account.jsx.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/chrome.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import 'account_screens.dart';
import 'cart_screen.dart';
import 'individual_screens.dart';
import '../../myWeb2/state/app_state.dart' as web;
import '../../Backend/Machines/get_machines.dart';
import '../../Backend/Maintenance/create_maintenance_request.dart';
import '../../Backend/Maintenance/get_maintenance_requests.dart';
import '../../Backend/Orders/get_orders.dart';
import '../../Models/Orders/order_model.dart';
import '../../Models/Pagination/pagination_model.dart';
import '../../Models/Machines/machines_model.dart';
import '../../Models/Maintenance/maintenance_request_model.dart';
import '../../Models/Products/products_model.dart';
import 'overlays.dart';
import 'product_detail_screen.dart';


class BusinessShell extends StatefulWidget {
  const BusinessShell({super.key, required this.onLogout, this.isNew = false});
  final VoidCallback onLogout;
  final bool isNew;

  @override
  State<BusinessShell> createState() => _BusinessShellState();
}

class _BusinessShellState extends State<BusinessShell> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String _tab = 'devices';
  int _requestVersion = 0;
  List<MachineModel> _machines = [];
  bool _loadingMachines = true;
  bool _loadingMoreMachines = false;
  int _machinesPage = 1;
  PaginationModel? _machinesPagination;
  int _statRented = 0;
  int _statPurchased = 0;

  @override
  void initState() {
    super.initState();
    _loadMachines();
  }

  Future<void> _loadMachines({int page = 1, bool append = false}) async {
    if (append) {
      setState(() => _loadingMoreMachines = true);
    } else {
      setState(() => _loadingMachines = true);
    }
    final res = await getMachines(page: page);
    if (!mounted) return;
    final stats = page == 1 ? (res.data?.meta?['stats'] as Map<String, dynamic>?) : null;
    setState(() {
      if (res.success && res.data != null) {
        _machines = append ? [..._machines, ...res.data!.items] : res.data!.items;
        _machinesPagination = res.data!.pagination;
        _machinesPage = page;
        if (stats != null) {
          _statRented    = stats['rented'] as int? ?? 0;
          _statPurchased = stats['purchased'] as int? ?? 0;
        }
      }
      _loadingMachines = false;
      _loadingMoreMachines = false;
    });
  }

  AppUser get _user {
    final u = web.AppState.instance.user;
    return AppUser(
      name: u?.name ?? '',
      initials: u?.initials ?? 'PW',
      phone: u?.phone ?? '',
      email: u?.email ?? '',
      kind: AccountKind.business,
      addressLabel: '',
      company: u?.companyName != null && u!.companyName!.isNotEmpty
          ? Company(
              name: u.companyName!,
              trn: '',
              industry: '',
              address: '',
              contact: u.name ?? '',
              email: u.email ?? '',
            )
          : null,
    );
  }

  void _onDrawerSelect(String key) {
    Navigator.of(context).pop();
    switch (key) {
      case 'logout':
        widget.onLogout();
      case 'profile':
        _push(ProfileScreen(user: _user, role: AccountKind.business));
      case 'settings':
        _push(const SettingsScreen());
      case 'invoices':
        _push(InvoicesScreen(invoices: MockData.businessInvoices));
    }
  }

  void _push(Widget screen) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));

  Future<void> _openSchedule({List<MachineModel>? presetMachines}) async {
    final submitted = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => ScheduleMaintenanceScreen(presetMachines: presetMachines ?? const [])),
    );
    if (submitted == true) setState(() => _requestVersion++);
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final tabs = ['devices', 'requests', 'orders', 'products'];

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: PwtColors.bg,
      endDrawer: ProfileDrawer(user: _user, onSelect: _onDrawerSelect),
      floatingActionButton: FloatingCart(onTap: () => _push(const CartScreen(role: AccountKind.business))),
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: tabs.indexOf(_tab),
          children: [
            widget.isNew
                ? _BusinessEmpty(user: _user, onProfile: () => _scaffoldKey.currentState?.openEndDrawer(), onBrowse: () => setState(() => _tab = 'products'))
                : BusinessDevicesScreen(
                    user: _user,
                    machines: _machines,
                    loading: _loadingMachines,
                    loadingMore: _loadingMoreMachines,
                    rented: _statRented,
                    purchased: _statPurchased,
                    onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
                    onMaintenance: (m) => _openSchedule(presetMachines: [m]),
                    onLoadMore: (_machinesPagination != null && _machinesPage < (_machinesPagination!.lastPage ?? 1) && !_loadingMoreMachines)
                        ? () => _loadMachines(page: _machinesPage + 1, append: true)
                        : null,
                  ),
            BusinessRequestsScreen(
              key: ValueKey(_requestVersion),
              user: _user,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onSchedule: () => _openSchedule(),
            ),
            BusinessOrdersScreen(
              user: _user,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
            ),
            ProductsScreen(
              user: _user,
              role: AccountKind.business,
              onProfile: () => _scaffoldKey.currentState?.openEndDrawer(),
              onOpenProduct: (p) => _push(ProductDetailScreen(product: p, role: AccountKind.business)),
            ),
          ],
        ),
      ),
      bottomNavigationBar: PwtBottomNav(
        active: _tab,
        onChanged: (k) => setState(() => _tab = k),
        items: [
          PwtNavItem(key: 'devices', label: s['devices']!, icon: PwtIcons.drop),
          PwtNavItem(key: 'requests', label: s['requests']!, icon: PwtIcons.wrench),
          PwtNavItem(key: 'orders', label: s['orders']!, icon: PwtIcons.orders),
          PwtNavItem(key: 'products', label: s['shop']!, icon: PwtIcons.cube),
        ],
      ),
    );
  }
}

// ─── Fleet ───
class BusinessDevicesScreen extends StatelessWidget {
  const BusinessDevicesScreen({super.key, required this.user, required this.machines, required this.loading, this.loadingMore = false, required this.rented, required this.purchased, required this.onProfile, required this.onMaintenance, this.onLoadMore});
  final AppUser user;
  final List<MachineModel> machines;
  final bool loading;
  final bool loadingMore;
  final int rented;
  final int purchased;
  final VoidCallback onProfile;
  final ValueChanged<MachineModel> onMaintenance;
  final VoidCallback? onLoadMore;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final total = rented + purchased;

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: user, onProfile: onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Pill(label: s['business']!),
                  const SizedBox(width: 10),
                  Expanded(child: Text(user.company!.name, overflow: TextOverflow.ellipsis, style: PwtType.caption().copyWith(fontSize: 12))),
                ],
              ),
              const SizedBox(height: 14),
              PwtCard(
                padding: EdgeInsets.zero,
                child: Row(
                  children: [
                    _stat(s['devicesCount']!, Text('$total', style: _statStyle), '${s['rent']} · ${s['buy']}'),
                    _stat(s['rent']!, Text('$rented', style: _statStyle.copyWith(color: rented > 0 ? PwtColors.brand : PwtColors.textTer)), 'rented devices', divider: true),
                    _stat(s['buy']!, Text('$purchased', style: _statStyle.copyWith(color: purchased > 0 ? PwtColors.success : PwtColors.textTer)), 'purchased', divider: true),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(s['allDevices']!, style: PwtType.subtitle().copyWith(fontSize: 17)),
              Text('$total', style: PwtType.mono(size: 12, color: PwtColors.textTer)),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: loading
              ? const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 32), child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)))
              : machines.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.symmetric(vertical: 24),
                      child: Center(child: Text('No devices found.', style: PwtType.body(color: PwtColors.textSec))),
                    )
                  : Column(
                      children: [
                        for (final m in machines)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _BusinessDeviceCard(machine: m, onMaintenance: () => onMaintenance(m)),
                          ),
                        if (loadingMore)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
                          )
                        else if (onLoadMore != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: PwtButton(label: 'Load more', variant: PwtButtonVariant.soft, full: true, onPressed: onLoadMore),
                          ),
                      ],
                    ),
        ),
      ],
    );
  }

  static const _statStyle = TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -0.4, color: PwtColors.textPri);

  Widget _stat(String label, Widget value, String sub, {bool divider = false}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        decoration: BoxDecoration(border: divider ? const Border(left: BorderSide(color: PwtColors.hairline)) : null),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            value,
            const SizedBox(height: 2),
            Text(sub, style: PwtType.caption().copyWith(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _BusinessDeviceCard extends StatelessWidget {
  const _BusinessDeviceCard({required this.machine, required this.onMaintenance});
  final MachineModel machine;
  final VoidCallback onMaintenance;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final nextDue = machine.nextMaintenanceDueAt;
    final overdue = nextDue != null && (() { try { return DateTime.parse(nextDue).isBefore(DateTime.now()); } catch (_) { return false; } })();
    final isRent = machine.term == 'rent';
    final code = machine.product.code;
    final imgPath = 'assets/products/$code.png';
    final machineId = machine.publicId.isNotEmpty ? machine.publicId : machine.serialNumber;

    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 72,
                  decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                  alignment: Alignment.center,
                  child: hasLocalAsset(imgPath)
                      ? Image(image: pwtImage(imgPath), height: 56, fit: BoxFit.contain)
                      : (machine.product.imageUrl != null && machine.product.imageUrl!.isNotEmpty
                          ? Image.network(machine.product.imageUrl!, height: 56, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined, size: 28, color: PwtColors.brand))
                          : const Icon(Icons.water_drop_outlined, size: 28, color: PwtColors.brand)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Pill(label: isRent ? s['rent']! : s['buy']!, color: isRent ? PwtColors.brand : PwtColors.success),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(machine.product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: PwtType.subtitle().copyWith(fontSize: 15)),
                      const SizedBox(height: 2),
                      Directionality(textDirection: TextDirection.ltr, child: Text(machineId, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              children: [
                Expanded(child: _svc(isRent ? s['rent']! : s['purchased']!, fmtDeviceDate(machine.installedAt) ?? '—', false)),
                if (machine.nextMaintenanceDueAt != null)
                  Expanded(child: _svc(s['nextService']!, '${fmtDeviceDate(machine.nextMaintenanceDueAt)!}${overdue ? ' · ${app.isArabic ? 'متأخر' : 'overdue'}' : ''}', overdue, divider: true)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              children: [
                Expanded(child: PwtButton(label: s['requestMaintenance']!, variant: overdue ? PwtButtonVariant.primary : PwtButtonVariant.ghost, size: PwtButtonSize.sm, icon: PwtIcons.wrench, onPressed: onMaintenance)),
                if (isRent) ...[
                  const SizedBox(width: 8),
                  Expanded(child: PwtButton(label: s['payNow']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.sm, icon: PwtIcons.card)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _svc(String label, String value, bool overdue, {bool divider = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(border: divider ? const Border(left: BorderSide(color: PwtColors.hairline)) : null),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label.toUpperCase(), style: PwtType.eyebrow().copyWith(fontSize: 10, letterSpacing: 1, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(value, style: PwtType.label(color: overdue ? PwtColors.error : PwtColors.textPri, weight: FontWeight.w600).copyWith(fontSize: 13)),
        ],
      ),
    );
  }
}

// ─── Requests ───
class BusinessRequestsScreen extends StatefulWidget {
  const BusinessRequestsScreen({super.key, required this.user, required this.onProfile, required this.onSchedule});
  final AppUser user;
  final VoidCallback onProfile;
  final VoidCallback onSchedule;

  @override
  State<BusinessRequestsScreen> createState() => _BusinessRequestsScreenState();
}

class _BusinessRequestsScreenState extends State<BusinessRequestsScreen> {
  List<MaintenanceRequestModel> _requests = [];
  bool _loading = true;
  bool _loadingMore = false;
  int _page = 1;
  PaginationModel? _pagination;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({int page = 1, bool append = false}) async {
    if (append) {
      setState(() => _loadingMore = true);
    } else {
      setState(() { _loading = true; _requests = []; });
    }
    final res = await getMaintenanceRequests(page: page);
    if (!mounted) return;
    setState(() {
      if (res.success && res.data != null) {
        _requests = append ? [..._requests, ...res.data!.items] : res.data!.items;
        _pagination = res.data!.pagination;
        _page = page;
      }
      _loading = false;
      _loadingMore = false;
    });
  }

  void _loadMore() => _load(page: _page + 1, append: true);

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: widget.user, onProfile: widget.onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Eyebrow(s['requests']!),
              const SizedBox(height: 4),
              Text(s['maintenanceRequests']!, style: PwtType.headline().copyWith(fontSize: 28)),
            ],
          ),
        ),
        if (_loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 60),
            child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
          )
        else if (_requests.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(30, 60, 30, 0),
            child: Column(
              children: [
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(color: PwtColors.brandTint, shape: BoxShape.circle, border: Border.all(color: PwtColors.brandBorder)),
                  child: const Icon(PwtIcons.wrench, size: 48, color: PwtColors.brand),
                ),
                const SizedBox(height: 22),
                Text(s['noRequestsYet']!, style: PwtType.title().copyWith(fontSize: 22)),
                const SizedBox(height: 8),
                Text(s['noRequestsSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
                const SizedBox(height: 24),
                PwtButton(label: s['scheduleMaintenance']!, full: true, icon: PwtIcons.plus, onPressed: widget.onSchedule),
              ],
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${_requests.length} ${s['upcoming']!.toLowerCase()}', style: PwtType.caption().copyWith(fontSize: 13)),
                    PwtButton(label: s['scheduleMaintenance']!, variant: PwtButtonVariant.soft, size: PwtButtonSize.sm, icon: PwtIcons.plus, onPressed: widget.onSchedule),
                  ],
                ),
                const SizedBox(height: 12),
                for (final req in _requests)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _RequestCard(request: req),
                  ),
                if (_pagination != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Page $_page of ${_pagination!.lastPage ?? 1} · ${_pagination!.total ?? _requests.length} total',
                    textAlign: TextAlign.center,
                    style: PwtType.caption().copyWith(fontSize: 12),
                  ),
                  if (_page < (_pagination!.lastPage ?? 1)) ...[
                    const SizedBox(height: 12),
                    if (_loadingMore)
                      const Center(child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand),
                      ))
                    else
                      PwtButton(label: 'Load more', variant: PwtButtonVariant.soft, full: true, onPressed: _loadMore),
                  ],
                ],
              ],
            ),
          ),
      ],
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({required this.request});
  final MaintenanceRequestModel request;

  static const _issueLabels = {
    'filter_change': 'Filter Change',
    'leak': 'Leak',
    'noise': 'Noise',
    'low_pressure': 'Low Pressure',
    'water_quality': 'Water Quality',
    'error_code': 'Error Code',
    'installation_fix': 'Installation Fix',
    'other': 'Other',
  };

  Color _statusColor(String st) => switch (st) {
    'pending'     => PwtColors.warning,
    'scheduled'   => PwtColors.brand,
    'in_progress' => PwtColors.brand,
    'completed'   => PwtColors.success,
    _             => PwtColors.textSec,
  };

  String _statusLabel(String st) => switch (st) {
    'pending'     => 'Pending',
    'scheduled'   => 'Scheduled',
    'in_progress' => 'In Progress',
    'completed'   => 'Completed',
    'cancelled'   => 'Cancelled',
    _             => st,
  };

  @override
  Widget build(BuildContext context) {
    final r = request;
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(r.publicId, style: PwtType.mono(size: 11.5, color: PwtColors.brand, weight: FontWeight.w600)),
                ),
                const SizedBox(width: 10),
                Pill(label: _statusLabel(r.status), color: _statusColor(r.status), dot: true),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                const Icon(PwtIcons.wrench, size: 16, color: PwtColors.textTer),
                const SizedBox(width: 8),
                Text(_issueLabels[r.issueType] ?? r.issueType, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13)),
                const SizedBox(width: 6),
                Expanded(
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(
                      r.preferredTime != null ? '· ${r.preferredDate}  ${r.preferredTime}' : '· ${r.preferredDate}',
                      style: PwtType.label(color: PwtColors.textTer).copyWith(fontSize: 13),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: Text(r.machine.serialNumber, style: PwtType.mono(size: 11, color: PwtColors.textTer)),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Orders ───
class BusinessOrdersScreen extends StatefulWidget {
  const BusinessOrdersScreen({super.key, required this.user, required this.onProfile});
  final AppUser user;
  final VoidCallback onProfile;

  @override
  State<BusinessOrdersScreen> createState() => _BusinessOrdersScreenState();
}

class _BusinessOrdersScreenState extends State<BusinessOrdersScreen> {
  bool _loading = true;
  bool _loadingMore = false;
  bool _sortDesc = true;
  List<OrderModel> _orders = [];
  int _page = 1;
  PaginationModel? _pagination;

  static const _monthsShort = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({int page = 1, bool append = false}) async {
    if (append) {
      setState(() => _loadingMore = true);
    } else {
      setState(() { _loading = true; _orders = []; });
    }
    final res = await getOrders(page: page);
    if (!mounted) return;
    setState(() {
      if (res.success && res.data != null) {
        if (append) {
          _orders = [..._orders, ...res.data!.items];
        } else {
          _orders = res.data!.items;
        }
        _pagination = res.data!.pagination;
        _page = page;
      }
      _loading = false;
      _loadingMore = false;
    });
  }

  void _loadMore() => _load(page: _page + 1, append: true);

  String _fmtDate(String? iso) {
    if (iso == null) return '—';
    try {
      final dt = DateTime.parse(iso);
      return '${dt.day} ${_monthsShort[dt.month - 1]} ${dt.year}';
    } catch (_) { return '—'; }
  }

  String _shortId(String publicId) =>
      '#${publicId.length >= 8 ? publicId.substring(0, 8).toUpperCase() : publicId.toUpperCase()}';

  Color _statusColor(String st) => switch (st) {
    'pending'   => PwtColors.warning,
    'confirmed' => PwtColors.brand,
    'scheduled' => PwtColors.brand,
    'completed' => PwtColors.success,
    'cancelled' => PwtColors.error,
    _           => PwtColors.textSec,
  };

  String _statusLabel(String st) => switch (st) {
    'pending'   => 'Pending',
    'confirmed' => 'Confirmed',
    'scheduled' => 'Scheduled',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    _           => st,
  };

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final orders = [..._orders];
    if (!_sortDesc) orders.sort((a, b) => (a.placedAt ?? '').compareTo(b.placedAt ?? ''));

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(user: widget.user, onProfile: widget.onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Eyebrow(context.watch<AppState>().isArabic ? 'طلبيات شركتك' : 'Company orders'),
                  const SizedBox(height: 4),
                  Text(s['orders']!, style: PwtType.headline().copyWith(fontSize: 28)),
                ],
              ),
              GestureDetector(
                onTap: () { setState(() { _sortDesc = !_sortDesc; _page = 1; }); _load(); },
                child: Container(
                  height: 36,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    children: [
                      const Icon(PwtIcons.sort, size: 15, color: PwtColors.textSec),
                      const SizedBox(width: 6),
                      Text(_sortDesc ? s['newestFirst']! : s['oldestFirst']!, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 60),
            child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
          )
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              children: [
                for (final o in orders)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _orderCard(o, s),
                  ),
                if (_pagination != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Page $_page of ${_pagination!.lastPage ?? 1} · ${_pagination!.total ?? _orders.length} total',
                    textAlign: TextAlign.center,
                    style: PwtType.caption().copyWith(fontSize: 12),
                  ),
                  if (_page < (_pagination!.lastPage ?? 1)) ...[
                    const SizedBox(height: 12),
                    if (_loadingMore)
                      const Center(child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand),
                      ))
                    else
                      PwtButton(
                        label: 'Load more',
                        variant: PwtButtonVariant.soft,
                        full: true,
                        onPressed: _loadMore,
                      ),
                  ],
                ],
              ],
            ),
          ),
      ],
    );
  }

  Widget _orderCard(OrderModel o, Map<String, String> s) {
    return PwtCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Directionality(textDirection: TextDirection.ltr, child: Text(_shortId(o.publicId), style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
              Pill(label: _statusLabel(o.status), color: _statusColor(o.status), dot: true),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Flexible(
                child: Text(
                  o.firstProductName ?? 'Order #${o.id}',
                  style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (o.remainingItemsCount > 0) ...[
                const SizedBox(width: 6),
                _MorePill('+${o.remainingItemsCount}'),
              ],
            ],
          ),
          const SizedBox(height: 4),
          Text('${s['placed']} ${_fmtDate(o.placedAt)}', style: PwtType.caption().copyWith(fontSize: 12)),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Divider(height: 1, color: PwtColors.hairline),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text('${o.currency} ', style: PwtType.caption().copyWith(fontSize: 12, fontWeight: FontWeight.w600)),
                  Text(o.totalAmount, style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                  if (o.term == 'rent') Text(s['perMonth']!, style: PwtType.caption()),
                ],
              ),
              const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
            ],
          ),
        ],
      ),
    );
  }
}

class _MorePill extends StatelessWidget {
  const _MorePill(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(color: PwtColors.brandTint, borderRadius: BorderRadius.circular(999)),
    child: Text(text, style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w700)),
  );
}

// ─── Empty fleet ───
class _BusinessEmpty extends StatelessWidget {
  const _BusinessEmpty({required this.user, required this.onProfile, required this.onBrowse});
  final AppUser user;
  final VoidCallback onProfile;
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return ListView(
      children: [
        AppHeader(user: user, onProfile: onProfile),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(
            children: [
              Pill(label: s['business']!),
              const SizedBox(width: 10),
              Expanded(child: Text(user.company!.name, overflow: TextOverflow.ellipsis, style: PwtType.caption().copyWith(fontSize: 12))),
            ],
          ),
        ),
        const SizedBox(height: 40),
        Center(
          child: Container(
            width: 110,
            height: 110,
            decoration: BoxDecoration(color: PwtColors.brandTint, shape: BoxShape.circle, border: Border.all(color: PwtColors.brandBorder)),
            child: const Icon(PwtIcons.briefcase, size: 48, color: PwtColors.brand),
          ),
        ),
        const SizedBox(height: 22),
        Center(child: Text(s['noFleetYet']!, style: PwtType.title().copyWith(fontSize: 22))),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(s['noFleetSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: PwtButton(label: s['exploreProducts']!, full: true, icon: PwtIcons.cube, onPressed: onBrowse),
        ),
      ],
    );
  }
}

// ═══════════════ SCHEDULE MAINTENANCE (multi-step) ═══════════════
class ScheduleMaintenanceScreen extends StatefulWidget {
  const ScheduleMaintenanceScreen({super.key, this.presetMachines = const []});
  final List<MachineModel> presetMachines;

  @override
  State<ScheduleMaintenanceScreen> createState() => _ScheduleMaintenanceScreenState();
}

class _ScheduleMaintenanceScreenState extends State<ScheduleMaintenanceScreen> {
  late String _step;
  List<MachineModel> _allMachines = [];
  bool _loadingMachines = false;
  bool _loadingMoreMachines = false;
  int _machinesPage = 1;
  PaginationModel? _machinesPagination;
  late List<MachineModel> _selectedMachines;
  DateTime? _selectedDate;
  int _slot = 0;
  final _notes = TextEditingController();
  bool _submitting = false;

  static const _slots = ['Morning (8AM – 12PM)', 'Afternoon (12PM – 4PM)', 'Evening (4PM – 7PM)'];
  static const _monthsShort = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  static const _issueTypes = ['filter_change', 'leak', 'noise', 'low_pressure', 'water_quality', 'error_code', 'installation_fix', 'other'];
  static const _issueLabels = {'filter_change': 'Filter Change', 'leak': 'Leak', 'noise': 'Noise', 'low_pressure': 'Low Pressure', 'water_quality': 'Water Quality', 'error_code': 'Error Code', 'installation_fix': 'Installation Fix', 'other': 'Other'};
  String _issueType = 'filter_change';

  @override
  void initState() {
    super.initState();
    _selectedMachines = List.of(widget.presetMachines);
    _step = widget.presetMachines.isNotEmpty ? 'when' : 'select';
    if (_step == 'select') _loadMachines();
    _notes.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _notes.dispose();
    super.dispose();
  }

  Future<void> _loadMachines({int page = 1, bool append = false}) async {
    if (append) {
      setState(() => _loadingMoreMachines = true);
    } else {
      setState(() => _loadingMachines = true);
    }
    final res = await getMachines(page: page);
    if (!mounted) return;
    setState(() {
      if (res.success && res.data != null) {
        _allMachines = append ? [..._allMachines, ...res.data!.items] : res.data!.items;
        _machinesPagination = res.data!.pagination;
        _machinesPage = page;
      }
      _loadingMachines = false;
      _loadingMoreMachines = false;
    });
  }

  String _fmtDisplay(DateTime d) {
    return '${d.day} ${_monthsShort[d.month - 1]} ${d.year}';
  }

  String _fmtApi(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _submit() async {
    if (_selectedMachines.isEmpty || _selectedDate == null) return;
    setState(() => _submitting = true);
    final m = _selectedMachines.first;
    final res = await submitMaintenanceRequest(
      machineId: m.id,
      issueType: _issueType,
      description: _notes.text.trim().isEmpty ? '' : _notes.text.trim(),
      preferredDate: _fmtApi(_selectedDate!),
      preferredTime: _slots[_slot],
    );
    if (!mounted) return;
    setState(() => _submitting = false);
    if (res.success) {
      setState(() => _step = 'success');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message ?? 'Request failed'), backgroundColor: PwtColors.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;

    return DetailScaffold(
      title: s['scheduleMaintenance'],
      onBack: _step == 'when' && widget.presetMachines.isEmpty
          ? () => setState(() => _step = 'select')
          : () => Navigator.pop(context),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          if (_step == 'select') ...[
            Text(s['selectDevices']!, style: PwtType.title().copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text(s['selectDevicesSub']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
            const SizedBox(height: 14),
            if (_loadingMachines)
              const Center(child: Padding(
                padding: EdgeInsets.symmetric(vertical: 32),
                child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand),
              ))
            else
              for (final m in _allMachines)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _deviceCheck(m, _selectedMachines.contains(m), () {
                    setState(() {
                      if (_selectedMachines.contains(m)) {
                        _selectedMachines.remove(m);
                      } else {
                        _selectedMachines.add(m);
                      }
                    });
                  }),
                ),
            if (!_loadingMachines) ...[
              if (_loadingMoreMachines)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
                )
              else if (_machinesPagination != null && _machinesPage < (_machinesPagination!.lastPage ?? 1))
                Padding(
                  padding: const EdgeInsets.only(top: 4, bottom: 4),
                  child: PwtButton(label: 'Load more', variant: PwtButtonVariant.soft, full: true, onPressed: () => _loadMachines(page: _machinesPage + 1, append: true)),
                ),
            ],
          ],
          if (_step == 'when') ...[
            Text(s['pickDate']!, style: PwtType.title().copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text('${_selectedMachines.length} ${s['devicesLabel']!.toLowerCase()} · ${s['devicesSelectedN']}', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
            const SizedBox(height: 20),
            // ── date picker ──
            Eyebrow(ar ? 'التاريخ المفضّل' : 'Preferred date'),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now().add(const Duration(days: 1)),
                  firstDate: DateTime.now().add(const Duration(days: 1)),
                  lastDate: DateTime.now().add(const Duration(days: 180)),
                );
                if (d != null) setState(() => _selectedDate = d);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                decoration: BoxDecoration(
                  color: PwtColors.surface,
                  border: Border.all(color: _selectedDate != null ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
                  borderRadius: BorderRadius.circular(PwtRadius.md),
                ),
                child: Row(
                  children: [
                    Icon(PwtIcons.cal, size: 18, color: _selectedDate != null ? PwtColors.brand : PwtColors.textTer),
                    const SizedBox(width: 10),
                    Text(
                      _selectedDate == null
                          ? (ar ? 'اختر تاريخاً' : 'Select a date')
                          : _fmtDisplay(_selectedDate!),
                      style: PwtType.body(color: _selectedDate != null ? PwtColors.textPri : PwtColors.textTer),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // ── time slot ──
            Eyebrow(ar ? 'الوقت المناسب' : 'Time slot'),
            const SizedBox(height: 10),
            Column(
              children: [
                for (int i = 0; i < _slots.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _slotChip(i, ar),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            // ── issue type ──
            Eyebrow(ar ? 'نوع المشكلة' : 'Issue type'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _issueType,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(PwtRadius.md), borderSide: const BorderSide(color: PwtColors.hairline2)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(PwtRadius.md), borderSide: const BorderSide(color: PwtColors.brand, width: 1.5)),
              ),
              items: _issueTypes.map((t) => DropdownMenuItem(
                value: t,
                child: Text(_issueLabels[t]!, style: PwtType.body()),
              )).toList(),
              onChanged: (v) { if (v != null) setState(() => _issueType = v); },
            ),
            const SizedBox(height: 20),
            // ── notes ──
            Eyebrow(ar ? 'ملاحظات' : 'Notes'),
            const SizedBox(height: 8),
            TextField(
              controller: _notes,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: ar ? 'تعليمات الوصول أو معلومات التواصل…' : 'Access instructions, on-site contact…',
                hintStyle: PwtType.body(color: PwtColors.textTer),
                contentPadding: const EdgeInsets.all(12),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(PwtRadius.md), borderSide: const BorderSide(color: PwtColors.hairline2)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(PwtRadius.md), borderSide: const BorderSide(color: PwtColors.brand, width: 1.5)),
              ),
            ),
            const SizedBox(height: 20),
            // ── selected devices ──
            Section(
              title: s['devicesLabel']!,
              child: PwtCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: [
                    for (int i = 0; i < _selectedMachines.length; i++)
                      ListRow(
                        leading: PwtIcons.drop,
                        title: _selectedMachines[i].product.name,
                        sub: _selectedMachines[i].publicId.isNotEmpty
                            ? _selectedMachines[i].publicId
                            : _selectedMachines[i].serialNumber,
                        last: i == _selectedMachines.length - 1,
                      ),
                  ],
                ),
              ),
            ),
          ],
          if (_step == 'success')
            SuccessView(
              title: s['scheduledTitle']!,
              body: s['scheduledBody']!,
              accent: PwtColors.brand,
              detail: PwtCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    ListRow(leading: PwtIcons.cal, title: _selectedDate != null ? _fmtDisplay(_selectedDate!) : '—', sub: _slots[_slot]),
                    ListRow(leading: PwtIcons.drop, title: '${_selectedMachines.length} ${s['devicesLabel']}', sub: _selectedMachines.map((m) => m.product.name).join(', '), last: true),
                  ],
                ),
              ),
            ),
        ],
      ),
      bottomBar: switch (_step) {
        'select' => PwtButton(
            label: '${s['continueLabel']}${_selectedMachines.isNotEmpty ? ' · ${_selectedMachines.length}' : ''}',
            full: true,
            disabled: _selectedMachines.isEmpty,
            onPressed: () => setState(() => _step = 'when'),
          ),
        'when' => PwtButton(
            label: _submitting ? '...' : s['scheduleVisitCta']!,
            full: true,
            disabled: _submitting || _selectedDate == null || _notes.text.trim().isEmpty,
            onPressed: (_submitting || _selectedDate == null || _notes.text.trim().isEmpty) ? null : _submit,
          ),
        _ => PwtButton(
            label: s['done']!,
            full: true,
            onPressed: () => Navigator.pop(context, true),
          ),
      },
    );
  }

  Widget _deviceCheck(MachineModel m, bool on, VoidCallback onTap) {
    final imgPath = 'assets/products/${m.product.code}.png';
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(PwtRadius.md),
        ),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: on ? PwtColors.brand : PwtColors.surface,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
              ),
              child: on ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
            ),
            const SizedBox(width: 12),
            Container(
              width: 40, height: 50,
              decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(9), border: Border.all(color: PwtColors.hairline)),
              alignment: Alignment.center,
              child: hasLocalAsset(imgPath)
                  ? Image(image: pwtImage(imgPath), height: 38, fit: BoxFit.contain)
                  : (m.product.imageUrl != null && m.product.imageUrl!.isNotEmpty
                      ? Image.network(m.product.imageUrl!, height: 38, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined, size: 20, color: PwtColors.brand))
                      : const Icon(Icons.water_drop_outlined, size: 20, color: PwtColors.brand)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(m.product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                  const SizedBox(height: 2),
                  Directionality(textDirection: TextDirection.ltr, child: Text(m.publicId.isNotEmpty ? m.publicId : m.serialNumber, style: PwtType.mono(size: 11.5, color: PwtColors.textTer))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _slotChip(int i, bool ar) {
    final on = i == _slot;
    return GestureDetector(
      onTap: () => setState(() => _slot = i),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(PwtRadius.md),
        ),
        child: Row(
          children: [
            Container(
              width: 18, height: 18,
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline2, width: 2)),
              child: on ? const Center(child: SizedBox(width: 8, height: 8, child: DecoratedBox(decoration: BoxDecoration(color: PwtColors.brand, shape: BoxShape.circle)))) : null,
            ),
            const SizedBox(width: 12),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text(_slots[i], style: TextStyle(fontSize: 13.5, fontWeight: on ? FontWeight.w600 : FontWeight.w500, color: on ? PwtColors.brandDeep : PwtColors.textPri)),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════ QUOTATION (view / approve / cancel) ═══════════════
class QuotationScreen extends StatefulWidget {
  const QuotationScreen({super.key, required this.order, required this.onDecision});
  final Order order;
  final ValueChanged<String> onDecision;

  @override
  State<QuotationScreen> createState() => _QuotationScreenState();
}

class _QuotationScreenState extends State<QuotationScreen> {
  String? _result; // approved | cancelled

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final o = widget.order;
    const subtotal = 8020;
    final vat = (subtotal * 0.05);
    final total = subtotal + vat;

    if (_result != null) {
      return DetailScaffold(
        title: s['viewQuote'],
        body: ListView(
          children: [
            SuccessView(
              title: _result == 'approved' ? s['quoteApproved']! : s['cancelledStatus']!,
              body: _result == 'approved'
                  ? (app.isArabic ? 'سيتواصل فريقنا لتحديد موعد التركيب.' : 'Our team will reach out to arrange installation.')
                  : (app.isArabic ? 'تم سحب طلب العرض.' : 'Your quotation request has been withdrawn.'),
              icon: _result == 'approved' ? PwtIcons.check : PwtIcons.close,
              accent: _result == 'approved' ? PwtColors.success : PwtColors.textSec,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
              child: PwtButton(label: s['done']!, full: true, onPressed: () => Navigator.pop(context)),
            ),
          ],
        ),
      );
    }

    return DetailScaffold(
      title: s['viewQuote'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          PwtCard(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Directionality(textDirection: TextDirection.ltr, child: Text(o.id, style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
                      const SizedBox(height: 4),
                      Text(o.items, style: PwtType.subtitle().copyWith(fontSize: 17, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text('${s['placed']} ${o.date}', style: PwtType.caption().copyWith(fontSize: 12)),
                    ],
                  ),
                ),
                Pill(label: s['quotationReceived']!, color: PwtColors.info, dot: true),
              ],
            ),
          ),
          Section(
            title: s['orderSummary']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: PwtColors.hairline))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text('1× ${o.items}', style: PwtType.label().copyWith(fontSize: 13.5))),
                        _money(subtotal),
                      ],
                    ),
                  ),
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, c: PwtColors.textSec)),
                  SummaryRow(label: s['vat']!, value: _money(vat, c: PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, c: PwtColors.textPri)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, left: 4),
            child: Text(app.isArabic ? 'يشمل التركيب وأول 3 أشهر إيجار' : 'Incl. installation + first 3 months rental', style: PwtType.caption().copyWith(fontSize: 12)),
          ),
        ],
      ),
      bottomBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          PwtButton(
            label: s['approveQuote']!,
            full: true,
            icon: PwtIcons.check,
            onPressed: () {
              widget.onDecision('approved');
              setState(() => _result = 'approved');
            },
          ),
          const SizedBox(height: 10),
          PwtButton(
            label: s['cancelQuote']!,
            variant: PwtButtonVariant.ghost,
            full: true,
            icon: PwtIcons.close,
            onPressed: () async {
              final ok = await showConfirmSheet(
                context,
                title: s['cancelConfirmTitle']!,
                body: s['cancelConfirmBody']!,
                keepLabel: s['keepIt']!,
                confirmLabel: s['yesCancel']!,
              );
              if (ok) {
                widget.onDecision('cancelled');
                setState(() => _result = 'cancelled');
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _money(num v, {Color c = PwtColors.textPri}) => Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [Dirham(size: 11, color: c), const SizedBox(width: 3), Text(_fmt(v), style: TextStyle(color: c, fontWeight: FontWeight.w600, fontSize: 14))],
      );
}

String _fmt(num v) => v.toInt().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
