// Maintenance request flow + request detail. Ported from proto/overlays.jsx
// (MaintenanceFlowScreen, RequestDetailScreen).

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../../Models/Machines/machines_model.dart';
import '../../Backend/Maintenance/create_maintenance_request.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';

class MaintenanceSheet extends StatefulWidget {
  const MaintenanceSheet({super.key, required this.machine});
  final MachineModel machine;

  @override
  State<MaintenanceSheet> createState() => _MaintenanceSheetState();
}

class _MaintenanceSheetState extends State<MaintenanceSheet> {
  bool _success = false;
  bool _submitting = false;
  String _issueType = 'filter_change';
  DateTime? _selectedDate;
  int _slot = 0;
  final _notes = TextEditingController();

  static const _slots = ['Morning (8AM – 12PM)', 'Afternoon (12PM – 4PM)', 'Evening (4PM – 7PM)'];
  static const _monthsShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  static const _issueTypes = ['filter_change', 'leak', 'noise', 'low_pressure', 'water_quality', 'error_code', 'installation_fix', 'other'];
  static const _issueLabels = {
    'filter_change': 'Filter Change',
    'leak': 'Leak',
    'noise': 'Noise',
    'low_pressure': 'Low Pressure',
    'water_quality': 'Water Quality',
    'error_code': 'Error Code',
    'installation_fix': 'Installation Fix',
    'other': 'Other',
  };

  @override
  void initState() {
    super.initState();
    _notes.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _notes.dispose();
    super.dispose();
  }

  String _fmtDisplay(DateTime d) => '${d.day} ${_monthsShort[d.month - 1]} ${d.year}';

  String _fmtApi(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _submit() async {
    if (_selectedDate == null) return;
    setState(() => _submitting = true);
    final m = widget.machine;
    final res = await submitMaintenanceRequest(
      machineId: m.id,
      issueType: _issueType,
      description: _notes.text.trim(),
      preferredDate: _fmtApi(_selectedDate!),
      preferredTime: _slots[_slot],
    );
    if (!mounted) return;
    setState(() => _submitting = false);
    if (res.success) {
      setState(() => _success = true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message ?? 'Request failed'), backgroundColor: PwtColors.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;
    final d = widget.machine;

    return DetailScaffold(
      title: s['requestMaintenance'],
      onBack: () => Navigator.pop(context),
      body: _success
          ? ListView(
              children: [
                SuccessView(
                  title: ar ? 'تم استلام طلبك' : 'Request received',
                  body: ar ? 'سيصل الفني قريباً.' : 'A technician will be assigned shortly.',
                  accent: PwtColors.brand,
                  detail: PwtCard(
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: [
                        ListRow(
                          leading: PwtIcons.cal,
                          title: _fmtDisplay(_selectedDate!),
                          sub: _slots[_slot],
                        ),
                        ListRow(
                          leading: PwtIcons.message,
                          title: ar
                              ? 'سنرسل تأكيداً عبر الواتساب'
                              : "You'll get a WhatsApp confirmation",
                          last: true,
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                  child: PwtButton(label: s['done']!, full: true, onPressed: () => Navigator.pop(context)),
                ),
              ],
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: [
                // device card
                PwtCard(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 56,
                        decoration: BoxDecoration(
                          color: PwtColors.surface2,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: PwtColors.hairline),
                        ),
                        alignment: Alignment.center,
                        child: hasLocalAsset('assets/products/${d.product.code}.png')
                            ? Image(image: pwtImage('assets/products/${d.product.code}.png'), height: 42, fit: BoxFit.contain)
                            : (d.product.imageUrl != null && d.product.imageUrl!.isNotEmpty
                                ? Image.network(d.product.imageUrl!, height: 42, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined, size: 24, color: PwtColors.brand))
                                : const Icon(Icons.water_drop_outlined, size: 24, color: PwtColors.brand)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d.product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                            const SizedBox(height: 2),
                            Directionality(
                              textDirection: TextDirection.ltr,
                              child: Text(
                                d.publicId.isNotEmpty ? d.publicId : d.serialNumber,
                                style: PwtType.mono(size: 11.5, color: PwtColors.textTer),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                // issue type dropdown
                _sectionTitle(ar ? 'نوع المشكلة' : 'Issue type'),
                DropdownButtonFormField<String>(
                  value: _issueType,
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                      borderSide: const BorderSide(color: PwtColors.hairline2),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                      borderSide: const BorderSide(color: PwtColors.brand, width: 1.5),
                    ),
                  ),
                  items: _issueTypes
                      .map((t) => DropdownMenuItem(value: t, child: Text(_issueLabels[t]!, style: PwtType.body())))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _issueType = v);
                  },
                ),
                // date picker
                _sectionTitle(ar ? 'التاريخ المفضَّل' : 'Preferred date'),
                GestureDetector(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now().add(const Duration(days: 1)),
                      firstDate: DateTime.now().add(const Duration(days: 1)),
                      lastDate: DateTime.now().add(const Duration(days: 180)),
                    );
                    if (picked != null) setState(() => _selectedDate = picked);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    decoration: BoxDecoration(
                      color: PwtColors.surface,
                      border: Border.all(
                        color: _selectedDate != null ? PwtColors.brand : PwtColors.hairline2,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                    ),
                    child: Row(
                      children: [
                        Icon(PwtIcons.cal, size: 18, color: _selectedDate != null ? PwtColors.brand : PwtColors.textTer),
                        const SizedBox(width: 10),
                        Text(
                          _selectedDate == null
                              ? (ar ? 'اختر تاريخاً' : 'Select a date')
                              : _fmtDisplay(_selectedDate!),
                          style: PwtType.body(color: _selectedDate != null ? PwtColors.textPri : PwtColors.textTer),
                        ),
                      ],
                    ),
                  ),
                ),
                // time slot
                _sectionTitle(ar ? 'الوقت المناسب' : 'Time slot'),
                for (int i = 0; i < _slots.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _slotChip(i),
                  ),
                // notes
                _sectionTitle(ar ? 'ملاحظات' : 'Notes'),
                TextField(
                  controller: _notes,
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText: ar
                        ? 'تعليمات الوصول أو معلومات التواصل…'
                        : 'Access instructions, on-site contact…',
                    hintStyle: PwtType.body(color: PwtColors.textTer),
                    contentPadding: const EdgeInsets.all(12),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                      borderSide: const BorderSide(color: PwtColors.hairline2),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(PwtRadius.md),
                      borderSide: const BorderSide(color: PwtColors.brand, width: 1.5),
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                PwtButton(
                  label: _submitting ? '...' : s['confirm']!,
                  full: true,
                  disabled: _submitting || _selectedDate == null || _notes.text.trim().isEmpty,
                  onPressed: (_submitting || _selectedDate == null || _notes.text.trim().isEmpty) ? null : _submit,
                ),
              ],
            ),
    );
  }

  Widget _slotChip(int i) {
    final on = i == _slot;
    return GestureDetector(
      onTap: () => setState(() => _slot = i),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: on ? PwtColors.brandTint : PwtColors.surface,
          border: Border.all(color: on ? PwtColors.brandBorder : PwtColors.hairline, width: 1.5),
          borderRadius: BorderRadius.circular(PwtRadius.md),
        ),
        child: Row(
          children: [
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline2, width: 2),
              ),
              child: on
                  ? const Center(
                      child: SizedBox(
                        width: 8,
                        height: 8,
                        child: DecoratedBox(decoration: BoxDecoration(color: PwtColors.brand, shape: BoxShape.circle)),
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text(
                _slots[i],
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: on ? FontWeight.w600 : FontWeight.w500,
                  color: on ? PwtColors.brandDeep : PwtColors.textPri,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(top: 24, bottom: 12),
        child: Eyebrow(t),
      );
}

// ─── Request detail (business) ───
class RequestDetailScreen extends StatelessWidget {
  const RequestDetailScreen({super.key, required this.request});
  final MaintenanceRequest request;

  Color _statusColor(String st) => switch (st) {
        'scheduled' => PwtColors.brand,
        'in_progress' => PwtColors.warning,
        'completed' => PwtColors.success,
        _ => PwtColors.textSec,
      };

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final r = request;
    return DetailScaffold(
      title: '#${r.id}',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          PwtCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(r.issue, style: PwtType.subtitle().copyWith(fontSize: 17, fontWeight: FontWeight.w700))),
                    Pill(label: r.statusLabel, color: _statusColor(r.status), dot: true),
                  ],
                ),
                const SizedBox(height: 6),
                Text(r.device, style: PwtType.body(color: PwtColors.textSec)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          PwtCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                ListRow(leading: PwtIcons.cal, title: r.schedule, sub: s['timeWindow']),
                ListRow(leading: PwtIcons.user, title: r.tech, sub: s['technician']),
                ListRow(leading: PwtIcons.cube, title: r.device, sub: r.deviceId),
                ListRow(leading: PwtIcons.info, title: r.raised, sub: app.isArabic ? 'تاريخ الطلب' : 'Raised on', last: true),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
