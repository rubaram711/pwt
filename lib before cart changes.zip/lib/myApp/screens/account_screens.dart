// Account area: Profile (individual + company), Settings, Invoices, Orders.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../widgets/form_field.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import '../../myWeb2/state/app_state.dart' as web;
import '../../Backend/Users/update_user.dart';
import '../../Backend/Addresses/get_addresses.dart';
import '../../Backend/Addresses/create_address.dart';
import '../../Backend/Addresses/update_address.dart';
import '../../Backend/Addresses/delete_address.dart';
import '../../Backend/Users/PaymentCards/get_payment_cards.dart';
import '../../Backend/Users/PaymentCards/create_payment_card.dart';
import '../../Backend/Users/PaymentCards/delete_payment_card.dart';
import '../../Backend/Users/PaymentCards/set_default_payment_card.dart';
import '../../Models/address_model.dart';
import '../../Models/payment_card_model.dart';
import '../../Backend/Orders/get_orders.dart';
import '../../Models/Orders/order_model.dart';
import '../../Models/Pagination/pagination_model.dart';

// ═══════════════════════ PROFILE ═══════════════════════
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.user, required this.role});
  final AppUser user;
  final AccountKind role;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<PaymentCard> _cards = [];
  bool _loadingCards = false;
  String? _cardsError;

  @override
  void initState() {
    super.initState();
    _loadCards();
  }

  Future<void> _loadCards() async {
    setState(() { _loadingCards = true; _cardsError = null; });
    final res = await getPaymentCards();
    if (!mounted) return;
    if (res.success && res.data != null) {
      setState(() { _cards = res.data!; _loadingCards = false; });
    } else {
      setState(() { _loadingCards = false; _cardsError = res.message ?? 'Failed to load cards.'; });
    }
  }

  Future<void> _deleteCard(PaymentCard c) async {
    final confirmed = await showConfirmSheet(
      context,
      title: 'Remove card?',
      body: 'Are you sure you want to remove this card?',
      keepLabel: 'Keep',
      confirmLabel: 'Remove',
    );
    if (!confirmed || !mounted) return;
    final res = await deletePaymentCard(c.id);
    if (!mounted) return;
    if (res.success) { _loadCards(); } else { _toast(res.message ?? 'Failed to delete card.'); }
  }

  Future<void> _setDefaultCard(PaymentCard c) async {
    final res = await setDefaultPaymentCard(c.id);
    if (!mounted) return;
    if (res.success) { _loadCards(); } else { _toast(res.message ?? 'Failed to update card.'); }
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, backgroundColor: PwtColors.textPri),
  );

  void _addCardSheet(Map<String, String> s) {
    final holderCtrl = TextEditingController();
    final numCtrl    = TextEditingController();
    final monthCtrl  = TextEditingController();
    final yearCtrl   = TextEditingController();
    bool def = false;
    String? holderErr, numErr, monthErr, yearErr;

    bool validate(void Function(void Function()) set) {
      final digits     = numCtrl.text.replaceAll(RegExp(r'\D'), '');
      final monthVal   = monthCtrl.text.trim();
      final yearVal    = yearCtrl.text.trim();

      final hErr = holderCtrl.text.trim().isEmpty ? 'Cardholder name is required' : null;
      final nErr = digits.isEmpty
          ? 'Card number is required'
          : digits.length != 16
              ? 'Enter a valid 16-digit card number'
              : null;
      final mErr = !RegExp(r'^\d{2}$').hasMatch(monthVal) ? 'Must be 2 digits (e.g. 08)' : null;
      final yErr = !RegExp(r'^\d{4}$').hasMatch(yearVal)  ? 'Must be 4 digits (e.g. 2027)' : null;

      set(() { holderErr = hErr; numErr = nErr; monthErr = mErr; yearErr = yErr; });
      return hErr == null && nErr == null && mErr == null && yErr == null;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PwtColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(PwtRadius.sheet))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 28),
        child: SingleChildScrollView(
          child: StatefulBuilder(
            builder: (ctx, set) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Expanded(child: Text(s['addCardDetails'] ?? 'Add Card', style: PwtType.title().copyWith(fontSize: 19))),
                  IconButton(icon: const Icon(PwtIcons.close), onPressed: () => Navigator.pop(ctx), color: PwtColors.textPri),
                ]),
                const SizedBox(height: 12),
                PwtField(label: s['cardholderName']!, controller: holderCtrl, onChanged: (_) => set(() => holderErr = null)),
                if (holderErr != null) _fieldError(holderErr!),
                const SizedBox(height: 10),
                PwtField(
                  label: s['cardNumber']!,
                  controller: numCtrl,
                  forceLtr: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: [_CardNumberFormatter()],
                  onChanged: (_) => set(() => numErr = null),
                ),
                if (numErr != null) _fieldError(numErr!),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    PwtField(
                      label: 'Month (MM)',
                      controller: monthCtrl,
                      forceLtr: true,
                      keyboardType: TextInputType.number,
                      onChanged: (_) => set(() => monthErr = null),
                    ),
                    if (monthErr != null) _fieldError(monthErr!),
                  ])),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    PwtField(
                      label: 'Year (YYYY)',
                      controller: yearCtrl,
                      forceLtr: true,
                      keyboardType: TextInputType.number,
                      onChanged: (_) => set(() => yearErr = null),
                    ),
                    if (yearErr != null) _fieldError(yearErr!),
                  ])),
                ]),
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: () => set(() => def = !def),
                  child: Row(children: [
                    _checkbox(def),
                    const SizedBox(width: 10),
                    Text(s['setDefault']!, style: PwtType.label()),
                  ]),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(child: PwtButton(label: s['cancel']!, variant: PwtButtonVariant.secondary, full: true, onPressed: () => Navigator.pop(ctx))),
                  const SizedBox(width: 10),
                  Expanded(child: PwtButton(
                    label: s['addCardDetails'] ?? 'Add Card',
                    full: true,
                    onPressed: () {
                      if (!validate(set)) return;
                      Navigator.pop(ctx);
                      final digits   = numCtrl.text.replaceAll(RegExp(r'\D'), '');
                      final lastFour = digits.substring(digits.length - 4);
                      final brand    = digits.startsWith('4') ? 'Visa' : digits.startsWith('5') ? 'Mastercard' : 'Card';
                      createPaymentCard(
                        brand: brand,
                        lastFour: lastFour,
                        cardNumberHash: digits,
                        expiryMonth: monthCtrl.text.trim(),
                        expiryYear: yearCtrl.text.trim(),
                        cardholderName: holderCtrl.text.trim(),
                        isDefault: def,
                      ).then((res) {
                        if (!mounted) return;
                        if (res.success) { _loadCards(); } else { _toast(res.message ?? 'Failed to add card.'); }
                      });
                    },
                  )),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _fieldError(String msg) => Padding(
    padding: const EdgeInsets.only(top: 5, left: 2),
    child: Text(msg, style: PwtType.label(color: PwtColors.error).copyWith(fontSize: 12)),
  );

  Widget _checkbox(bool checked) => Container(
    width: 20,
    height: 20,
    decoration: BoxDecoration(
      color: checked ? PwtColors.brand : PwtColors.surface,
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: checked ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
    ),
    child: checked ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
  );

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final u = web.AppState.instance.user;

    return DetailScaffold(
      title: s['profile'],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          // header card
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            child: PwtCard(
              padding: const EdgeInsets.all(20),
              child: Row(children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [PwtColors.brand, PwtColors.brandDeep])),
                  alignment: Alignment.center,
                  child: Text(u?.initials ?? 'PW', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 20)),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(u?.name ?? '', style: PwtType.subtitle().copyWith(fontSize: 17)),
                  const SizedBox(height: 3),
                  if ((u?.phone ?? '').isNotEmpty)
                    Directionality(textDirection: TextDirection.ltr, child: Text(u!.phone!, style: PwtType.mono(size: 12, color: PwtColors.textTer))),
                  const SizedBox(height: 8),
                  Pill(label: widget.role == AccountKind.business ? s['business']! : s['individual']!),
                ])),
              ]),
            ),
          ),
          // personal / company info + addresses
          if (widget.role == AccountKind.business)
            _CompanyProfile(user: widget.user, onUserUpdated: () => setState(() {}))
          else
            _IndividualProfile(user: widget.user, onUserUpdated: () => setState(() {})),
          // payment details
          Section(
            title: s['paymentDetails']!,
            trailing: GestureDetector(
              onTap: () => _addCardSheet(s),
              child: Text('+ ${s['addCardDetails'] ?? 'Add'}', style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
            ),
            child: _loadingCards
                ? const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 16), child: CircularProgressIndicator(strokeWidth: 2)))
                : _cardsError != null
                    ? Text(_cardsError!, style: PwtType.label(color: PwtColors.error).copyWith(fontSize: 13))
                    : _cards.isEmpty
                        ? PwtCard(
                            padding: EdgeInsets.zero,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(s['noCardsYet']!, style: PwtType.label(weight: FontWeight.w600)),
                                const SizedBox(height: 4),
                                Text(s['noCardsSub']!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
                              ]),
                            ),
                          )
                        : PwtCard(
                            padding: EdgeInsets.zero,
                            child: Column(children: [
                              for (int i = 0; i < _cards.length; i++)
                                _cardRow(_cards[i], last: i == _cards.length - 1, s: s),
                            ]),
                          ),
          ),
        ],
      ),
    );
  }

  Widget _cardRow(PaymentCard c, {required bool last, required Map<String, String> s}) {
    final brandLower  = c.brand.toLowerCase();
    final displayName = brandLower == 'visa' ? 'Visa' : brandLower.contains('master') ? 'Mastercard' : c.brand;
    return ListRow(
      leading: PwtIcons.card,
      title: '$displayName ···· ${c.lastFour}',
      sub: c.isDefault ? s['primary'] ?? 'Primary' : 'Exp ${c.expiryMonth}/${c.expiryYear}',
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (!c.isDefault)
          GestureDetector(
            onTap: () => _setDefaultCard(c),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(s['setDefault']!, style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12)),
            ),
          ),
        GestureDetector(
          onTap: () => _deleteCard(c),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(PwtIcons.trash, size: 18, color: PwtColors.error),
          ),
        ),
      ]),
      last: last,
    );
  }
}

// ─── Individual profile + addresses ───
class _IndividualProfile extends StatefulWidget {
  const _IndividualProfile({required this.user, required this.onUserUpdated});
  final AppUser user;
  final VoidCallback onUserUpdated;

  @override
  State<_IndividualProfile> createState() => _IndividualProfileState();
}

class _IndividualProfileState extends State<_IndividualProfile> {
  bool _edit = false;
  bool _saving = false;
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;

  List<AddressModel> _addresses = [];
  bool _loadingAddr = false;
  String? _addrError;

  @override
  void initState() {
    super.initState();
    final u = web.AppState.instance.user;
    _nameCtrl  = TextEditingController(text: u?.name ?? widget.user.name);
    _emailCtrl = TextEditingController(text: u?.email ?? widget.user.email);
    _loadAddresses();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAddresses() async {
    setState(() { _loadingAddr = true; _addrError = null; });
    final res = await getAddresses();
    if (!mounted) return;
    if (res.success && res.data != null) {
      setState(() { _addresses = res.data!; _loadingAddr = false; });
    } else {
      setState(() { _loadingAddr = false; _addrError = res.message ?? 'Failed to load addresses.'; });
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final res = await updateProfile(
      name:            _nameCtrl.text.trim().isEmpty  ? null : _nameCtrl.text.trim(),
      email:           _emailCtrl.text.trim().isEmpty ? null : _emailCtrl.text.trim(),
      currentPassword: web.AppState.instance.currentPassword,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (res.success && res.data != null) {
      web.AppState.instance.user = res.data;
      setState(() => _edit = false);
      widget.onUserUpdated();
      _toast('Profile updated.');
    } else {
      _toast(res.message ?? 'Failed to save profile.');
    }
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, backgroundColor: PwtColors.textPri),
  );

  void _addressSheet({AddressModel? edit}) {
    final labelCtrl = TextEditingController(text: edit?.label ?? '');
    final line1Ctrl = TextEditingController(text: edit?.line1 ?? '');
    final line2Ctrl = TextEditingController(text: edit?.line2 ?? '');
    final cityCtrl  = TextEditingController(text: edit?.city ?? '');
    final pcCtrl    = TextEditingController(text: edit?.postalCode ?? '');
    bool def = edit?.isDefault ?? false;
    final s = Strings.of(context.read<AppState>().lang);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PwtColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(PwtRadius.sheet))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 28),
        child: SingleChildScrollView(
          child: StatefulBuilder(
            builder: (ctx, set) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Expanded(child: Text(edit == null ? s['addAddress']! : s['edit']!, style: PwtType.title().copyWith(fontSize: 19))),
                  IconButton(icon: const Icon(PwtIcons.close), onPressed: () => Navigator.pop(ctx), color: PwtColors.textPri),
                ]),
                const SizedBox(height: 12),
                PwtField(label: 'Label', controller: labelCtrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                PwtField(label: 'Address line 1', controller: line1Ctrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                PwtField(label: 'Address line 2 (optional)', controller: line2Ctrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: PwtField(label: 'City', controller: cityCtrl, onChanged: (_) {})),
                  const SizedBox(width: 10),
                  Expanded(child: PwtField(label: 'Postcode', controller: pcCtrl, onChanged: (_) {})),
                ]),
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: () => set(() => def = !def),
                  child: Row(children: [
                    _checkbox(def),
                    const SizedBox(width: 10),
                    Text(s['setDefault']!, style: PwtType.label()),
                  ]),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(child: PwtButton(label: s['cancel']!, variant: PwtButtonVariant.secondary, full: true, onPressed: () => Navigator.pop(ctx))),
                  const SizedBox(width: 10),
                  Expanded(child: PwtButton(
                    label: edit == null ? s['addAddress']! : s['saved']!,
                    full: true,
                    onPressed: () {
                      Navigator.pop(ctx);
                      final u = web.AppState.instance.user;
                      if (edit != null && edit.id != null) {
                        updateAddress(
                          addressId: edit.id!,
                          label: labelCtrl.text.trim().isEmpty ? null : labelCtrl.text.trim(),
                          line1: line1Ctrl.text.trim().isEmpty ? null : line1Ctrl.text.trim(),
                          line2: line2Ctrl.text.trim().isEmpty ? null : line2Ctrl.text.trim(),
                          city: cityCtrl.text.trim().isEmpty ? null : cityCtrl.text.trim(),
                          postalCode: pcCtrl.text.trim().isEmpty ? null : pcCtrl.text.trim(),
                          isDefault: def,
                          recipientName: u?.name,
                          recipientPhone: u?.phone,
                        ).then((_) { if (mounted) _loadAddresses(); });
                      } else {
                        createAddress(
                          label: labelCtrl.text.trim().isEmpty ? 'Address' : labelCtrl.text.trim(),
                          line1: line1Ctrl.text.trim(),
                          line2: line2Ctrl.text.trim().isEmpty ? null : line2Ctrl.text.trim(),
                          city: cityCtrl.text.trim().isEmpty ? null : cityCtrl.text.trim(),
                          postalCode: pcCtrl.text.trim().isEmpty ? null : pcCtrl.text.trim(),
                          isDefault: def,
                          recipientName: u?.name,
                          recipientPhone: u?.phone,
                        ).then((_) { if (mounted) _loadAddresses(); });
                      }
                    },
                  )),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _deleteAddress(AddressModel a) async {
    if (a.id == null) return;
    final confirmed = await showConfirmSheet(
      context,
      title: 'Remove address?',
      body: 'Are you sure you want to remove this address?',
      keepLabel: 'Keep',
      confirmLabel: 'Remove',
    );
    if (!confirmed || !mounted) return;
    final res = await deleteAddress(a.id!);
    if (!mounted) return;
    if (res.success) { _loadAddresses(); } else { _toast(res.message ?? 'Failed to remove address.'); }
  }

  Widget _checkbox(bool checked) => Container(
    width: 20,
    height: 20,
    decoration: BoxDecoration(
      color: checked ? PwtColors.brand : PwtColors.surface,
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: checked ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
    ),
    child: checked ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
  );

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final u = web.AppState.instance.user;
    return Column(children: [
      Section(
        title: s['personal']!,
        trailing: GestureDetector(
          onTap: () {
            if (_edit) {
              _save();
            } else {
              setState(() => _edit = true);
            }
          },
          child: Text(
            _saving ? '…' : (_edit ? 'Save changes' : s['edit']!),
            style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5),
          ),
        ),
        child: _edit
            ? Column(children: [
                PwtField(label: s['fullName']!, controller: _nameCtrl),
                const SizedBox(height: 10),
                PwtField(label: s['email']!, controller: _emailCtrl, forceLtr: true, keyboardType: TextInputType.emailAddress),
                const SizedBox(height: 10),
                PwtField(
                  label: 'Phone',
                  initialValue: u?.phone ?? '',
                  forceLtr: true,
                  readOnly: true,
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(999), border: Border.all(color: PwtColors.hairline)),
                    child: Text('Coming soon', style: PwtType.label(color: PwtColors.textTer).copyWith(fontSize: 10.5)),
                  ),
                ),
              ])
            : PwtCard(
                padding: EdgeInsets.zero,
                child: Column(children: [
                  ListRow(leading: PwtIcons.user, title: u?.name ?? widget.user.name, sub: s['fullName']),
                  ListRow(leading: PwtIcons.phone, title: u?.phone ?? widget.user.phone, sub: s['phoneNumber']),
                  ListRow(leading: PwtIcons.message, title: u?.email ?? widget.user.email, sub: s['email'], last: true),
                ]),
              ),
      ),
      Section(
        title: s['savedAddresses']!,
        trailing: GestureDetector(
          onTap: () => _addressSheet(),
          child: Text('+ ${s['addAddress']!}', style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
        ),
        child: _loadingAddr
            ? const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 16), child: CircularProgressIndicator(strokeWidth: 2)))
            : _addrError != null
                ? Text(_addrError!, style: PwtType.label(color: PwtColors.error).copyWith(fontSize: 13))
                : _addresses.isEmpty
                    ? PwtCard(
                        padding: const EdgeInsets.all(16),
                        child: Text('No saved addresses.', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
                      )
                    : Column(children: [
                        for (final a in _addresses)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _AddressCard(
                              address: a,
                              canRemove: _addresses.length > 1,
                              onEdit: () => _addressSheet(edit: a),
                              onSetDefault: () async {
                                if (a.id == null) return;
                                await updateAddress(addressId: a.id!, isDefault: true);
                                if (mounted) _loadAddresses();
                              },
                              onRemove: () => _deleteAddress(a),
                            ),
                          ),
                      ]),
      ),
    ]);
  }
}

// ─── Address card (uses AddressModel) ───
class _AddressCard extends StatelessWidget {
  const _AddressCard({required this.address, required this.canRemove, required this.onSetDefault, required this.onEdit, required this.onRemove});
  final AddressModel address;
  final bool canRemove;
  final VoidCallback onSetDefault;
  final VoidCallback onEdit;
  final VoidCallback onRemove;

  String get _fullLine {
    return [address.line1, address.line2, address.city, address.postalCode]
        .where((s) => s != null && s!.isNotEmpty)
        .cast<String>()
        .join(', ');
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(PwtIcons.pin, size: 16, color: PwtColors.brand),
                const SizedBox(width: 8),
                Text(address.label ?? '', style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5)),
                const SizedBox(width: 8),
                if (address.isDefault == true) Pill(label: s['defaultAddr']!, color: PwtColors.success),
              ]),
              const SizedBox(height: 6),
              Text(_fullLine, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13, height: 1.5)),
            ]),
          ),
          Container(
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(children: [
              if (address.isDefault != true) _action(s['setDefault']!, null, onSetDefault),
              _action(s['edit']!, PwtIcons.edit, onEdit),
              if (canRemove) _action(s['remove']!, PwtIcons.trash, onRemove, danger: true),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _action(String label, IconData? icon, VoidCallback onTap, {bool danger = false}) {
    final color = danger ? PwtColors.error : PwtColors.brand;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
          decoration: const BoxDecoration(border: Border(right: BorderSide(color: PwtColors.hairline))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[Icon(icon, size: 14, color: color), const SizedBox(width: 6)],
              Text(label, style: TextStyle(color: color, fontSize: 12.5, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Company profile ───
class _CompanyProfile extends StatefulWidget {
  const _CompanyProfile({required this.user, required this.onUserUpdated});
  final AppUser user;
  final VoidCallback onUserUpdated;

  @override
  State<_CompanyProfile> createState() => _CompanyProfileState();
}

class _CompanyProfileState extends State<_CompanyProfile> {
  bool _edit = false;
  bool _saving = false;
  late final TextEditingController _companyCtrl;
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;

  List<AddressModel> _addresses = [];
  bool _loadingAddr = false;
  String? _addrError;

  Company get _c => widget.user.company ?? const Company(name: '', trn: '', industry: '', address: '', contact: '', email: '');

  @override
  void initState() {
    super.initState();
    final u = web.AppState.instance.user;
    _companyCtrl = TextEditingController(text: u?.companyName ?? _c.name);
    _nameCtrl    = TextEditingController(text: u?.name ?? _c.contact);
    _emailCtrl   = TextEditingController(text: u?.email ?? _c.email);
    _loadAddresses();
  }

  @override
  void dispose() {
    _companyCtrl.dispose();
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAddresses() async {
    setState(() { _loadingAddr = true; _addrError = null; });
    final res = await getAddresses();
    if (!mounted) return;
    if (res.success && res.data != null) {
      setState(() { _addresses = res.data!; _loadingAddr = false; });
    } else {
      setState(() { _loadingAddr = false; _addrError = res.message ?? 'Failed to load addresses.'; });
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final res = await updateProfile(
      name:            _nameCtrl.text.trim().isEmpty    ? null : _nameCtrl.text.trim(),
      email:           _emailCtrl.text.trim().isEmpty   ? null : _emailCtrl.text.trim(),
      companyName:     _companyCtrl.text.trim().isEmpty ? null : _companyCtrl.text.trim(),
      currentPassword: web.AppState.instance.currentPassword,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (res.success && res.data != null) {
      web.AppState.instance.user = res.data;
      setState(() => _edit = false);
      widget.onUserUpdated();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated.'), behavior: SnackBarBehavior.floating, backgroundColor: PwtColors.textPri),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message ?? 'Failed to save profile.'), behavior: SnackBarBehavior.floating, backgroundColor: PwtColors.error),
      );
    }
  }

  void _addressSheet({AddressModel? edit}) {
    final labelCtrl = TextEditingController(text: edit?.label ?? '');
    final line1Ctrl = TextEditingController(text: edit?.line1 ?? '');
    final line2Ctrl = TextEditingController(text: edit?.line2 ?? '');
    final cityCtrl  = TextEditingController(text: edit?.city ?? '');
    final pcCtrl    = TextEditingController(text: edit?.postalCode ?? '');
    bool def = edit?.isDefault ?? false;
    final s = Strings.of(context.read<AppState>().lang);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PwtColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(PwtRadius.sheet))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 28),
        child: SingleChildScrollView(
          child: StatefulBuilder(
            builder: (ctx, set) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Expanded(child: Text(edit == null ? s['addAddress']! : s['edit']!, style: PwtType.title().copyWith(fontSize: 19))),
                  IconButton(icon: const Icon(PwtIcons.close), onPressed: () => Navigator.pop(ctx), color: PwtColors.textPri),
                ]),
                const SizedBox(height: 12),
                PwtField(label: 'Label', controller: labelCtrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                PwtField(label: 'Address line 1', controller: line1Ctrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                PwtField(label: 'Address line 2 (optional)', controller: line2Ctrl, onChanged: (_) {}),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: PwtField(label: 'City', controller: cityCtrl, onChanged: (_) {})),
                  const SizedBox(width: 10),
                  Expanded(child: PwtField(label: 'Postcode', controller: pcCtrl, onChanged: (_) {})),
                ]),
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: () => set(() => def = !def),
                  child: Row(children: [
                    _checkbox(def),
                    const SizedBox(width: 10),
                    Text(s['setDefault']!, style: PwtType.label()),
                  ]),
                ),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(child: PwtButton(label: s['cancel']!, variant: PwtButtonVariant.secondary, full: true, onPressed: () => Navigator.pop(ctx))),
                  const SizedBox(width: 10),
                  Expanded(child: PwtButton(
                    label: edit == null ? s['addAddress']! : s['saved']!,
                    full: true,
                    onPressed: () {
                      Navigator.pop(ctx);
                      final u = web.AppState.instance.user;
                      if (edit != null && edit.id != null) {
                        updateAddress(
                          addressId: edit.id!,
                          label: labelCtrl.text.trim().isEmpty ? null : labelCtrl.text.trim(),
                          line1: line1Ctrl.text.trim().isEmpty ? null : line1Ctrl.text.trim(),
                          line2: line2Ctrl.text.trim().isEmpty ? null : line2Ctrl.text.trim(),
                          city: cityCtrl.text.trim().isEmpty ? null : cityCtrl.text.trim(),
                          postalCode: pcCtrl.text.trim().isEmpty ? null : pcCtrl.text.trim(),
                          isDefault: def,
                          recipientName: u?.name,
                          recipientPhone: u?.phone,
                        ).then((_) { if (mounted) _loadAddresses(); });
                      } else {
                        createAddress(
                          label: labelCtrl.text.trim().isEmpty ? 'Address' : labelCtrl.text.trim(),
                          line1: line1Ctrl.text.trim(),
                          line2: line2Ctrl.text.trim().isEmpty ? null : line2Ctrl.text.trim(),
                          city: cityCtrl.text.trim().isEmpty ? null : cityCtrl.text.trim(),
                          postalCode: pcCtrl.text.trim().isEmpty ? null : pcCtrl.text.trim(),
                          isDefault: def,
                          recipientName: u?.name,
                          recipientPhone: u?.phone,
                        ).then((_) { if (mounted) _loadAddresses(); });
                      }
                    },
                  )),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _deleteAddress(AddressModel a) async {
    if (a.id == null) return;
    final confirmed = await showConfirmSheet(
      context,
      title: 'Remove address?',
      body: 'Are you sure you want to remove this address?',
      keepLabel: 'Keep',
      confirmLabel: 'Remove',
    );
    if (!confirmed || !mounted) return;
    final res = await deleteAddress(a.id!);
    if (!mounted) return;
    if (res.success) {
      _loadAddresses();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message ?? 'Failed to remove address.'), behavior: SnackBarBehavior.floating, backgroundColor: PwtColors.error),
      );
    }
  }

  Widget _checkbox(bool checked) => Container(
    width: 20,
    height: 20,
    decoration: BoxDecoration(
      color: checked ? PwtColors.brand : PwtColors.surface,
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: checked ? PwtColors.brand : PwtColors.hairline2, width: 1.5),
    ),
    child: checked ? const Icon(PwtIcons.check, size: 14, color: Colors.white) : null,
  );

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final u = web.AppState.instance.user;
    return Column(children: [
      Section(
        title: s['companyInfo']!,
        trailing: GestureDetector(
          onTap: () {
            if (_edit) { _save(); } else { setState(() => _edit = true); }
          },
          child: Text(
            _saving ? '…' : (_edit ? 'Save changes' : s['edit']!),
            style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5),
          ),
        ),
        child: _edit
            ? Column(children: [
                PwtField(label: s['companyName']!, controller: _companyCtrl),
                const SizedBox(height: 10),
                PwtField(label: s['fullName']!, controller: _nameCtrl),
                const SizedBox(height: 10),
                PwtField(label: s['email']!, controller: _emailCtrl, forceLtr: true, keyboardType: TextInputType.emailAddress),
              ])
            : PwtCard(
                padding: EdgeInsets.zero,
                child: Column(children: [
                  ListRow(leading: PwtIcons.building, title: u?.companyName ?? _c.name, sub: s['companyName']),
                  ListRow(leading: PwtIcons.user, title: u?.name ?? _c.contact, sub: 'Primary contact'),
                  ListRow(leading: PwtIcons.message, title: u?.email ?? _c.email, sub: s['email'], last: true),
                ]),
              ),
      ),
      Section(
        title: s['savedAddresses']!,
        trailing: GestureDetector(
          onTap: () => _addressSheet(),
          child: Text('+ ${s['addAddress']!}', style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 12.5)),
        ),
        child: _loadingAddr
            ? const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 16), child: CircularProgressIndicator(strokeWidth: 2)))
            : _addrError != null
                ? Text(_addrError!, style: PwtType.label(color: PwtColors.error).copyWith(fontSize: 13))
                : _addresses.isEmpty
                    ? PwtCard(
                        padding: const EdgeInsets.all(16),
                        child: Text('No saved addresses.', style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13)),
                      )
                    : Column(children: [
                        for (final a in _addresses)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _AddressCard(
                              address: a,
                              canRemove: _addresses.length > 1,
                              onEdit: () => _addressSheet(edit: a),
                              onSetDefault: () async {
                                if (a.id == null) return;
                                await updateAddress(addressId: a.id!, isDefault: true);
                                if (mounted) _loadAddresses();
                              },
                              onRemove: () => _deleteAddress(a),
                            ),
                          ),
                      ]),
      ),
    ]);
  }
}

// ═══════════════════════ SETTINGS ═══════════════════════
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final Map<String, bool> _notifs = Map.of(MockData.notifDefaults);
  final _curPw = TextEditingController();
  final _newPw = TextEditingController();
  final _confPw = TextEditingController();
  bool _pwDone = false;

  @override
  void dispose() {
    _curPw.dispose();
    _newPw.dispose();
    _confPw.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final rows = [
      (k: 'maintenance', label: s['notifMaintenance']!, sub: s['notifMaintenanceSub']!, icon: PwtIcons.wrench),
      (k: 'billing', label: s['notifBilling']!, sub: s['notifBillingSub']!, icon: PwtIcons.card),
      (k: 'orders', label: s['notifOrders']!, sub: s['notifOrdersSub']!, icon: PwtIcons.orders),
      (k: 'offers', label: s['notifOffers']!, sub: s['notifOffersSub']!, icon: PwtIcons.bolt),
    ];

    return DetailScaffold(
      title: s['settings'],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Section(
            title: s['notifications']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  for (int i = 0; i < rows.length; i++)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(border: i == rows.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                      child: Row(children: [
                        Icon(rows[i].icon, size: 18, color: PwtColors.textSec),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(rows[i].label, style: PwtType.label(weight: FontWeight.w500).copyWith(fontSize: 14)),
                          const SizedBox(height: 2),
                          Text(rows[i].sub, style: PwtType.caption().copyWith(fontSize: 11.5)),
                        ])),
                        PwtSwitch(value: _notifs[rows[i].k] ?? false, onChanged: (v) => setState(() => _notifs[rows[i].k] = v)),
                      ]),
                    ),
                ],
              ),
            ),
          ),
          Section(
            title: s['security']!,
            child: Column(children: [
              PwtField(label: s['currentPassword']!, controller: _curPw, obscure: true),
              const SizedBox(height: 10),
              PwtField(label: s['newPassword']!, controller: _newPw, obscure: true),
              const SizedBox(height: 10),
              PwtField(label: s['confirmNewPassword']!, controller: _confPw, obscure: true),
              const SizedBox(height: 8),
              Align(alignment: AlignmentDirectional.centerStart, child: Padding(padding: const EdgeInsets.only(left: 4), child: Text(s['passwordHint']!, style: PwtType.caption().copyWith(fontSize: 11.5)))),
              const SizedBox(height: 10),
              PwtButton(
                label: _pwDone ? s['passwordUpdated']! : s['updatePassword']!,
                variant: _pwDone ? PwtButtonVariant.soft : PwtButtonVariant.primary,
                full: true,
                icon: _pwDone ? PwtIcons.check : PwtIcons.lock,
                onPressed: () {
                  setState(() => _pwDone = true);
                  Future.delayed(const Duration(milliseconds: 1800), () {
                    if (mounted) setState(() => _pwDone = false);
                  });
                },
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════ INVOICES ═══════════════════════
class InvoicesScreen extends StatelessWidget {
  const InvoicesScreen({super.key, required this.invoices});
  final List<Invoice> invoices;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return DetailScaffold(
      title: s['invoices'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Eyebrow(s['allInvoices']!),
          const SizedBox(height: 4),
          Text(s['invoices']!, style: PwtType.headline().copyWith(fontSize: 26)),
          const SizedBox(height: 18),
          for (final inv in invoices)
            Padding(padding: const EdgeInsets.only(bottom: 10), child: _InvoiceCard(inv: inv)),
        ],
      ),
    );
  }
}

class _InvoiceCard extends StatefulWidget {
  const _InvoiceCard({required this.inv});
  final Invoice inv;
  @override
  State<_InvoiceCard> createState() => _InvoiceCardState();
}

class _InvoiceCardState extends State<_InvoiceCard> {
  bool _dl = false;

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    final inv = widget.inv;
    final paid = inv.status == 'paid';
    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12)),
              child: const Icon(PwtIcons.file, size: 20, color: PwtColors.textSec),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Directionality(textDirection: TextDirection.ltr, child: Text(inv.id, style: PwtType.mono(size: 11.5, color: PwtColors.brand, weight: FontWeight.w600))),
                const SizedBox(width: 8),
                Pill(label: paid ? s['paid']! : s['dueStatus']!, color: paid ? PwtColors.success : PwtColors.warning, dot: true),
              ]),
              const SizedBox(height: 4),
              Text(inv.desc, style: PwtType.label(weight: FontWeight.w500).copyWith(fontSize: 13.5)),
              const SizedBox(height: 2),
              Text(inv.date, style: PwtType.caption().copyWith(fontSize: 12)),
            ])),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Dirham(size: 12),
                const SizedBox(width: 3),
                Text(inv.amount.toStringAsFixed(2), style: PwtType.subtitle().copyWith(fontSize: 15, fontWeight: FontWeight.w700)),
              ],
            ),
          ]),
        ),
        InkWell(
          onTap: () {
            setState(() => _dl = true);
            Future.delayed(const Duration(milliseconds: 1500), () { if (mounted) setState(() => _dl = false); });
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(_dl ? PwtIcons.check : PwtIcons.file, size: 15, color: _dl ? PwtColors.success : PwtColors.brand),
                const SizedBox(width: 8),
                Text(_dl ? s['saved']! : s['download']!, style: TextStyle(color: _dl ? PwtColors.success : PwtColors.brand, fontSize: 12.5, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}

// ═══════════════════════ ORDERS ═══════════════════════
class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key, required this.role});
  final AccountKind role;

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List<OrderModel> _orders = [];
  bool _loading = true;
  bool _loadingMore = false;
  int _page = 1;
  PaginationModel? _pagination;

  static const _monthsShort = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({int page = 1, bool append = false}) async {
    if (append) {
      setState(() => _loadingMore = true);
    } else {
      setState(() { _loading = true; _orders = []; });
    }
    final res = await getOrders(page: page);
    if (!mounted) return;
    setState(() {
      if (res.success && res.data != null) {
        _orders = append ? [..._orders, ...res.data!.items] : res.data!.items;
        _pagination = res.data!.pagination;
        _page = page;
      }
      _loading = false;
      _loadingMore = false;
    });
  }

  void _loadMore() => _load(page: _page + 1, append: true);

  String _fmtDate(String? iso) {
    if (iso == null) return '—';
    try {
      final dt = DateTime.parse(iso);
      return '${dt.day} ${_monthsShort[dt.month - 1]} ${dt.year}';
    } catch (_) { return '—'; }
  }

  String _shortId(String publicId) =>
      '#${publicId.length >= 8 ? publicId.substring(0, 8).toUpperCase() : publicId.toUpperCase()}';

  Color _statusColor(String st) => switch (st) {
    'pending'   => PwtColors.warning,
    'confirmed' => PwtColors.brand,
    'scheduled' => PwtColors.brand,
    'completed' => PwtColors.success,
    'cancelled' => PwtColors.error,
    _           => PwtColors.textSec,
  };

  String _statusLabel(String st) => switch (st) {
    'pending'   => 'Pending',
    'confirmed' => 'Confirmed',
    'scheduled' => 'Scheduled',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    _           => st,
  };

  @override
  Widget build(BuildContext context) {
    final s = Strings.of(context.watch<AppState>().lang);
    return DetailScaffold(
      title: s['orders'],
      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand))
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: [
                for (final o in _orders)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: PwtCard(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Directionality(textDirection: TextDirection.ltr, child: Text(_shortId(o.publicId), style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w600))),
                            Pill(label: _statusLabel(o.status), color: _statusColor(o.status), dot: true),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                o.firstProductName ?? 'Order #${o.id}',
                                style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14.5),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (o.remainingItemsCount > 0) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(color: PwtColors.brandTint, borderRadius: BorderRadius.circular(999)),
                                child: Text('+${o.remainingItemsCount}', style: PwtType.mono(size: 11, color: PwtColors.brand, weight: FontWeight.w700)),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text('${s['placed']} ${_fmtDate(o.placedAt)}', style: PwtType.caption().copyWith(fontSize: 12)),
                        const SizedBox(height: 10),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            Text('${s['total']}  ', style: PwtType.caption()),
                            Text('${o.currency} ', style: PwtType.caption().copyWith(fontWeight: FontWeight.w600)),
                            Text(o.totalAmount, style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                            if (o.term == 'rent') Text(s['perMonth']!, style: PwtType.caption()),
                          ],
                        ),
                      ]),
                    ),
                  ),
                if (_pagination != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Page $_page of ${_pagination!.lastPage ?? 1} · ${_pagination!.total ?? _orders.length} total',
                    textAlign: TextAlign.center,
                    style: PwtType.caption().copyWith(fontSize: 12),
                  ),
                  if (_page < (_pagination!.lastPage ?? 1)) ...[
                    const SizedBox(height: 12),
                    if (_loadingMore)
                      const Center(child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand),
                      ))
                    else
                      PwtButton(label: 'Load more', variant: PwtButtonVariant.soft, full: true, onPressed: _loadMore),
                  ],
                ],
              ],
            ),
    );
  }
}

// Groups card digits as "XXXX XXXX XXXX XXXX", capped at 16 digits.
class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue old, TextEditingValue next) {
    final digits = next.text.replaceAll(RegExp(r'\D'), '');
    if (digits.length > 16) return old;
    final buffer = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      if (i > 0 && i % 4 == 0) buffer.write(' ');
      buffer.write(digits[i]);
    }
    final text = buffer.toString();
    return TextEditingValue(text: text, selection: TextSelection.collapsed(offset: text.length));
  }
}
