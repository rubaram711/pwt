import '../Products/products_model.dart';

class CartModel {
  int? id;
  String? uuid;
  String? userId;
  String? sessionId;
  String? createdAt;
  String? updatedAt;
  List<CartItemModel>? items;

  CartModel({
    this.id,
    this.uuid,
    this.userId,
    this.sessionId,
    this.createdAt,
    this.updatedAt,
    this.items,
  });

  CartModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uuid = json['uuid'];
    userId = json['user_id'];
    sessionId = json['session_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];

    if (json['items'] != null) {
      items = <CartItemModel>[];
      json['items'].forEach((v) {
        items!.add(CartItemModel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'uuid': uuid,
      'user_id': userId,
      'session_id': sessionId,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'items': items?.map((e) => e.toJson()).toList(),
    };
  }
}

class CartItemModel {
  int? id;
  String? uuid;
  String? cartId;
  String? productId;
  String? planType;
  int? quantity;
  String? unitPrice;
  String? createdAt;
  String? updatedAt;
  ProductModel? product;

  CartItemModel({
    this.id,
    this.uuid,
    this.cartId,
    this.productId,
    this.planType,
    this.quantity,
    this.unitPrice,
    this.createdAt,
    this.updatedAt,
    this.product,
  });

  CartItemModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uuid = json['uuid'];
    cartId = json['cart_id'];
    productId = json['product_id'];
    planType = json['plan_type'];
    quantity = json['quantity'];
    unitPrice = json['unit_price'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];

    product = json['product'] != null
        ? ProductModel.fromJson(json['product'])
        : null;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'uuid': uuid,
      'cart_id': cartId,
      'product_id': productId,
      'plan_type': planType,
      'quantity': quantity,
      'unit_price': unitPrice,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'product': product?.toJson(),
    };
  }
}

