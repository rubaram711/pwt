import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';
import '../../Models/Orders/order_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';
import '../../const/urls.dart';

Future<ApiResponse<OrderDetailModel>> placeOrder({
  required List<Map<String, dynamic>> items,
  String? customerName,
  String? customerEmail,
  String? customerPhone,
  int? deliveryAddressId,
  String? deliveryAddressLine1,
  String? deliveryCity,
  String? deliveryPostcode,
  int? billingAddressId,
  required String term,
  required String paymentMethod,
  String? promoCode,
  String? notes,
  String? installationPreferredTime,
  String? cardNumber,
  String? cardExpiry,
  String? cardCvc,
}) async {
  final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<OrderDetailModel>(
    request: () => di.post(
      kOrdersUrl,
      data: {
        "items": items,
        if (customerName != null) "customer_name": customerName,
        if (customerEmail != null) "customer_email": customerEmail,
        if (customerPhone != null) "customer_phone": customerPhone,
        if (deliveryAddressId != null) "delivery_address_id": deliveryAddressId,
        if (deliveryAddressLine1 != null) "delivery_address_line_1": deliveryAddressLine1,
        if (deliveryCity != null) "delivery_city": deliveryCity,
        if (deliveryPostcode != null) "delivery_postcode": deliveryPostcode,
        if (billingAddressId != null) "billing_address_id": billingAddressId,
        "term": term,
        "payment_method": paymentMethod,
        if (promoCode != null) "promo_code": promoCode,
        if (notes != null) "notes": notes,
        if (installationPreferredTime != null) "installation_preferred_time": installationPreferredTime,
        if (cardNumber != null) "card_number": cardNumber,
        if (cardExpiry != null) "card_expiry": cardExpiry,
        if (cardCvc != null) "card_cvc": cardCvc,
      },
    ),
    parser: (data) => OrderDetailModel.fromJson(data),
  );
}
