import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../../Services/dio_service.dart';
import '../../../const/urls.dart';
import '../../Models/api_response_model.dart';
import '../../Models/payments/payment_status_model.dart';
import '../../Services/api_handler.dart';


Future<ApiResponse<PaymentStatusModel>> getPaymentStatus(int id) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<PaymentStatusModel>(
    request: () => di.get(
      '$kPaymentsUrl/$id/status',
    ),
    parser: (data) => PaymentStatusModel.fromJson(data),
  );
}