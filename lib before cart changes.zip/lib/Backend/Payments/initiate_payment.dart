import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';

import '../../../Services/dio_service.dart';
import '../../../const/urls.dart';
import '../../Models/api_response_model.dart';
import '../../Models/payments/payment_initiate_model.dart';
import '../../Services/api_handler.dart';


Future<ApiResponse<PaymentInitiateModel>> initiatePayment({
  required int orderId,
  required String paymentMethod,
  required String idempotencyKey,
}) async {
final dio.Dio di = AppState.instance.dioService.dio;

  return ApiHandler.handleRequest<PaymentInitiateModel>(
    request: () => di.post(
      kPaymentsInitiateUrl,
      data: {
        "order_id": orderId,
        "payment_method": paymentMethod,
      },
      options: dio.Options(
        headers: {
          "Idempotency-Key": idempotencyKey,
        },
      ),
    ),
    parser: (data) => PaymentInitiateModel.fromJson(data),
  );
}