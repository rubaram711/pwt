import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

class RfqScreen extends StatefulWidget {
  const RfqScreen({super.key});
  @override
  State<RfqScreen> createState() => _RfqScreenState();
}

class _RfqScreenState extends State<RfqScreen> {
  final Set<String> _picked = {'pw50-r'};
  bool _uploaded = false;

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 980;
    final opts = kProducts.take(4).toList();
    return StoreScaffold(active: '/shop', showFooter: false, slivers: [
      SliverToBoxAdapter(
        child: Band(color: AppColors.ink900, padding: const EdgeInsets.fromLTRB(28, 34, 28, 34), child: Row(children: [
          Container(width: 56, height: 56, decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.description_outlined, color: Colors.white, size: 28)),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(AppRadius.pill)), child: const Text('FOR BUSINESS', style: TextStyle(color: Color(0xFF9CC1ED), fontWeight: FontWeight.w700, fontSize: 11))),
            const SizedBox(height: 8),
            Text('Request a Quotation', style: AppText.headline(wide ? 30 : 24).copyWith(color: Colors.white)),
            const SizedBox(height: 6),
            Text('Tell us about your business needs and our team will contact you with a custom quotation — no payment required.', style: AppText.body.copyWith(color: const Color(0xFFC4CCDD), height: 1.5)),
          ])),
        ])),
      ),
      SliverToBoxAdapter(
        child: Band(child: Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: wide ? 3 : 0, child: Column(children: [
            _card('Company Information', 'Step 1 of 3', Column(children: [
              _field('Company name', 'Acme Facilities Ltd'),
              const SizedBox(height: 14),
              GestureDetector(
                onTap: () => setState(() => _uploaded = !_uploaded),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 26),
                  decoration: BoxDecoration(color: _uploaded ? AppColors.blue50 : AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: _uploaded ? AppColors.blue600 : AppColors.line, style: BorderStyle.solid)),
                  child: Column(children: [
                    Icon(_uploaded ? Icons.description : Icons.upload_file, color: AppColors.blue700, size: 26),
                    const SizedBox(height: 8),
                    Text(_uploaded ? 'trade-license.pdf' : 'Upload Trade License', style: AppText.label),
                    const SizedBox(height: 4),
                    Text(_uploaded ? 'Uploaded · tap to replace' : 'Tap to browse · PDF, JPG or PNG (max 10MB)', style: AppText.muted),
                  ]),
                ),
              ),
            ])),
            _card('Contact Person', 'Step 2 of 3', Column(children: [
              Row(children: [Expanded(child: _field('Full name', 'Ahmed Hassan')), const SizedBox(width: 12), Expanded(child: _field('Job title', 'Facilities Manager'))]),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: _field('Business email', 'ahmed@company.com')), const SizedBox(width: 12), Expanded(child: _field('Phone number', '07xxx xxxxxx'))]),
            ])),
            _card('Your Requirements', 'Step 3 of 3', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Preferred products', style: AppText.label),
              const SizedBox(height: 10),
              Wrap(spacing: 10, runSpacing: 10, children: opts.map((p) {
                final on = _picked.contains(p.id);
                return GestureDetector(
                  onTap: () => setState(() => on ? _picked.remove(p.id) : _picked.add(p.id)),
                  child: Container(
                    width: wide ? 250 : double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: on ? AppColors.blue50 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 1.5 : 1)),
                    child: Row(children: [
                      Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(8)), padding: const EdgeInsets.all(5), child: Image.asset(p.image, fit: BoxFit.contain)),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.name, style: AppText.label), Text(p.sub, style: AppText.muted, maxLines: 1, overflow: TextOverflow.ellipsis)])),
                      Icon(on ? Icons.check_circle : Icons.circle_outlined, size: 18, color: on ? AppColors.blue700 : AppColors.ink300),
                    ]),
                  ),
                );
              }).toList()),
              const SizedBox(height: 16),
              Row(children: [Expanded(child: _field('Total quantity', 'e.g. 12 units')), const SizedBox(width: 12), Expanded(child: _field('Required by', 'Within 1 month'))]),
              const SizedBox(height: 14),
              _field('Installation location', 'Full site address — city, postcode'),
              const SizedBox(height: 14),
              _field('Notes / comments', 'Multi-site rollout, branding, service contracts…', lines: 3),
            ])),
          ])),
          SizedBox(width: wide ? 22 : 0, height: wide ? 0 : 22),
          Expanded(flex: wide ? 2 : 0, child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Why request a quote?', style: AppText.h3),
              const SizedBox(height: 6),
              Text('Tailored B2B pricing and support for your organisation.', style: AppText.body.copyWith(color: AppColors.ink500)),
              const SizedBox(height: 16),
              ...['Personalised volume pricing', 'Dedicated account manager', 'Flexible installation & service plans', 'Priority after-sales support'].map((t) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [const Icon(Icons.check, size: 16, color: AppColors.blue600), const SizedBox(width: 10), Expanded(child: Text(t, style: AppText.body))]))),
              const SizedBox(height: 14),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(AppRadius.sm)), child: Row(children: [const Icon(Icons.info_outline, size: 16, color: AppColors.blue700), const SizedBox(width: 10), Expanded(child: Text('Our team will contact you with a custom quotation within 24 hours.', style: AppText.muted.copyWith(color: AppColors.blue800)))])),
              const SizedBox(height: 16),
              PwtButton('Submit Request', icon: Icons.arrow_forward, fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/rfqConfirmation')),
            ]),
          )),
        ])),
      ),
    ]);
  }

  Widget _card(String title, String step, Widget child) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(title, style: AppText.h3)), Text(step, style: AppText.muted.copyWith(color: AppColors.blue700, fontWeight: FontWeight.w700))]),
          const SizedBox(height: 16),
          child,
        ]),
      );

  Widget _field(String label, String hint, {int lines = 1}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: AppText.label),
        const SizedBox(height: 7),
        TextField(maxLines: lines, decoration: InputDecoration(hintText: hint)),
      ]);
}

class RfqConfirmationScreen extends StatelessWidget {
  const RfqConfirmationScreen({super.key});
  @override
  Widget build(BuildContext context) {
    Widget kv(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 150, child: Text(k, style: AppText.muted)), Expanded(child: Text(v, style: AppText.label))]));
    return StoreScaffold(active: '/', showFooter: false, slivers: [
      SliverToBoxAdapter(
        child: Band(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: Column(children: [
          Container(width: 84, height: 84, decoration: const BoxDecoration(color: AppColors.badgeGreenBg, shape: BoxShape.circle), child: const Icon(Icons.check, size: 44, color: AppColors.green600)),
          const SizedBox(height: 18),
          Text('Quotation Request Received!', style: AppText.headline(28), textAlign: TextAlign.center),
          const SizedBox(height: 10),
          Text("Thank you. We've received your request. Our team will contact you with a custom quotation tailored to your business needs.", style: AppText.bodyLg.copyWith(height: 1.6), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12), decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.pill)), child: Row(mainAxisSize: MainAxisSize.min, children: [Text('Request ID  ', style: AppText.muted), Text('PWT-RFQ-2026-00231', style: AppText.label)])),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Your Request Summary', style: AppText.h3),
              const SizedBox(height: 8),
              kv('Company', 'Acme Facilities Ltd'),
              kv('Contact', 'Ahmed Hassan · ahmed@company.com'),
              kv('Preferred products', 'PW50-R, PW100-B'),
              kv('Quantity', '12 units'),
              kv('Installation location', 'London, NW1 6XE'),
              kv('Trade license', 'Uploaded ✓'),
            ]),
          ),
          const SizedBox(height: 22),
          Wrap(spacing: 12, runSpacing: 12, alignment: WrapAlignment.center, children: [
            PwtButton('Go to Dashboard', icon: Icons.grid_view_rounded, onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/companyDashboard', (r) => false)),
            PwtButton('Back to Shop', variant: PwtBtn.outline, onPressed: () => Navigator.of(context).pushNamed('/shop')),
          ]),
        ])))),
      ),
    ]);
  }
}
