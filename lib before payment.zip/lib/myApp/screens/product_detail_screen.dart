// Rich product-detail page (PDP): gallery, rating, features, pricing,
// rent/buy selector, assurances and the overview/specs/box/reviews tabs.
// Design from proto/overlays.jsx; data from the real ProductModel API.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pwt_website/myApp/widgets/chrome.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../../myWeb2/state/app_state.dart' as web;
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import 'cart_screen.dart';
import '../../Backend/Products/show_product.dart';
import '../../Models/Products/products_model.dart';
import '../../Models/Products/product_image_model.dart';
import '../../Models/Products/product_price_model.dart';

class StarRating extends StatelessWidget {
  const StarRating({super.key, required this.value, this.size = 14});
  final double value;
  final double size;

  @override
  Widget build(BuildContext context) {
    final full = value.round();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int n = 1; n <= 5; n++)
          Icon(PwtIcons.star, size: size, color: n <= full ? const Color(0xFFF5A623) : PwtColors.hairline2),
      ],
    );
  }
}

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.product, required this.role});
  final ProductModel product;
  final AccountKind role;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late ProductModel _product = widget.product;
  bool _loading = false;
  int _heroIdx = 0;
  String _tab = 'overview';
  bool _justAdded = false;
  Plan _plan = Plan.rent;

  @override
  void initState() {
    super.initState();
    _plan = (_product.isQuoteOnly ?? false) ? Plan.quote : Plan.rent;
    if (widget.product.id != null) _fetchDetails(widget.product.id!);
  }

  Future<void> _fetchDetails(int id) async {
    setState(() => _loading = true);
    final res = await getProductDetails(id);
    if (!mounted) return;
    if (res.success && res.data != null) {
      setState(() {
        _product = res.data!;
        _heroIdx = 0;
        _loading = false;
        _plan = (_product.isQuoteOnly ?? false) ? Plan.quote : Plan.rent;
      });
    } else {
      setState(() => _loading = false);
    }
  }

  ProductPriceModel? get _rentPrice =>
      _product.prices.where((p) => p.term == 'rent').firstOrNull;
  ProductPriceModel? get _buyPrice =>
      _product.prices.where((p) => p.term == 'buy').firstOrNull;

  bool get _isQuote =>
      widget.role == AccountKind.business || (_product.isQuoteOnly ?? false);

  Plan get _currentPlan {
    if (_isQuote) return Plan.quote;
    if (_plan == Plan.buy && _buyPrice != null) return Plan.buy;
    return Plan.rent;
  }

  double get _rating => double.tryParse(_product.rentStars ?? '') ?? 4.7;

  List<ProductImageModel> get _images {
    if (_product.images.isNotEmpty) return _product.images;
    if (_product.primaryImageUrl != null) {
      return [ProductImageModel(url: _product.primaryImageUrl)];
    }
    return [];
  }

  String _fmtAmt(String amount) {
    final v = double.tryParse(amount);
    if (v == null) return amount;
    return v.truncate().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  }

  @override
  Widget build(BuildContext context) {
    final p = _product;
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final ar = app.isArabic;

    final name = p.localizedName ?? p.name ?? p.code ?? '';
    final catName = p.category?.name ?? '';
    final blurb = p.shortDescription ?? '';
    final isQuoteOnly = p.isQuoteOnly ?? false;
    final images = _images;

    final features = p.benefits.isNotEmpty
        ? p.benefits
        : (ar
            ? ['مياه ساخنة وباردة ودرجة الحرارة العادية', 'موفر للطاقة', 'قفل أمان للأطفال', 'تصميم عصري أنيق']
            : ['Instant hot & cold', 'Energy efficient', 'Child safety lock', 'Sleek modern design']);

    final tabs = [
      (k: 'overview', label: s['overview']!),
      (k: 'specs', label: s['specifications']!),
    ];

    return DetailScaffold(
      title: name,
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          // gallery
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
            child: Column(
              children: [
                Container(
                  height: 280,
                  decoration: BoxDecoration(
                    color: PwtColors.surface,
                    border: Border.all(color: PwtColors.hairline),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      if (_loading)
                        const CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)
                      else
                        ProductImage(
                          img: '',
                          imageUrl: images.isNotEmpty ? images[_heroIdx].url : null,
                          size: 232,
                        ),
                      if (p.tagLabel != null)
                        Positioned(
                          top: 12, left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: PwtColors.brand, borderRadius: BorderRadius.circular(999)),
                            child: Text(p.tagLabel!, style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      if ((p.discount ?? 0) > 0)
                        Positioned(
                          top: 12, right: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: PwtColors.success, borderRadius: BorderRadius.circular(999)),
                            child: Text('${p.discount}% OFF', style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)),
                          ),
                        ),
                    ],
                  ),
                ),
                if (images.length > 1) ...[
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (int i = 0; i < images.length; i++)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () => setState(() => _heroIdx = i),
                              child: Container(
                                width: 60, height: 60,
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: PwtColors.surface,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: i == _heroIdx ? PwtColors.brand : PwtColors.hairline, width: 1.5),
                                ),
                                child: images[i].url != null
                                    ? Image.network(images[i].url!, fit: BoxFit.contain,
                                        errorBuilder: (_, __, ___) => const Icon(PwtIcons.drop, size: 20, color: PwtColors.brandBorder))
                                    : const Icon(PwtIcons.drop, size: 20, color: PwtColors.brandBorder),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (catName.isNotEmpty) Eyebrow(catName),
                const SizedBox(height: 4),
                Text(name, style: PwtType.headline().copyWith(fontSize: 26)),
                if (blurb.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(blurb, style: PwtType.body(color: PwtColors.textSec).copyWith(height: 1.5)),
                ],
                const SizedBox(height: 16),
                // feature chips
                if (features.isNotEmpty)
                  GridView.count(
                    crossAxisCount: 2,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 4.2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      for (final f in features.take(4))
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: PwtColors.surface,
                            border: Border.all(color: PwtColors.hairline),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              const Icon(PwtIcons.check, size: 15, color: PwtColors.brand),
                              const SizedBox(width: 8),
                              Expanded(child: Text(f, style: PwtType.caption(color: PwtColors.textPri).copyWith(fontSize: 12, fontWeight: FontWeight.w500))),
                            ],
                          ),
                        ),
                    ],
                  ),
                const SizedBox(height: 16),
                // price card / quote banner
                if (!isQuoteOnly && (_rentPrice != null || _buyPrice != null))
                  PwtCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            if (_rentPrice != null)
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Eyebrow(s['rent']!),
                                    const SizedBox(height: 6),
                                    Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
                                      const Dirham(size: 14),
                                      const SizedBox(width: 4),
                                      Text(_fmtAmt(_rentPrice!.amount), style: PwtType.title().copyWith(fontSize: 22, fontWeight: FontWeight.w700)),
                                      Text(s['perMonth']!, style: PwtType.caption()),
                                    ]),
                                  ],
                                ),
                              ),
                            if (_buyPrice != null)
                              Container(
                                padding: const EdgeInsets.only(left: 16),
                                decoration: const BoxDecoration(border: Border(left: BorderSide(color: PwtColors.hairline))),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Eyebrow(s['buy']!),
                                    const SizedBox(height: 6),
                                    Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
                                      const Dirham(size: 14),
                                      const SizedBox(width: 4),
                                      Text(_fmtAmt(_buyPrice!.amount), style: PwtType.title().copyWith(fontSize: 22, fontWeight: FontWeight.w700)),
                                    ]),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        if (_rentPrice != null && _buyPrice != null) ...[
                          const SizedBox(height: 10),
                          Text(s['youSaveLine']!, style: PwtType.caption().copyWith(fontSize: 11.5)),
                        ],
                      ],
                    ),
                  )
                else if (isQuoteOnly)
                  PwtBanner(
                    variant: BannerVariant.info,
                    title: s['quoteOnly']!,
                    body: ar
                        ? 'يحدد السعر بناءً على متطلبات التركيب — فريقنا سيقترح حلاً مخصصاً.'
                        : 'Pricing is determined by your installation requirements — our team will tailor a quote for you.',
                  ),
                // rent/buy selector (individual only, when both prices exist)
                if (widget.role == AccountKind.individual && !_isQuote && _rentPrice != null && _buyPrice != null) ...[
                  const SizedBox(height: 16),
                  Eyebrow(s['rentOrBuy']!),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(14), border: Border.all(color: PwtColors.hairline)),
                    child: Row(
                      children: [
                        _planTab(s['rent']!, '${_fmtAmt(_rentPrice!.amount)}${s['perMonth']}', _plan == Plan.rent, () => setState(() => _plan = Plan.rent)),
                        _planTab(s['buy']!, _fmtAmt(_buyPrice!.amount), _plan == Plan.buy, () => setState(() => _plan = Plan.buy)),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                // assurances
                Row(
                  children: [
                    _assurance(PwtIcons.truck, s['freeDelivery']!, s['freeDeliverySub']!),
                    const SizedBox(width: 8),
                    _assurance(PwtIcons.wrench, s['freeInstall']!, s['freeInstallSub']!),
                    const SizedBox(width: 8),
                    _assurance(PwtIcons.shield, s['warrantyTitle']!, s['warrantySub']!),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          // tabs
          Container(
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: PwtColors.hairline))),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  for (final tb in tabs)
                    GestureDetector(
                      onTap: () => setState(() => _tab = tb.k),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tb.k == _tab ? PwtColors.brand : Colors.transparent, width: 2))),
                        child: Text(tb.label, style: TextStyle(fontSize: 13.5, fontWeight: tb.k == _tab ? FontWeight.w700 : FontWeight.w500, color: tb.k == _tab ? PwtColors.brand : PwtColors.textSec)),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
            child: _tabContent(features, s, ar),
          ),
        ],
      ),
      bottomBar: _buildBottomBar(s),
    );
  }

  void _addAndGo(BuildContext context, Plan plan) {
    if (web.AppState.instance.user == null) {
      context.read<AppState>().go(AppRoute.login);
      return;
    }
    final pid = _product.id?.toString() ?? _product.uuid ?? '';
    context.read<CartState>().addItem(pid, plan: plan);
    setState(() => _justAdded = true);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      setState(() => _justAdded = false);
      Navigator.push(context, MaterialPageRoute(builder: (_) => CartScreen(role: widget.role)));
    });
  }

  Widget _buildBottomBar(Map<String, String> s) {
    return Builder(builder: (ctx) => PwtButton(
      label: _justAdded ? s['addedToCart']! : (_isQuote ? s['requestQuote']! : s['addToCart']!),
      variant: _justAdded ? PwtButtonVariant.soft : PwtButtonVariant.primary,
      full: true,
      icon: _justAdded ? PwtIcons.check : PwtIcons.cart,
      onPressed: () => _addAndGo(ctx, _currentPlan),
    ));
  }

  Widget _tabContent(List<String> features, Map<String, String> s, bool ar) {
    switch (_tab) {
      case 'specs':
        if (_product.specs.isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Text(
              ar ? 'لا توجد مواصفات متاحة.' : 'No specifications available.',
              style: PwtType.body(color: PwtColors.textSec),
            ),
          );
        }
        return PwtCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              for (int i = 0; i < _product.specs.length; i++)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(border: i == _product.specs.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_product.specs[i].label ?? '', style: PwtType.label(color: PwtColors.textSec).copyWith(fontSize: 13)),
                      Flexible(child: Text(_product.specs[i].value ?? '', textAlign: TextAlign.end, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13))),
                    ],
                  ),
                ),
            ],
          ),
        );
      default: // overview
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if ((_product.description ?? '').isNotEmpty) ...[
              Text(_product.description!, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.6)),
              const SizedBox(height: 12),
            ] else ...[
              Text(ar ? 'ترطيب مميّز كل يوم.' : 'Premium hydration, every day.', style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(
                ar ? 'تصميم أنيق وأداء متقدم وتقنية موفّرة للطاقة — إضافة مثالية لأي مساحة.' : 'A sleek design, advanced filtration and energy-saving technology make this the perfect addition to any home or office.',
                style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5, height: 1.6),
              ),
              const SizedBox(height: 12),
            ],
            for (final f in features)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    const Icon(PwtIcons.check, size: 16, color: PwtColors.success),
                    const SizedBox(width: 10),
                    Expanded(child: Text(f, style: PwtType.label().copyWith(fontSize: 13.5))),
                  ],
                ),
              ),
          ],
        );
    }
  }

  Widget _planTab(String label, String sub, bool on, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: PwtMotion.fast,
          height: 50,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: on ? PwtColors.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            boxShadow: on ? const [BoxShadow(color: Color(0x1F0F172A), blurRadius: 4, offset: Offset(0, 1))] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: TextStyle(fontSize: 13.5, fontWeight: on ? FontWeight.w700 : FontWeight.w600, color: on ? PwtColors.textPri : PwtColors.textSec)),
              Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  const Dirham(size: 9, color: PwtColors.textTer),
                  const SizedBox(width: 2),
                  Text(sub, style: PwtType.caption().copyWith(fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _assurance(IconData icon, String title, String sub) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(color: PwtColors.surface, border: Border.all(color: PwtColors.hairline), borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Icon(icon, size: 18, color: PwtColors.brand),
            const SizedBox(height: 6),
            Text(title, textAlign: TextAlign.center, style: PwtType.label(weight: FontWeight.w700).copyWith(fontSize: 11)),
            const SizedBox(height: 2),
            Text(sub, textAlign: TextAlign.center, style: PwtType.caption().copyWith(fontSize: 9.5)),
          ],
        ),
      ),
    );
  }
}
