// Cart, checkout and success flows.

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/asset_resolver.dart';
import '../core/theme.dart';
import '../core/tokens.dart';
import '../data/mock_data.dart';
import '../i18n/strings.dart';
import '../models/models.dart';
import '../state/app_state.dart';
import '../state/cart_state.dart';
import '../widgets/layout.dart';
import '../widgets/primitives.dart';
import '../widgets/pwt_icons.dart';
import '../../myWeb2/state/app_state.dart' as web;
import '../../Backend/Addresses/get_addresses.dart';
import '../../Backend/Users/PaymentCards/get_payment_cards.dart';
import '../../Backend/Orders/place_order.dart';
import '../../Models/address_model.dart';
import '../../Models/payment_card_model.dart';
import '../../Models/Orders/order_model.dart';

String _genOrderId(AccountKind role) {
  final n = 2300 + Random().nextInt(999);
  return role == AccountKind.business ? 'PWT-B-$n' : 'PWT-${1100 + Random().nextInt(99)}';
}

class _Row {
  _Row(this.item, this.product);
  final CartItem item;
  final Product product;
  int get qty => item.qty;
  Plan get plan => item.plan;
  bool get isQuote => plan == Plan.quote || product.quoteOnly;
  int get unit => plan == Plan.buy ? (product.buyPrice ?? 0) : (product.price ?? 0);
  int get lineTotal => isQuote ? 0 : unit * qty;
}

List<_Row> _rowsOf(CartState cart) => cart.items
    .map((i) => (i, MockData.productById(i.productId)))
    .where((p) => p.$2 != null)
    .map((p) => _Row(p.$1, p.$2!))
    .toList();

// ─── Cart ───
class CartScreen extends StatelessWidget {
  const CartScreen({super.key, required this.role});
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartState>();
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final rows = _rowsOf(cart);

    if (rows.isEmpty) {
      return DetailScaffold(
        title: s['yourCart'],
        body: Padding(
          padding: const EdgeInsets.fromLTRB(20, 60, 20, 0),
          child: Column(
            children: [
              Container(
                width: 84, height: 84,
                decoration: BoxDecoration(color: PwtColors.surface2, shape: BoxShape.circle, border: Border.all(color: PwtColors.hairline)),
                child: const Icon(PwtIcons.cart, size: 36, color: PwtColors.textTer),
              ),
              const SizedBox(height: 18),
              Text(s['emptyCart']!, style: PwtType.title().copyWith(fontSize: 20)),
              const SizedBox(height: 8),
              Text(s['emptyCartSub']!, textAlign: TextAlign.center, style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 13.5)),
              const SizedBox(height: 24),
              PwtButton(label: s['browseProducts']!, onPressed: () => Navigator.pop(context)),
            ],
          ),
        ),
      );
    }

    final subtotal = rows.fold<int>(0, (sum, r) => sum + r.lineTotal);
    final hasQuote = rows.any((r) => r.isQuote);
    final vat = (subtotal * 0.05);
    final total = subtotal + vat;
    final quoteFlow = role == AccountKind.business || hasQuote;
    final isLoggedIn = web.AppState.instance.user != null;

    return DetailScaffold(
      title: s['yourCart'],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Row(
              children: [
                Text('${rows.length} ${rows.length == 1 ? s['item'] : s['items']}', style: PwtType.caption().copyWith(fontSize: 12)),
                const Spacer(),
                GestureDetector(
                  onTap: () => context.read<CartState>().clearBackend(),
                  child: Text('Clear cart', style: PwtType.caption().copyWith(fontSize: 12, color: PwtColors.error)),
                ),
              ],
            ),
          ),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _CartItemCard(row: r, role: role),
            ),
          if (role == AccountKind.individual && !hasQuote) ...[
            const SizedBox(height: 6),
            PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  SummaryRow(label: s['subtotal']!, value: _money(subtotal, PwtColors.textSec)),
                  SummaryRow(label: s['shippingFee']!, value: Text(s['free']!, style: const TextStyle(color: PwtColors.success, fontWeight: FontWeight.w600))),
                  SummaryRow(label: s['vat']!, value: _money(vat, PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(total, PwtColors.textPri)),
                ],
              ),
            ),
          ],
          if (quoteFlow) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: PwtColors.brandTint,
                border: Border.all(color: PwtColors.brandBorder),
                borderRadius: BorderRadius.circular(PwtRadius.card),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(PwtIcons.info, size: 18, color: PwtColors.brand),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      app.isArabic
                          ? 'يتم تحديد الأسعار النهائية بناءً على متطلبات الشركة. سيتواصل معك فريقنا بعرض السعر خلال 24 ساعة.'
                          : 'Final pricing is determined based on your company’s requirements. Our team will share a tailored quotation within 24 hours.',
                      style: PwtType.body(color: PwtColors.textPri).copyWith(fontSize: 12.5, height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
          ],
          // login wall message
          if (!isLoggedIn) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: PwtColors.brandTint,
                border: Border.all(color: PwtColors.brandBorder),
                borderRadius: BorderRadius.circular(PwtRadius.card),
              ),
              child: Row(
                children: [
                  const Icon(PwtIcons.info, size: 18, color: PwtColors.brand),
                  const SizedBox(width: 12),
                  Expanded(child: Text('Sign in or register to proceed to checkout.', style: PwtType.body(color: PwtColors.brand).copyWith(fontSize: 13))),
                ],
              ),
            ),
          ],
        ],
      ),
      bottomBar: quoteFlow
          ? PwtButton(
              label: s['requestQuotation']!,
              full: true,
              icon: PwtIcons.message,
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuotationSuccessScreen(rows: rows, role: role))),
            )
          : PwtButton(
              label: isLoggedIn ? s['proceedToCheckout']! : 'Sign in to Checkout',
              full: true,
              trailing: PwtIcons.arrow,
              onPressed: isLoggedIn
                  ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(rows: rows, subtotal: subtotal, vat: vat, total: total)))
                  : () {
                      // Navigate app-level to login
                      context.read<AppState>().go(AppRoute.login);
                    },
            ),
    );
  }
}

Widget _money(num v, Color color, {double symbol = 11, double size = 14, FontWeight weight = FontWeight.w600}) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.baseline,
    textBaseline: TextBaseline.alphabetic,
    children: [
      Dirham(size: symbol, color: color),
      const SizedBox(width: 3),
      Text(_fmt(v), style: TextStyle(color: color, fontSize: size, fontWeight: weight)),
    ],
  );
}

String _fmt(num v) {
  final s = v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(2);
  final parts = s.split('.');
  final intPart = parts[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return parts.length > 1 ? '$intPart.${parts[1]}' : intPart;
}

class _CartItemCard extends StatelessWidget {
  const _CartItemCard({required this.row, required this.role});
  final _Row row;
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartState>();
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final p = row.product;

    return Container(
      decoration: BoxDecoration(
        color: PwtColors.surface,
        border: Border.all(color: PwtColors.hairline),
        borderRadius: BorderRadius.circular(PwtRadius.card),
        boxShadow: PwtShadows.e1,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 76, height: 88,
                  decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                  alignment: Alignment.center,
                  child: Image(image: pwtImage(p.img), height: 70, fit: BoxFit.contain),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Eyebrow(p.cat, color: p.tint),
                                const SizedBox(height: 4),
                                Text(p.name, style: PwtType.subtitle().copyWith(fontSize: 15)),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () => cart.removeItem(row.item.productId, row.plan),
                            child: const Icon(PwtIcons.close, size: 18, color: PwtColors.textTer),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (row.isQuote)
                        Text(s['quoteOnly']!, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13))
                      else
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            const Dirham(size: 12),
                            const SizedBox(width: 4),
                            Text(_fmt(row.unit), style: PwtType.subtitle().copyWith(fontSize: 16, fontWeight: FontWeight.w700)),
                            if (row.plan == Plan.rent) Text(s['perMonth']!, style: PwtType.caption().copyWith(fontSize: 12)),
                          ],
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (role == AccountKind.individual && !p.quoteOnly)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: PwtColors.hairline)),
                child: Row(
                  children: [
                    _planTab(context, s['rent']!, p.price ?? 0, s['perMonth']!, row.plan == Plan.rent, () => cart.setPlan(row.item.productId, row.plan, Plan.rent)),
                    _planTab(context, s['buy']!, p.buyPrice ?? 0, '', row.plan == Plan.buy, () => cart.setPlan(row.item.productId, row.plan, Plan.buy)),
                  ],
                ),
              ),
            ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: PwtColors.hairline))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(s['quantity']!, style: PwtType.caption(color: PwtColors.textSec).copyWith(fontSize: 12)),
                Row(
                  children: [
                    _StepBtn(icon: PwtIcons.minus, enabled: row.qty > 1, onTap: () => cart.setQty(row.item.productId, row.plan, row.qty - 1)),
                    Container(
                      constraints: const BoxConstraints(minWidth: 44),
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text('${row.qty}', style: PwtType.mono(size: 15, weight: FontWeight.w600)),
                    ),
                    _StepBtn(icon: PwtIcons.plus, primary: true, onTap: () => cart.setQty(row.item.productId, row.plan, row.qty + 1)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _planTab(BuildContext context, String label, int price, String suffix, bool on, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: PwtMotion.fast,
          height: 40,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: on ? PwtColors.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            boxShadow: on ? const [BoxShadow(color: Color(0x1F0F172A), blurRadius: 4, offset: Offset(0, 1))] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: TextStyle(fontSize: 12, fontWeight: on ? FontWeight.w600 : FontWeight.w500, color: on ? PwtColors.textPri : PwtColors.textSec)),
              Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  const Dirham(size: 8, color: PwtColors.textTer),
                  const SizedBox(width: 2),
                  Text('${_fmt(price)}$suffix', style: PwtType.caption().copyWith(fontSize: 10.5)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StepBtn extends StatelessWidget {
  const _StepBtn({required this.icon, required this.onTap, this.enabled = true, this.primary = false});
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.4,
      child: GestureDetector(
        onTap: enabled ? onTap : null,
        child: Container(
          width: 32, height: 32,
          decoration: BoxDecoration(
            color: primary ? PwtColors.brandTint : PwtColors.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: primary ? PwtColors.brandBorder : PwtColors.hairline2),
          ),
          child: Icon(icon, size: 16, color: primary ? PwtColors.brand : PwtColors.textPri),
        ),
      ),
    );
  }
}

// ─── Checkout (multi-step) ───

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key, required this.rows, required this.subtotal, required this.vat, required this.total});
  final List<_Row> rows;
  final int subtotal;
  final double vat;
  final double total;

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int _step = 0; // 0=information 1=delivery 2=payment

  // Step 0 – address
  List<AddressModel> _addresses = [];
  bool _loadingAddresses = true;
  AddressModel? _selectedAddress;
  String? _addressError;

  // Step 1 – delivery
  DateTime? _deliveryDate;
  String? _timeSlot; // 'morning' | 'afternoon' | 'evening'

  // Step 2 – payment
  String _paymentMethod = 'cod';
  List<PaymentCard> _cards = [];
  bool _loadingCards = false;
  int? _selectedCardId;
  bool _enterNewCard = false;
  final _cardNumCtrl  = TextEditingController();
  final _cardExpCtrl  = TextEditingController();
  final _cardCvcCtrl  = TextEditingController();
  final _cardNameCtrl = TextEditingController();
  final _promoCtrl    = TextEditingController();
  final _notesCtrl    = TextEditingController();

  // Submission
  bool _submitting = false;
  String? _error;
  String? _dateError;

  @override
  void initState() {
    super.initState();
    _loadAddresses();
  }

  @override
  void dispose() {
    _cardNumCtrl.dispose();
    _cardExpCtrl.dispose();
    _cardCvcCtrl.dispose();
    _cardNameCtrl.dispose();
    _promoCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAddresses() async {
    final res = await getAddresses();
    if (!mounted) return;
    setState(() {
      _loadingAddresses = false;
      if (res.success && res.data != null) {
        _addresses = res.data!;
        if (_addresses.isNotEmpty) {
          _selectedAddress = _addresses.firstWhere(
            (a) => a.isDefault == true,
            orElse: () => _addresses.first,
          );
        }
      } else {
        _addressError = res.message ?? 'Failed to load addresses.';
      }
    });
  }

  Future<void> _loadCards() async {
    setState(() => _loadingCards = true);
    final res = await getPaymentCards();
    if (!mounted) return;
    setState(() {
      _loadingCards = false;
      if (res.success && res.data != null) {
        _cards = res.data!;
        final def = _cards.where((c) => c.isDefault).firstOrNull;
        _selectedCardId = def?.id ?? (_cards.isNotEmpty ? _cards.first.id : null);
      }
    });
  }

  bool get _canProceed {
    switch (_step) {
      case 0: return _selectedAddress != null;
      case 1: return _timeSlot != null;
      case 2: return _paymentMethod == 'cod' || (_paymentMethod == 'card' && (_selectedCardId != null || _enterNewCard));
      default: return false;
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _deliveryDate ?? now.add(const Duration(days: 1)),
      firstDate: now.add(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 60)),
    );
    if (picked != null) setState(() => _deliveryDate = picked);
  }

  Future<void> _submit() async {
    final user = web.AppState.instance.user;
    final term = widget.rows.isNotEmpty ? widget.rows.first.plan.id : 'buy';

    setState(() { _submitting = true; _error = null; });

    final items = widget.rows.map((r) => {
      'product_id': int.tryParse(r.item.productId) ?? 0,
      'quantity': r.qty,
      'term': r.plan.id,
    }).toList();

    final dateStr = _deliveryDate != null
        ? '${_deliveryDate!.year}-${_deliveryDate!.month.toString().padLeft(2, '0')}-${_deliveryDate!.day.toString().padLeft(2, '0')}'
        : null;

    final promo = _promoCtrl.text.trim().isEmpty ? null : _promoCtrl.text.trim();
    final notes = _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim();
    String? cardNumber;
    String? cardExpiry;
    String? cardCvc;
    if (_paymentMethod == 'card') {
      if (!_enterNewCard && _selectedCardId != null) {
        final saved = _cards.where((c) => c.id == _selectedCardId).firstOrNull;
        if (saved != null) {
          cardNumber = saved.cardNumberHash ?? saved.lastFour;
          cardExpiry = '${saved.expiryMonth}/${saved.expiryYear}';
          cardCvc    = saved.cvc;
        }
      } else {
        final num = _cardNumCtrl.text.replaceAll(' ', '');
        cardNumber = num.isEmpty ? null : num;
        cardExpiry = _cardExpCtrl.text.trim().isEmpty ? null : _cardExpCtrl.text.trim();
        cardCvc    = _cardCvcCtrl.text.trim().isEmpty ? null : _cardCvcCtrl.text.trim();
      }
    }

    final res = await placeOrder(
      items: items,
      customerName: user?.name,
      customerEmail: user?.email,
      customerPhone: user?.phone,
      deliveryAddressId: _selectedAddress?.id,
      deliveryDate: dateStr,
      deliveryTimeSlot: _timeSlot,
      term: term,
      paymentMethod: _paymentMethod,
      cardNumber: cardNumber,
      cardExpiry: cardExpiry,
      cardCvc:    cardCvc,
      promoCode: promo,
      notes: notes,
    );

    if (!mounted) return;

    if (res.success && res.data != null) {
      context.read<CartState>().clearBackend();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => OrderSuccessScreen(order: res.data!, subtotal: widget.subtotal, vat: widget.vat)),
      );
    } else {
      setState(() { _error = res.message ?? 'Failed to place order. Please try again.'; _submitting = false; });
    }
  }

  static const _months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  String _fmtDate(DateTime d) => '${d.day} ${_months[d.month - 1]} ${d.year}';

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);

    return DetailScaffold(
      title: s['checkout'],
      body: Column(
        children: [
          _buildStepBar(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.only(bottom: 24),
              children: [
                if (_step == 0) ..._buildInfoStep(s, app.isArabic),
                if (_step == 1) ..._buildDeliveryStep(s),
                if (_step == 2) ..._buildPaymentStep(s),
              ],
            ),
          ),
        ],
      ),
      bottomBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_error != null)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                color: PwtColors.errorFill,
                border: Border.all(color: PwtColors.errorBorder),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, size: 16, color: PwtColors.error),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(fontSize: 13, color: PwtColors.error))),
                ],
              ),
            ),
          PwtButton(
            label: _submitting ? 'Placing order…' : (_step < 2 ? 'Continue' : s['placeOrder']!),
            full: true,
            trailing: _step < 2 ? PwtIcons.arrow : null,
            disabled: !_canProceed || _submitting,
            onPressed: _step < 2
                ? () {
                    if (_step == 1 && _deliveryDate == null) {
                      setState(() => _dateError = 'Please select a preferred delivery date');
                      return;
                    }
                    if (_step == 1 && _paymentMethod == 'card' && _cards.isEmpty) _loadCards();
                    setState(() { _step++; _error = null; _dateError = null; });
                  }
                : _submit,
          ),
        ],
      ),
    );
  }

  // ── Step indicator ──
  Widget _buildStepBar() {
    const labels = ['Information', 'Delivery', 'Payment'];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      child: Row(
        children: [
          for (int i = 0; i < 3; i++) ...[
            if (i > 0) Expanded(
              child: Container(
                height: 2,
                color: i <= _step ? PwtColors.brand : PwtColors.hairline2,
              ),
            ),
            _StepDot(index: i + 1, active: i == _step, done: i < _step, label: labels[i]),
          ],
        ],
      ),
    );
  }

  // ── Step 0 – Information ──
  List<Widget> _buildInfoStep(Map<String, String> s, bool ar) {
    return [
      Section(
        title: s['orderSummary']!,
        child: PwtCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              for (int i = 0; i < widget.rows.length; i++)
                _summaryItem(widget.rows[i], s, ar, last: i == widget.rows.length - 1),
            ],
          ),
        ),
      ),
      Section(
        title: 'Delivery Address',
        child: _buildAddressSection(),
      ),
    ];
  }

  Widget _buildAddressSection() {
    if (_loadingAddresses) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
      );
    }
    if (_addressError != null) {
      return PwtBanner(variant: BannerVariant.error, title: 'Could not load addresses', body: _addressError!);
    }
    if (_addresses.isEmpty) {
      return PwtBanner(variant: BannerVariant.info, title: 'No saved addresses', body: 'Please add a delivery address in your profile to continue.');
    }
    return Column(
      children: [
        for (final addr in _addresses)
          GestureDetector(
            onTap: () => setState(() => _selectedAddress = addr),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: PwtColors.surface,
                border: Border.all(
                  color: _selectedAddress?.id == addr.id ? PwtColors.brand : PwtColors.hairline,
                  width: _selectedAddress?.id == addr.id ? 2 : 1,
                ),
                borderRadius: BorderRadius.circular(PwtRadius.card),
              ),
              child: Row(
                children: [
                  Icon(PwtIcons.pin, size: 20, color: _selectedAddress?.id == addr.id ? PwtColors.brand : PwtColors.textTer),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(addr.label ?? 'Address', style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                            if (addr.isDefault == true) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(color: PwtColors.brandTint, borderRadius: BorderRadius.circular(999)),
                                child: Text('Default', style: PwtType.caption().copyWith(fontSize: 10, color: PwtColors.brand, fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          [addr.line1, addr.city, addr.country?.name].where((v) => v != null && v.isNotEmpty).join(', '),
                          style: PwtType.body(color: PwtColors.textSec).copyWith(fontSize: 12.5),
                        ),
                        if (addr.recipientName != null || addr.recipientPhone != null) ...[
                          const SizedBox(height: 2),
                          Text(
                            [addr.recipientName, addr.recipientPhone].where((v) => v != null && v!.isNotEmpty).join(' · '),
                            style: PwtType.caption().copyWith(fontSize: 11.5),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (_selectedAddress?.id == addr.id)
                    const Icon(Icons.check_circle, size: 20, color: PwtColors.brand),
                ],
              ),
            ),
          ),
      ],
    );
  }

  // ── Step 1 – Delivery ──
  List<Widget> _buildDeliveryStep(Map<String, String> s) {
    Widget slotBtn(String value, String label, String sub) {
      final on = _timeSlot == value;
      return Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _timeSlot = value),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: on ? PwtColors.brand : PwtColors.surface,
              border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(label, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: on ? Colors.white : PwtColors.textPri)),
                const SizedBox(height: 2),
                Text(sub, style: TextStyle(fontSize: 11, color: on ? Colors.white.withValues(alpha: .8) : PwtColors.textTer)),
              ],
            ),
          ),
        ),
      );
    }

    return [
      Section(
        title: 'Preferred Delivery Date',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          GestureDetector(
            onTap: () { _pickDate(); setState(() => _dateError = null); },
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: PwtColors.surface,
                borderRadius: BorderRadius.circular(PwtRadius.md),
                border: Border.all(
                  color: _dateError != null ? PwtColors.error : PwtColors.hairline,
                  width: _dateError != null ? 1.5 : 1,
                ),
                boxShadow: PwtShadows.e1,
              ),
              child: Row(children: [
                Icon(PwtIcons.cal, size: 20, color: _dateError != null ? PwtColors.error : PwtColors.brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _deliveryDate != null ? _fmtDate(_deliveryDate!) : 'Select a date…',
                    style: _deliveryDate != null
                        ? PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)
                        : PwtType.body(color: PwtColors.textTer).copyWith(fontSize: 14),
                  ),
                ),
                const Icon(PwtIcons.caret, size: 16, color: PwtColors.textTer),
              ]),
            ),
          ),
          if (_dateError != null)
            Padding(
              padding: const EdgeInsets.only(top: 6, left: 2),
              child: Text(_dateError!, style: PwtType.body(color: PwtColors.error).copyWith(fontSize: 12)),
            ),
        ]),
      ),
      Section(
        title: 'Preferred Time Slot',
        child: Row(
          children: [
            slotBtn('morning', 'Morning', '6 AM – 12 PM'),
            const SizedBox(width: 8),
            slotBtn('afternoon', 'Afternoon', '12 PM – 6 PM'),
            const SizedBox(width: 8),
            slotBtn('evening', 'Evening', '6 PM – 10 PM'),
          ],
        ),
      ),
    ];
  }

  // ── Step 2 – Payment ──
  List<Widget> _buildPaymentStep(Map<String, String> s) {
    Widget methodBtn(String value, String label, IconData icon) {
      final on = _paymentMethod == value;
      return Expanded(
        child: GestureDetector(
          onTap: () {
            setState(() { _paymentMethod = value; });
            if (value == 'card' && _cards.isEmpty && !_loadingCards) _loadCards();
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: on ? PwtColors.brandTint : PwtColors.surface,
              border: Border.all(color: on ? PwtColors.brand : PwtColors.hairline, width: on ? 2 : 1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Icon(icon, size: 22, color: on ? PwtColors.brand : PwtColors.textSec),
                const SizedBox(height: 6),
                Text(label, style: TextStyle(fontSize: 13, fontWeight: on ? FontWeight.w700 : FontWeight.w500, color: on ? PwtColors.brand : PwtColors.textPri)),
              ],
            ),
          ),
        ),
      );
    }

    return [
      Section(
        title: s['paymentMethod']!,
        child: Column(
          children: [
            Row(
              children: [
                methodBtn('cod', 'Cash on Delivery', Icons.money_outlined),
                const SizedBox(width: 10),
                methodBtn('card', 'Credit / Debit Card', Icons.credit_card_outlined),
              ],
            ),
            if (_paymentMethod == 'card') ...[
              const SizedBox(height: 16),
              _buildCardSection(),
            ],
          ],
        ),
      ),
      Section(
        title: 'Promo Code',
        child: PwtCard(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: TextField(
            controller: _promoCtrl,
            textCapitalization: TextCapitalization.characters,
            style: PwtType.mono(size: 14),
            decoration: const InputDecoration(
              hintText: 'Enter promo code',
              border: InputBorder.none,
              isDense: true,
            ),
          ),
        ),
      ),
      Section(
        title: 'Notes',
        child: PwtCard(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: TextField(
            controller: _notesCtrl,
            maxLines: 3,
            style: PwtType.body(color: PwtColors.textPri).copyWith(fontSize: 14),
            decoration: const InputDecoration(
              hintText: 'Any notes for delivery or installation…',
              border: InputBorder.none,
              isDense: true,
            ),
          ),
        ),
      ),
      Section(
        title: s['total']!,
        child: PwtCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              SummaryRow(label: s['subtotal']!, value: _money(widget.subtotal, PwtColors.textSec)),
              SummaryRow(label: s['shippingFee']!, value: Text(s['free']!, style: const TextStyle(color: PwtColors.success, fontWeight: FontWeight.w600))),
              SummaryRow(label: s['vat']!, value: _money(widget.vat, PwtColors.textSec)),
              SummaryRow(label: s['total']!, bold: true, last: true, value: _money(widget.subtotal + widget.vat, PwtColors.textPri)),
            ],
          ),
        ),
      ),
    ];
  }

  Widget _buildCardSection() {
    if (_loadingCards) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: PwtColors.brand)),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_cards.isNotEmpty) ...[
          for (final c in _cards)
            GestureDetector(
              onTap: () => setState(() { _selectedCardId = c.id; _enterNewCard = false; }),
              child: Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: PwtColors.surface,
                  border: Border.all(
                    color: !_enterNewCard && _selectedCardId == c.id ? PwtColors.brand : PwtColors.hairline,
                    width: !_enterNewCard && _selectedCardId == c.id ? 2 : 1,
                  ),
                  borderRadius: BorderRadius.circular(PwtRadius.card),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44, height: 28,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        gradient: const LinearGradient(colors: [Color(0xFF1A1F71), Color(0xFF4A52A3)]),
                      ),
                      alignment: Alignment.center,
                      child: Text(c.brand.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text('${c.brand} ···· ${c.lastFour}', style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                          ),
                          Text('${c.cardholderName} · Exp ${c.expiryMonth}/${c.expiryYear}', style: PwtType.caption().copyWith(fontSize: 11.5)),
                        ],
                      ),
                    ),
                    if (c.isDefault)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(color: PwtColors.brandTint, borderRadius: BorderRadius.circular(999)),
                        child: Text('Default', style: PwtType.caption().copyWith(fontSize: 10, color: PwtColors.brand, fontWeight: FontWeight.w600)),
                      ),
                    const SizedBox(width: 8),
                    if (!_enterNewCard && _selectedCardId == c.id)
                      const Icon(Icons.check_circle, size: 20, color: PwtColors.brand),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 4),
          GestureDetector(
            onTap: () => setState(() { _enterNewCard = !_enterNewCard; _selectedCardId = null; }),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Icon(_enterNewCard ? Icons.remove_circle_outline : Icons.add_circle_outline, size: 18, color: PwtColors.brand),
                  const SizedBox(width: 8),
                  Text(_enterNewCard ? 'Use a saved card' : 'Use a new card', style: PwtType.label(color: PwtColors.brand, weight: FontWeight.w600).copyWith(fontSize: 13.5)),
                ],
              ),
            ),
          ),
        ],
        if (_cards.isEmpty || _enterNewCard) ...[
          _cardInput('Card Number', _cardNumCtrl, TextInputType.number, '1234 5678 9012 3456'),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _cardInput('Expiry', _cardExpCtrl, TextInputType.datetime, 'MM/YY')),
              const SizedBox(width: 10),
              Expanded(child: _cardInput('CVV', _cardCvcCtrl, TextInputType.number, '123')),
            ],
          ),
          const SizedBox(height: 10),
          _cardInput('Cardholder Name', _cardNameCtrl, TextInputType.name, 'Full name on card'),
        ],
      ],
    );
  }

  Widget _cardInput(String label, TextEditingController ctrl, TextInputType type, String hint) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: PwtType.caption().copyWith(fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        PwtCard(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: TextField(
            controller: ctrl,
            keyboardType: type,
            style: PwtType.mono(size: 14),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: PwtType.mono(size: 14, color: PwtColors.textTer),
              border: InputBorder.none,
              isDense: true,
            ),
          ),
        ),
      ],
    );
  }

  Widget _summaryItem(_Row r, Map<String, String> s, bool ar, {bool last = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
      child: Row(
        children: [
          Container(
            width: 44, height: 56,
            decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: PwtColors.hairline)),
            alignment: Alignment.center,
            child: Image(image: pwtImage(r.product.img), height: 42, fit: BoxFit.contain),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 14)),
                const SizedBox(height: 2),
                Text('${r.plan == Plan.rent ? s['rent'] : s['buy']} · ${ar ? 'كمية' : 'Qty'} ${r.qty}', style: PwtType.caption().copyWith(fontSize: 11.5)),
              ],
            ),
          ),
          _money(r.unit * r.qty, PwtColors.textPri, size: 14),
        ],
      ),
    );
  }
}

class _StepDot extends StatelessWidget {
  const _StepDot({required this.index, required this.active, required this.done, required this.label});
  final int index;
  final bool active;
  final bool done;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: done || active ? PwtColors.brand : PwtColors.surface,
            border: Border.all(color: active || done ? PwtColors.brand : PwtColors.hairline2, width: 2),
          ),
          alignment: Alignment.center,
          child: done
              ? const Icon(Icons.check, size: 14, color: Colors.white)
              : Text('$index', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: active ? Colors.white : PwtColors.textTer)),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w600 : FontWeight.w400, color: active ? PwtColors.brand : PwtColors.textTer)),
      ],
    );
  }
}

// ─── Order confirmed ───
class OrderSuccessScreen extends StatelessWidget {
  const OrderSuccessScreen({super.key, required this.order, required this.subtotal, required this.vat});
  final OrderDetailModel order;
  final int subtotal;
  final double vat;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);

    return DetailScaffold(
      title: s['orderConfirmed'],
      onBack: () => Navigator.of(context).popUntil((r) => r.isFirst),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          SuccessView(
            title: s['orderConfirmed']!,
            body: s['orderConfirmedSub']!,
            detail: Directionality(
              textDirection: TextDirection.ltr,
              child: Text('Order #${order.id}', style: PwtType.mono(size: 12, color: PwtColors.brand, weight: FontWeight.w600)),
            ),
          ),
          Section(
            title: s['total']!,
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  SummaryRow(label: s['subtotal']!, value: _money(double.tryParse(order.subtotalAmount) ?? subtotal, PwtColors.textSec)),
                  SummaryRow(label: s['vat']!, value: _money(double.tryParse(order.taxAmount) ?? vat, PwtColors.textSec)),
                  SummaryRow(label: s['total']!, bold: true, last: true, value: _money(double.tryParse(order.totalAmount) ?? (subtotal + vat), PwtColors.textPri)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              children: [
                PwtButton(label: s['viewOrder']!, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
                const SizedBox(height: 10),
                PwtButton(label: s['continueShopping']!, variant: PwtButtonVariant.ghost, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Quotation submitted ───
class QuotationSuccessScreen extends StatelessWidget {
  const QuotationSuccessScreen({super.key, required this.rows, required this.role});
  final List<_Row> rows;
  final AccountKind role;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final s = Strings.of(app.lang);
    final orderId = _genOrderId(AccountKind.business);

    return DetailScaffold(
      title: s['quotationSubmitted'],
      onBack: () => Navigator.of(context).popUntil((r) => r.isFirst),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          SuccessView(
            title: s['quotationSubmitted']!,
            body: s['quotationSubmittedSub']!,
            icon: PwtIcons.message,
            accent: PwtColors.brand,
            detail: Directionality(
              textDirection: TextDirection.ltr,
              child: Text('${s['orderId']}  $orderId', style: PwtType.mono(size: 12, color: PwtColors.brand, weight: FontWeight.w600)),
            ),
          ),
          Section(
            title: app.isArabic ? 'العناصر المطلوبة' : 'Requested items',
            child: PwtCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: [
                  for (int i = 0; i < rows.length; i++)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(border: i == rows.length - 1 ? null : const Border(bottom: BorderSide(color: PwtColors.hairline))),
                      child: Row(
                        children: [
                          Container(
                            width: 40, height: 50,
                            decoration: BoxDecoration(color: PwtColors.surface2, borderRadius: BorderRadius.circular(8), border: Border.all(color: PwtColors.hairline)),
                            alignment: Alignment.center,
                            child: Image(image: pwtImage(rows[i].product.img), height: 38, fit: BoxFit.contain),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Text(rows[i].product.name, style: PwtType.label(weight: FontWeight.w600).copyWith(fontSize: 13.5))),
                          Text('${app.isArabic ? 'كمية' : 'Qty'} ${rows[i].qty}', style: PwtType.caption().copyWith(fontSize: 11.5)),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: PwtBanner(
              variant: BannerVariant.info,
              title: app.isArabic ? 'الخطوات التالية' : 'What happens next',
              body: app.isArabic
                  ? 'سيراجع فريقنا متطلباتك ويرسل عرض السعر مع تفاصيل التركيب خلال 24 ساعة عمل.'
                  : 'Our team will review your requirements and send a tailored quote with installation details within 24 working hours.',
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Column(
              children: [
                PwtButton(label: s['viewOrder']!, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
                const SizedBox(height: 10),
                PwtButton(label: s['continueShopping']!, variant: PwtButtonVariant.ghost, full: true, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
