import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../../myWeb2/state/app_state.dart' as webState;
import '../../Backend/Cart/get_cart.dart';
import '../../Backend/Cart/add_cart_item.dart';
import '../../Backend/Cart/update_cart_item.dart';
import '../../Backend/Cart/remove_cart_item.dart';
import '../../Backend/Cart/clear_cart.dart';
import '../../Models/Cart/cart_model.dart';

class CartState extends ChangeNotifier {
  CartState() {
    webState.AppState.instance.addListener(_onAuthChange);
    // If already logged in when constructed (app restart with saved session)
    if (webState.AppState.instance.user != null) {
      _cartLoaded = true;
      loadFromBackend();
    }
  }

  final List<CartItem> _items = [];
  bool _cartLoaded = false;

  List<CartItem> get items => List.unmodifiable(_items);
  int get totalQty => _items.fold(0, (sum, i) => sum + i.qty);
  bool get isEmpty => _items.isEmpty;

  bool get _isLoggedIn => webState.AppState.instance.user != null;

  void _onAuthChange() {
    final loggedIn = webState.AppState.instance.user != null;
    if (loggedIn && !_cartLoaded) {
      _cartLoaded = true;
      loadFromBackend();
    } else if (!loggedIn && _cartLoaded) {
      _cartLoaded = false;
      _items.clear();
      notifyListeners();
    }
  }

  @override
  void dispose() {
    webState.AppState.instance.removeListener(_onAuthChange);
    super.dispose();
  }

  int _indexOf(String productId, Plan plan) =>
      _items.indexWhere((i) => i.productId == productId && i.plan == plan);

  Future<void> addItem(String productId, {Plan plan = Plan.rent, int qty = 1}) async {
    final idx = _indexOf(productId, plan);
    final existingBackendId = idx >= 0 ? _items[idx].backendItemId : null;
    if (idx >= 0) {
      _items[idx] = _items[idx].copyWith(qty: _items[idx].qty + qty);
    } else {
      _items.add(CartItem(productId: productId, plan: plan, qty: qty));
    }
    notifyListeners();

    if (_isLoggedIn) {
      final id = int.tryParse(productId);
      if (id != null) {
        final newQty = _items.where((i) => i.productId == productId && i.plan == plan).firstOrNull?.qty ?? qty;
        final res = existingBackendId != null
            ? await updateCartItem(existingBackendId, quantity: newQty)
            : await addCartItem(productId: id, term: plan.id, quantity: qty);
        if (res.success && res.data != null) {
          _applyBackendCart(res.data!);
          notifyListeners();
        }
      }
    }
  }

  Future<void> setPlan(String productId, Plan oldPlan, Plan newPlan) async {
    final idx = _indexOf(productId, oldPlan);
    if (idx < 0) return;
    final backendId = _items[idx].backendItemId;
    final currentQty = _items[idx].qty;

    final existing = _indexOf(productId, newPlan);
    if (existing >= 0 && existing != idx) {
      _items[existing] = _items[existing].copyWith(qty: _items[existing].qty + currentQty);
      _items.removeAt(idx);
    } else {
      _items[idx] = _items[idx].copyWith(plan: newPlan);
    }
    notifyListeners();

    if (_isLoggedIn) {
      if (backendId != null) await removeCartItem(backendId);
      final id = int.tryParse(productId);
      if (id != null) {
        final res = await addCartItem(productId: id, term: newPlan.id, quantity: currentQty);
        if (res.success && res.data != null) {
          _applyBackendCart(res.data!);
          notifyListeners();
        }
      }
    }
  }

  Future<void> setQty(String productId, Plan plan, int qty) async {
    final idx = _indexOf(productId, plan);
    if (idx < 0) return;
    if (qty <= 0) {
      await removeItem(productId, plan);
      return;
    }
    final backendId = _items[idx].backendItemId;
    _items[idx] = _items[idx].copyWith(qty: qty);
    notifyListeners();

    if (_isLoggedIn && backendId != null) {
      final res = await updateCartItem(backendId, quantity: qty);
      if (res.success && res.data != null) {
        _applyBackendCart(res.data!);
        notifyListeners();
      }
    }
  }

  Future<void> removeItem(String productId, Plan plan) async {
    final idx = _indexOf(productId, plan);
    final backendId = idx >= 0 ? _items[idx].backendItemId : null;
    _items.removeWhere((i) => i.productId == productId && i.plan == plan);
    notifyListeners();

    if (_isLoggedIn && backendId != null) {
      final res = await removeCartItem(backendId);
      if (res.success && res.data != null) {
        _applyBackendCart(res.data!);
        notifyListeners();
      }
    }
  }

  Future<void> clearBackend() async {
    if (_isLoggedIn) await clearCart();
    _items.clear();
    notifyListeners();
  }

  Future<void> loadFromBackend() async {
    final res = await getCart();
    if (!res.success || res.data == null) return;
    _applyBackendCart(res.data!);
    notifyListeners();
  }

  void _applyBackendCart(CartModel backendCart) {
    _items.clear();
    for (final item in backendCart.items) {
      _items.add(CartItem(
        productId: item.productId.toString(),
        plan: PlanX.fromId(item.term),
        qty: item.quantity,
        backendItemId: item.id,
      ));
    }
  }
}
