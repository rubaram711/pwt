import 'package:dio/dio.dart' as dio;
import '../../myWeb2/state/app_state.dart';
import '../../Models/Cart/cart_model.dart';
import '../../Models/api_response_model.dart';
import '../../Services/api_handler.dart';
import '../../const/urls.dart';

Future<ApiResponse<CartModel>> getCart() async {
  final dio.Dio di = AppState.instance.dioService.dio;
  return ApiHandler.handleRequest<CartModel>(
    request: () => di.get(kCartUrl),
    parser: (data) => CartModel.fromJson(data),
  );
}
