import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';

/// KPI summary tile (Total Devices, Rented, …).
class KpiTile extends StatelessWidget {
  final String label, value, sub;
  final IconData? icon;
  final Color iconColor;
  const KpiTile({super.key, required this.label, required this.value, required this.sub, this.icon, this.iconColor = AppColors.blue700});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: AppText.muted)),
          if (icon != null) Container(width: 38, height: 38, decoration: BoxDecoration(color: iconColor.withOpacity(.12), borderRadius: BorderRadius.circular(10)), child: Icon(icon, size: 20, color: iconColor)),
        ]),
        const SizedBox(height: 10),
        Text(value, style: AppText.pageTitle.copyWith(fontSize: 28)),
        const SizedBox(height: 2),
        Text(sub, style: AppText.muted),
      ]),
    );
  }
}

/// Responsive grid of KPI tiles.
class KpiGrid extends StatelessWidget {
  final List<KpiTile> tiles;
  const KpiGrid({super.key, required this.tiles});
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final cols = c.maxWidth > 760 ? tiles.length.clamp(1, 4) : c.maxWidth > 460 ? 2 : 1;
      return GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: cols,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 1.9,
        children: tiles,
      );
    });
  }
}

/// Vertical progress timeline (orders / maintenance tracking).
class TimelineStep {
  final String title, sub;
  final bool done;
  final bool active;
  const TimelineStep(this.title, this.sub, {this.done = false, this.active = false});
}

class Timeline extends StatelessWidget {
  final List<TimelineStep> steps;
  const Timeline({super.key, required this.steps});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: List.generate(steps.length, (i) {
      final s = steps[i];
      final filled = s.done || s.active;
      final color = s.done ? AppColors.green600 : s.active ? AppColors.blue700 : AppColors.ink300;
      return IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Column(children: [
            Container(width: 14, height: 14, decoration: BoxDecoration(color: filled ? color : Colors.white, shape: BoxShape.circle, border: Border.all(color: color, width: 2))),
            if (i < steps.length - 1) Expanded(child: Container(width: 2, color: s.done ? AppColors.green600 : AppColors.line)),
          ]),
          const SizedBox(width: 14),
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title, style: AppText.label.copyWith(color: s.active || s.done ? AppColors.ink900 : AppColors.ink500)),
              const SizedBox(height: 2),
              Text(s.sub, style: AppText.muted),
            ]),
          ),
        ]),
      );
    }));
  }
}

/// Simple data table for dashboard lists (Orders / Invoices).
class DashTable extends StatelessWidget {
  final List<String> headers;
  final List<List<Widget>> rows;
  const DashTable({super.key, required this.headers, required this.rows});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: ConstrainedBox(
        constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width > 1100 ? 1050 : 760),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
                children: headers.map((h) =>
                //Expanded( flex: h == headers.first ? 3 : 2,
                    SizedBox(
                    width: 200,
                    child: Text(h, style: AppText.muted.copyWith(fontWeight: FontWeight.w700)))).toList()),
          ),
          const Divider(height: 1, color: AppColors.line),
          ...rows.map((r) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(crossAxisAlignment: CrossAxisAlignment.center,
                    children: List.generate(r.length, (i) =>
                        // Expanded(flex: i == 0 ? 3 : 2,
                    SizedBox(
                        width: 200,
                            child: r[i]))),
              )),
        ]),
      ),
    );
  }
}

/// Product cell used inside dashboard tables (thumb + name + sub).
class ProdCell extends StatelessWidget {
  final String image, name, sub;
  const ProdCell({super.key, required this.image, required this.name, required this.sub});
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(9)), padding: const EdgeInsets.all(5), child: Image.asset(image, fit: BoxFit.contain)),
      const SizedBox(width: 11),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text(name, style: AppText.label, maxLines: 1, overflow: TextOverflow.ellipsis),
        Text(sub, style: AppText.muted, maxLines: 1, overflow: TextOverflow.ellipsis),
      ])),
    ]);
  }
}
