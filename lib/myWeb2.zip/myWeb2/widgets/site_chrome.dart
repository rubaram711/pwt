import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';

/// Money formatter: £1,536
String money(num n) {
  final s = n.round().toString();
  final buf = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  return '£$buf';
}

const _storeLinks = [
  ['Home', '/'],
  ['Shop', '/shop'],
  ['Solutions', '/solutions'],
  ['About Us', '/about'],
  ['Contact', '/contact'],
];

/// Top storefront navbar (logo · links · search/cart/account · Sign In).
class SiteHeader extends StatelessWidget implements PreferredSizeWidget {
  final String active; // route name
  final bool showLeadingMenu;
  const SiteHeader({super.key, this.active = '/', this.showLeadingMenu = false});

  @override
  Size get preferredSize => const Size.fromHeight(78);

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 900;
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      scrolledUnderElevation: 0,
      toolbarHeight: 78,
      shape: const Border(bottom: BorderSide(color: AppColors.line)),
      titleSpacing: showLeadingMenu ? 4 : 24,
      automaticallyImplyLeading: false,
      leading: showLeadingMenu ? Builder(builder: (c) => IconButton(icon: const Icon(Icons.menu, color: AppColors.ink800), onPressed: () => Scaffold.of(c).openDrawer())) : null,
      title: Row(children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false),
          child: Row(children: [
            Image.asset('assets/images/pwt-logo.png', width: 38, height: 38, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop, color: AppColors.blue700)),
            const SizedBox(width: 9),
            Text('PWT', style: AppText.h3.copyWith(fontSize: 25, letterSpacing: 1.0, fontWeight: FontWeight.w800)),
          ]),
        ),
        if (wide) ...[
          const SizedBox(width: 36),
          ..._storeLinks.map((l) => _NavLink(label: l[0], route: l[1], active: active == l[1])),
        ],
        const Spacer(),
        _icon(context, Icons.search, null),
        Stack(clipBehavior: Clip.none, children: [
          _icon(context, Icons.shopping_cart_outlined, '/cart'),
          Positioned(
            right: 4,
            top: 2,
            child: AnimatedBuilder(
              animation: AppState.I,
              builder: (_, __) {
                final n = AppState.I.cartCount;
                if (n == 0) return const SizedBox.shrink();
                return Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(color: AppColors.blue700, shape: BoxShape.circle),
                  constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                  child: Text('$n', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.w800, height: 1)),
                );
              },
            ),
          ),
        ]),
        _icon(context, Icons.person_outline, '/login'),
        const SizedBox(width: 8),
        _SignInButton(),
        const SizedBox(width: 6),
      ]),
    );
  }

  Widget _icon(BuildContext context, IconData ic, String? route) => IconButton(
        onPressed: route == null ? () {} : () => Navigator.of(context).pushNamed(route),
        icon: Icon(ic, color: AppColors.ink800, size: 22),
        splashRadius: 22,
      );
}

class _NavLink extends StatelessWidget {
  final String label;
  final String route;
  final bool active;
  const _NavLink({required this.label, required this.route, required this.active});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: InkWell(
        onTap: () => Navigator.of(context).pushNamed(route),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, children: [
          Text(label,
              style: AppText.body.copyWith(
                fontSize: 15.5,
                fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                color: active ? AppColors.ink900 : AppColors.ink700,
              )),
          const SizedBox(height: 5),
          Container(height: 2, width: active ? 18 : 0, decoration: BoxDecoration(color: AppColors.blue700, borderRadius: BorderRadius.circular(2))),
        ]),
      ),
    );
  }
}

class _SignInButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (_, __) {
        final u = AppState.I.user;
        if (u != null) {
          return GestureDetector(
            onTap: () => Navigator.of(context).pushNamed(u.isCompany ? '/companyDashboard' : '/dashboard'),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(AppRadius.pill)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                CircleAvatar(radius: 12, backgroundColor: AppColors.blue100, child: Text(u.initials, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.blue800))),
                const SizedBox(width: 7),
                Text(u.isCompany ? u.company : u.name, style: AppText.label.copyWith(color: AppColors.blue800)),
              ]),
            ),
          );
        }
        return ElevatedButton(
          onPressed: () => Navigator.of(context).pushNamed('/login'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.blue700,
            foregroundColor: Colors.white,
            elevation: 0,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.pill)),
            textStyle: AppText.label.copyWith(fontWeight: FontWeight.w700),
          ),
          child: const Text('Sign In'),
        );
      },
    );
  }
}

/// WhatsApp-style floating button.
class WhatsAppFab extends StatelessWidget {
  const WhatsAppFab({super.key});
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () {},
      backgroundColor: const Color(0xFF25D366),
      foregroundColor: Colors.white,
      elevation: 4,
      child: const Icon(Icons.chat_bubble, size: 26),
    );
  }
}

/// Shared footer for storefront pages.
class SiteFooter extends StatelessWidget {
  const SiteFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 760;
    final cols = [
      ['SHOP', ['Water Dispensers', 'Countertop Systems', 'Reverse Osmosis', 'Filters & Cartridges'], '/shop'],
      ['SOLUTIONS', ['For Home', 'For Office', 'For Business', 'Industrial'], '/solutions'],
      ['COMPANY', ['About Us', 'Careers', 'Blog', 'News'], '/about'],
      ['SUPPORT', ['Help Center', 'Maintenance', 'Returns', 'Warranty'], '/support'],
    ];
    return Container(
      color: AppColors.ink900,
      padding: const EdgeInsets.fromLTRB(28, 44, 28, 28),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1280),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 48, runSpacing: 28, children: [
              SizedBox(
                width: wide ? 280 : double.infinity,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Image.asset('assets/images/pwt-logo.png', width: 28, height: 28, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop, color: Colors.white)),
                    const SizedBox(width: 9),
                    const Text('PWT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18, letterSpacing: 1.4)),
                  ]),
                  const SizedBox(height: 14),
                  Text('Advanced water purification solutions for a healthier, better everyday. Pure Water. Pure Life.',
                      style: AppText.body.copyWith(color: const Color(0xFF9AA6BF), height: 1.6)),
                ]),
              ),
              ...cols.map((c) => SizedBox(
                    width: 150,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c[0] as String, style: const TextStyle(color: Color(0xFF7E8AA6), fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 0.8)),
                      const SizedBox(height: 14),
                      ...(c[1] as List).map((t) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: InkWell(
                              onTap: () => Navigator.of(context).pushNamed(c[2] as String),
                              child: Text(t, style: AppText.body.copyWith(color: const Color(0xFFC4CCDD))),
                            ),
                          )),
                    ]),
                  )),
            ]),
            const SizedBox(height: 32),
            const Divider(color: Color(0xFF23304F), height: 1),
            const SizedBox(height: 18),
            Text('© 2025 PWT. All rights reserved.', style: AppText.muted.copyWith(color: const Color(0xFF7E8AA6))),
          ]),
        ),
      ),
    );
  }
}

/// Wraps a storefront page: header + scrollable body (with footer) + WA fab.
class StoreScaffold extends StatelessWidget {
  final String active;
  final List<Widget> slivers;
  final bool showFooter;
  const StoreScaffold({super.key, required this.active, required this.slivers, this.showFooter = true});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: SiteHeader(active: active),
      floatingActionButton: const WhatsAppFab(),
      body: CustomScrollView(
        slivers: [
          ...slivers,
          if (showFooter) const SliverToBoxAdapter(child: SiteFooter()),
        ],
      ),
    );
  }
}

/// Centered max-width content band used across storefront sections.
class Band extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final double maxWidth;
  const Band({super.key, required this.child, this.padding = const EdgeInsets.symmetric(horizontal: 32, vertical: 40), this.color, this.maxWidth = 1280});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: color,
      padding: padding,
      child: Center(child: ConstrainedBox(constraints: BoxConstraints(maxWidth: maxWidth), child: child)),
    );
  }
}

/// Small eyebrow label used above section titles.
class Eyebrow extends StatelessWidget {
  final String text;
  const Eyebrow(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Text(text.toUpperCase(), style: AppText.muted.copyWith(color: AppColors.blue700, fontWeight: FontWeight.w700, letterSpacing: 0.6, fontSize: 11.5)),
    );
  }
}
