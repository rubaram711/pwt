import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'dashboard_shell.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late bool isCompany;
  int _seq = 3;
  late List<Address> _addresses;
  late List<PayCard> _cards;

  @override
  void initState() {
    super.initState();
    isCompany = AppState.I.isCompany;
    _addresses = isCompany
        ? [Address(id: 1, label: 'Registered Office', line1: '14 Riverside Way', city: 'London', postcode: 'EC1A 1BB', isDefault: true)]
        : [
            Address(id: 1, label: 'Home', line1: '12 Green Park Road', city: 'London', postcode: 'SW1A 2AA', isDefault: true),
            Address(id: 2, label: 'Office', line1: '8 Riverside Way', line2: 'Floor 3', city: 'Manchester', postcode: 'M3 4LX'),
          ];
    _cards = [
      PayCard(id: 1, brand: 'VISA', last4: '4242', exp: '08 / 27', isDefault: true),
      PayCard(id: 2, brand: 'MC', last4: '8810', exp: '02 / 26'),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final u = AppState.I.user;
    final wide = MediaQuery.of(context).size.width > 880;
    return DashboardShell(
      active: 'profile',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const DashHeader(title: 'Profile', subtitle: 'Manage your information, addresses and payment details'),
        Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: wide ? 1 : 0, child: Column(children: [
            DashCard(title: 'Personal Information', child: Column(children: [
              Row(children: [
                CircleAvatar(radius: 30, backgroundColor: AppColors.blue100, child: Text(u?.initials ?? 'SJ', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: AppColors.blue800))),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(isCompany ? (u?.company ?? 'Globex Facilities') : (u?.name ?? 'Sarah Johnson'), style: AppText.h3.copyWith(fontSize: 16)), const SizedBox(height: 2), Text('Member since Mar 2026', style: AppText.muted)])),
                PwtButton('Change photo', variant: PwtBtn.outline, onPressed: () {}),
              ]),
              const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Divider(height: 1, color: AppColors.line)),
              Row(children: [Expanded(child: _field('First name', isCompany ? 'Sarah' : (u?.name.split(' ').first ?? 'Sarah'))), const SizedBox(width: 12), Expanded(child: _field('Last name', 'Johnson'))]),
              const SizedBox(height: 12),
              Row(children: [Expanded(child: _field('Email', u?.email ?? 'sarah.johnson@email.com')), const SizedBox(width: 12), Expanded(child: _field('Phone', '+44 7123 456789'))]),
              const SizedBox(height: 16),
              Align(alignment: Alignment.centerLeft, child: PwtButton('Save Changes', onPressed: () => _toast('Changes saved'))),
            ])),
            const SizedBox(height: 16),
            DashCard(
              title: isCompany ? 'Address' : 'Addresses',
              action: isCompany ? null : PwtButton('Add new address', variant: PwtBtn.outline, icon: Icons.add, onPressed: () => _addressSheet()),
              child: Column(children: _addresses.map(_addressItem).toList()),
            ),
          ])),
          SizedBox(width: wide ? 18 : 0, height: wide ? 0 : 16),
          Expanded(flex: wide ? 1 : 0, child: DashCard(
            title: 'Payment Details',
            action: PwtButton('Add card', variant: PwtBtn.outline, icon: Icons.add, onPressed: () => _cardSheet()),
            child: Column(children: _cards.isEmpty
                ? [Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('No saved cards. Add one with "Add card".', style: AppText.muted))]
                : _cards.map(_cardItem).toList()),
          )),
        ]),
      ]),
    );
  }

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, backgroundColor: AppColors.ink900));

  Widget _field(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: AppText.label),
        const SizedBox(height: 7),
        TextField(controller: TextEditingController(text: value), decoration: const InputDecoration()),
      ]);

  Widget _addressItem(Address a) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.line)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.location_on_outlined, size: 20, color: AppColors.blue700),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Text(a.label, style: AppText.label), if (a.isDefault) ...[const SizedBox(width: 8), StatusBadge.green('Default')]]),
            const SizedBox(height: 3),
            Text(a.full, style: AppText.muted),
          ])),
          IconButton(icon: const Icon(Icons.edit_outlined, size: 18, color: AppColors.ink400), onPressed: () => _addressSheet(edit: a)),
          if (!isCompany) IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.danger), onPressed: () => setState(() {
                _addresses.remove(a);
                if (!_addresses.any((x) => x.isDefault) && _addresses.isNotEmpty) _addresses.first.isDefault = true;
              })),
        ]),
      );

  Widget _cardItem(PayCard c) {
    final grad = c.brand == 'VISA' ? const [Color(0xFF1A1F71), Color(0xFF2B3A8C)] : c.brand == 'MC' ? const [Color(0xFFEB5B2E), Color(0xFFCF4521)] : const [Color(0xFF334155), Color(0xFF1E293B)];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.line)),
      child: Row(children: [
        Container(width: 48, height: 32, alignment: Alignment.center, decoration: BoxDecoration(gradient: LinearGradient(colors: grad), borderRadius: BorderRadius.circular(6)), child: Text(c.brand, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${c.brand == 'VISA' ? 'Visa' : c.brand == 'MC' ? 'Mastercard' : 'Card'} •••• ${c.last4}', style: AppText.label),
          Text('Expires ${c.exp}${c.isDefault ? ' · Default' : ''}', style: AppText.muted),
        ])),
        if (c.isDefault) StatusBadge.green('Default') else TextButton(onPressed: () => setState(() {
              for (final x in _cards) x.isDefault = false;
              c.isDefault = true;
            }), child: const Text('Make default')),
        IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.danger), onPressed: () => setState(() => _cards.remove(c))),
      ]),
    );
  }

  void _addressSheet({Address? edit}) {
    final label = TextEditingController(text: edit?.label ?? '');
    final l1 = TextEditingController(text: edit?.line1 ?? '');
    final l2 = TextEditingController(text: edit?.line2 ?? '');
    final city = TextEditingController(text: edit?.city ?? '');
    final pc = TextEditingController(text: edit?.postcode ?? '');
    bool def = edit?.isDefault ?? false;
    _sheet(
      title: edit == null ? 'Add new address' : 'Edit address',
      fields: [
        _sheetField('Label', label, hint: 'e.g. Home, Office'),
        _sheetField('Address line 1', l1),
        _sheetField('Address line 2 (optional)', l2),
        Row(children: [Expanded(child: _sheetField('City', city)), const SizedBox(width: 12), Expanded(child: _sheetField('Postcode', pc))]),
        if (!isCompany) StatefulBuilder(builder: (c, set) => Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [Expanded(child: Text('Set as default address', style: AppText.label)), PwtToggle(value: def, onChanged: (v) => set(() => def = v))]))),
      ],
      saveLabel: edit == null ? 'Save address' : 'Save changes',
      onSave: () => setState(() {
        if (def) for (final a in _addresses) a.isDefault = false;
        if (edit != null) {
          edit..label = label.text.trim().isEmpty ? 'Address' : label.text.trim()..line1 = l1.text.trim()..line2 = l2.text.trim()..city = city.text.trim()..postcode = pc.text.trim()..isDefault = def;
        } else {
          _addresses.add(Address(id: _seq++, label: label.text.trim().isEmpty ? 'Address' : label.text.trim(), line1: l1.text.trim(), line2: l2.text.trim(), city: city.text.trim(), postcode: pc.text.trim(), isDefault: def));
        }
        if (!_addresses.any((a) => a.isDefault) && _addresses.isNotEmpty) _addresses.first.isDefault = true;
      }),
    );
  }

  void _cardSheet() {
    final num = TextEditingController();
    final exp = TextEditingController();
    bool def = false;
    _sheet(
      title: 'Add card',
      fields: [
        _sheetField('Card number', num, hint: '1234 1234 1234 1234'),
        Row(children: [Expanded(child: _sheetField('Expiry', exp, hint: 'MM / YY')), const SizedBox(width: 12), Expanded(child: _sheetField('CVC', TextEditingController(), hint: '123'))]),
        StatefulBuilder(builder: (c, set) => Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [Expanded(child: Text('Set as default card', style: AppText.label)), PwtToggle(value: def, onChanged: (v) => set(() => def = v))]))),
      ],
      saveLabel: 'Add card',
      onSave: () => setState(() {
        final digits = num.text.replaceAll(' ', '');
        final last4 = digits.length >= 4 ? digits.substring(digits.length - 4) : '0000';
        final brand = digits.startsWith('4') ? 'VISA' : digits.startsWith('5') ? 'MC' : 'CARD';
        if (def) for (final c in _cards) c.isDefault = false;
        _cards.add(PayCard(id: _seq++, brand: brand, last4: last4, exp: exp.text.trim().isEmpty ? '—' : exp.text.trim(), isDefault: def));
      }),
    );
  }

  void _sheet({required String title, required List<Widget> fields, required String saveLabel, required VoidCallback onSave}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [Expanded(child: Text(title, style: AppText.h2.copyWith(fontSize: 19))), IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx))]),
            const SizedBox(height: 12),
            ...fields.map((f) => Padding(padding: const EdgeInsets.only(bottom: 14), child: f)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: PwtButton('Cancel', variant: PwtBtn.outline, fullWidth: true, onPressed: () => Navigator.pop(ctx))),
              const SizedBox(width: 12),
              Expanded(child: PwtButton(saveLabel, fullWidth: true, onPressed: () { onSave(); Navigator.pop(ctx); })),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _sheetField(String label, TextEditingController c, {String? hint}) => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text(label, style: AppText.label),
        const SizedBox(height: 7),
        TextField(controller: c, decoration: InputDecoration(hintText: hint ?? label)),
      ]);
}
