import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

/// Brand side-panel shared by Login + Register.
class AuthShell extends StatelessWidget {
  final String headline;
  final String sub;
  final List<String> bullets;
  final Widget form;
  const AuthShell({super.key, required this.headline, required this.sub, required this.bullets, required this.form});

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 880;
    return Scaffold(
      backgroundColor: AppColors.soft,
      body: SafeArea(
        child: Row(children: [
          if (wide)
            Expanded(
              child: Container(
                color: AppColors.blue700,
                padding: const EdgeInsets.all(48),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                  Row(children: [
                    Image.asset('assets/images/pwt-logo.png', width: 30, height: 30, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop, color: Colors.white)),
                    const SizedBox(width: 10),
                    const Text('PWT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20, letterSpacing: 1.5)),
                  ]),
                  const SizedBox(height: 40),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(AppRadius.pill)), child: Row(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.water_drop, size: 14, color: Colors.white), SizedBox(width: 6), Text('Pure Water. Pure Life.', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))])),
                  const SizedBox(height: 20),
                  Text(headline, style: AppText.headline(34).copyWith(color: Colors.white)),
                  const SizedBox(height: 14),
                  Text(sub, style: AppText.bodyLg.copyWith(color: Colors.white.withOpacity(.9), height: 1.6)),
                  const SizedBox(height: 26),
                  ...bullets.map((b) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(children: [
                        Container(width: 24, height: 24, decoration: BoxDecoration(color: Colors.white.withOpacity(.18), shape: BoxShape.circle), child: const Icon(Icons.check, size: 15, color: Colors.white)),
                        const SizedBox(width: 12),
                        Expanded(child: Text(b, style: AppText.body.copyWith(color: Colors.white))),
                      ]))),
                ]),
              ),
            ),
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: form),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  int _acct = 0; // 0 individual, 1 company
  bool _obscure = true;
  final _email = TextEditingController(text: 'sarah.johnson@email.com');
  final _password = TextEditingController(text: 'password');

  Future<void> _signIn() async {
    final type = _acct == 1 ? 'company' : 'individual';
    await AppState.I.signIn(PwtUser.fromLogin(email: _email.text, accountType: type));
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil(type == 'company' ? '/companyDashboard' : '/dashboard', (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    return AuthShell(
      headline: 'Welcome back to cleaner water.',
      sub: 'Manage your orders, rentals, maintenance visits and filter reminders — all in one place.',
      bullets: const ['Track every order & delivery', 'Manage rentals & invoices', 'Book maintenance in seconds'],
      form: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextButton.icon(onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false), icon: const Icon(Icons.arrow_back, size: 16), label: const Text('Back to home'), style: TextButton.styleFrom(padding: EdgeInsets.zero)),
          const SizedBox(height: 12),
          Text('Sign in to your account', style: AppText.h2),
          const SizedBox(height: 6),
          Text('Enter your details below to access your PWT dashboard.', style: AppText.body.copyWith(color: AppColors.ink500)),
          const SizedBox(height: 20),
          Segmented(options: const ['Personal', 'Business'], icons: const [Icons.person_outline, Icons.apartment], index: _acct, onChanged: (i) => setState(() => _acct = i)),
          const SizedBox(height: 18),
          Text('Email address', style: AppText.label),
          const SizedBox(height: 7),
          TextField(controller: _email, decoration: const InputDecoration(hintText: 'you@email.com')),
          const SizedBox(height: 16),
          Row(children: [Text('Password', style: AppText.label), const Spacer(), Text('Forgot password?', style: AppText.muted.copyWith(color: AppColors.blue700))]),
          const SizedBox(height: 7),
          TextField(
            controller: _password,
            obscureText: _obscure,
            decoration: InputDecoration(
              hintText: 'Your password',
              suffixIcon: IconButton(icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 18), onPressed: () => setState(() => _obscure = !_obscure)),
            ),
          ),
          const SizedBox(height: 22),
          PwtButton('Sign In', fullWidth: true, onPressed: _signIn),
          const SizedBox(height: 18),
          Center(child: Wrap(children: [
            Text("Don't have an account? ", style: AppText.body.copyWith(color: AppColors.ink500)),
            GestureDetector(onTap: () => Navigator.of(context).pushNamed('/register'), child: Text('Create one', style: AppText.label.copyWith(color: AppColors.blue700))),
          ])),
        ]),
      ),
    );
  }
}
