import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../widgets/common.dart';
import 'dashboard_shell.dart';

class DevicesScreen extends StatelessWidget {
  const DevicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardShell(
      active: 'devices',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashHeader(
          title: 'My Devices',
          subtitle: 'Your water systems at a glance.',
          action: PwtButton('Shop new device', icon: Icons.add, onPressed: () => Navigator.of(context).pushNamed('/shop')),
        ),
        LayoutBuilder(builder: (context, c) {
          final cols = c.maxWidth > 720 ? 2 : 1;
          return GridView.builder(
              primary: false,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
            itemCount: kIndividualDevices.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, mainAxisSpacing: 18, crossAxisSpacing: 18, mainAxisExtent: 250),
            itemBuilder: (_, i) => _DeviceCard(kIndividualDevices[i]),
          );
        }),
      ]),
    );
  }
}

class _DeviceCard extends StatelessWidget {
  final Device d;
  const _DeviceCard(this.d);

  String get _image {
    switch (d.name) {
      case 'PW50-R':
        return 'assets/images/pw90.png';
      case 'PW-RO5':
        return 'assets/images/ct.png';
      case 'S4 Sparkling':
        return 'assets/images/s4.png';
      default:
        return 'assets/images/pw0ctr.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    final badge = d.ordered ? StatusBadge.amber('Ordered') : d.rented ? StatusBadge.blue('Rented') : StatusBadge.green('Purchased');
    return DashCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 56, height: 56, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.all(8), child: Image.asset(_image, fit: BoxFit.contain)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d.name, style: AppText.h3), const SizedBox(height: 2), Text(d.type, style: AppText.muted)])),
          badge,
        ]),
        // const Spacer(),
        if (d.ordered)
          _banner(Icons.local_shipping_outlined, 'Order confirmed — arriving 12 Jun 2026', AppColors.green700, AppColors.badgeGreenBg)
        else if (d.maintenanceOn != null)
          _banner(Icons.calendar_today_outlined, 'Maintenance scheduled · ${d.maintenanceOn}', AppColors.blue700, AppColors.badgeBlueBg)
        else if (d.rented) ...[
          _row('Rental plan', d.tenure),
          _row('Next payment', d.nextDue ?? '—', accent: true),
        ] else ...[
          _row('Tenure', d.tenure),
          _row('Warranty', '2 years'),
        ],
        const SizedBox(height: 14),
        PwtButton(
          d.ordered ? 'Order details' : d.maintenanceOn != null ? 'Reschedule' : 'Request maintenance',
          variant: PwtBtn.outline,
          fullWidth: true,
          onPressed: () => Navigator.of(context).pushReplacementNamed(d.ordered ? '/orders' : '/maintenance'),
        ),
      ]),
    );
  }

  Widget _row(String k, String v, {bool accent = false}) => Padding(
        padding: const EdgeInsets.only(top: 9),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: AppText.muted),
          Text(v, style: AppText.label.copyWith(fontWeight: FontWeight.w700, color: accent ? AppColors.blue700 : AppColors.ink900)),
        ]),
      );

  Widget _banner(IconData ic, String t, Color fg, Color bg) => Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
        child: Row(children: [Icon(ic, size: 16, color: fg), const SizedBox(width: 8), Expanded(child: Text(t, style: AppText.muted.copyWith(color: fg, fontWeight: FontWeight.w600)))]),
      );
}
