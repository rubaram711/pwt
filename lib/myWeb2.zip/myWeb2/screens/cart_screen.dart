import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StoreScaffold(active: '/cart', slivers: [
      SliverToBoxAdapter(
        child: Band(child: AnimatedBuilder(
          animation: AppState.I,
          builder: (context, _) {
            final s = AppState.I;
            final wide = MediaQuery.of(context).size.width > 880;
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Your Cart', style: AppText.headline(wide ? 32 : 26)),
              const SizedBox(height: 6),
              Text('Review your items and proceed to checkout.', style: AppText.bodyLg),
              const SizedBox(height: 24),
              if (s.cart.isEmpty)
                _empty(context)
              else
                Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(flex: wide ? 3 : 0, child: Column(children: [
                    ...s.cart.map((l) => _line(context, s, l)),
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => Navigator.of(context).pushNamed('/shop'), icon: const Icon(Icons.arrow_back, size: 16), label: const Text('Continue shopping'))),
                  ])),
                  SizedBox(width: wide ? 22 : 0, height: wide ? 0 : 22),
                  Expanded(flex: wide ? 2 : 0, child: _summary(context, s)),
                ]),
            ]);
          },
        )),
      ),
    ]);
  }

  Widget _line(BuildContext context, AppState s, CartLine l) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 84, height: 84, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.all(8), child: Image.asset(l.product.image, fit: BoxFit.contain)),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(l.product.name, style: AppText.h3),
          const SizedBox(height: 2),
          Text(l.product.sub, style: AppText.muted),
          const SizedBox(height: 8),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: l.mode == 'rent' ? AppColors.badgeBlueBg : AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.pill)), child: Text(l.mode == 'rent' ? 'Rent (${l.rentTerm ?? 36} Months)' : 'One-time Purchase', style: AppText.muted.copyWith(fontWeight: FontWeight.w700, color: l.mode == 'rent' ? AppColors.blue700 : AppColors.ink600))),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(l.mode == 'rent' ? '${money(l.lineTotal)}/mo' : money(l.lineTotal), style: AppText.price),
          const SizedBox(height: 10),
          Row(children: [
            _qtyBtn(Icons.remove, () => s.decQty(l)),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('${l.qty}', style: AppText.label)),
            _qtyBtn(Icons.add, () => s.incQty(l)),
          ]),
          const SizedBox(height: 8),
          TextButton.icon(onPressed: () => s.removeLine(l), icon: const Icon(Icons.delete_outline, size: 15, color: AppColors.danger), label: Text('Remove', style: AppText.muted.copyWith(color: AppColors.danger)), style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 0), tapTargetSize: MaterialTapTargetSize.shrinkWrap)),
        ]),
      ]),
    );
  }

  Widget _qtyBtn(IconData ic, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(width: 30, height: 30, decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(8)), child: Icon(ic, size: 15, color: AppColors.ink700)),
      );

  Widget _summary(BuildContext context, AppState s) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Order Summary', style: AppText.h2.copyWith(fontSize: 19)),
        const SizedBox(height: 16),
        _row('Subtotal', money(s.subtotal)),
        _row('Delivery', 'Free', muted: true),
        _row('Installation', 'Free', muted: true),
        _row('VAT (20%)', money(s.vat)),
        const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(height: 1, color: AppColors.line)),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Total', style: AppText.h3),
          Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [Text(money(s.total), style: AppText.h2.copyWith(fontSize: 22)), const SizedBox(width: 6), Text('incl. VAT', style: AppText.muted)]),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: TextField(decoration: const InputDecoration(hintText: 'Promo code'))),
          const SizedBox(width: 8),
          PwtButton('Apply', variant: PwtBtn.outline, onPressed: () {}),
        ]),
        const SizedBox(height: 16),
        PwtButton('Proceed to Checkout', icon: Icons.arrow_forward, fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/checkout', arguments: 'buy')),
        const SizedBox(height: 16),
        ..._assure('Secure SSL encrypted checkout', Icons.lock_outline),
        ..._assure('14-day easy returns', Icons.swap_horiz),
        ..._assure('2 years full warranty', Icons.shield_outlined),
      ]),
    );
  }

  List<Widget> _assure(String t, IconData ic) => [
        Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Icon(ic, size: 15, color: AppColors.ink400), const SizedBox(width: 9), Text(t, style: AppText.muted)])),
      ];

  Widget _row(String k, String v, {bool muted = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: AppText.body.copyWith(color: muted ? AppColors.ink400 : AppColors.ink700)),
          Text(v, style: AppText.label.copyWith(color: muted ? AppColors.green600 : AppColors.ink900)),
        ]),
      );

  Widget _empty(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Column(children: [
          Container(width: 80, height: 80, decoration: BoxDecoration(color: AppColors.soft, shape: BoxShape.circle), child: const Icon(Icons.shopping_cart_outlined, size: 36, color: AppColors.ink400)),
          const SizedBox(height: 18),
          Text('Your cart is empty', style: AppText.h2.copyWith(fontSize: 20)),
          const SizedBox(height: 6),
          Text("Looks like you haven't added anything yet.", style: AppText.body.copyWith(color: AppColors.ink500)),
          const SizedBox(height: 18),
          PwtButton('Browse Products', onPressed: () => Navigator.of(context).pushNamed('/shop')),
        ]),
      ),
    );
  }
}
