import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../widgets/site_chrome.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StoreScaffold(
      active: '/',
      slivers: [
        SliverToBoxAdapter(child: _Hero()),
        SliverToBoxAdapter(child: _StatsBar()),
        SliverToBoxAdapter(child: _Solutions()),
        SliverToBoxAdapter(child: _TopProducts()),
        SliverToBoxAdapter(child: _Process()),
        SliverToBoxAdapter(child: _Benefits()),
        SliverToBoxAdapter(child: _CtaBanner()),
      ],
    );
  }
}

class _Hero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 900;
    return Stack(children: [
      Positioned.fill(
        child: Image.asset('assets/images/lake-mountain.jpeg', fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: AppColors.blue50)),
      ),
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [Colors.white.withOpacity(.96), Colors.white.withOpacity(wide ? .55 : .9)],
            ),
          ),
        ),
      ),
      Band(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 56),
        child: Flex(
          direction: wide ? Axis.horizontal : Axis.vertical,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              flex: wide ? 1 : 0,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                const Eyebrow('Pure Water. Pure Life.'),
                const SizedBox(height: 18),
                Text('Water that actually tastes like water.',
                    style: AppText.headline(wide ? 52 : 38)),
                const SizedBox(height: 18),
                Text('Advanced water purification solutions for a healthier, better everyday. From home to enterprise, we deliver purity you can taste.',
                    style: AppText.bodyLg.copyWith(height: 1.6), softWrap: true),
                const SizedBox(height: 26),
                Wrap(spacing: 12, runSpacing: 12, children: [
                  PwtButton('Explore Solutions', onPressed: () => Navigator.of(context).pushNamed('/solutions')),
                  PwtButton('Watch Video', variant: PwtBtn.outline, icon: Icons.play_arrow_rounded, onPressed: () {}),
                ]),
                const SizedBox(height: 30),
                Wrap(spacing: 22, runSpacing: 16, children: const [
                  _FeaturePill(Icons.water_drop, 'High Quality\nFiltration', AppColors.blue600),
                  _FeaturePill(Icons.settings, 'Easy\nMaintenance', AppColors.ink400),
                  _FeaturePill(Icons.eco, 'Eco\nFriendly', AppColors.green600),
                  _FeaturePill(Icons.groups, 'Trusted by\nThousands', AppColors.purple),
                ]),
              ]),
            ),
            if (wide) const SizedBox(width: 30),
            Expanded(
              flex: wide ? 1 : 0,
              child: Padding(
                padding: EdgeInsets.only(top: wide ? 0 : 30),
                child: Image.asset('assets/images/podium-hero.png', fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const SizedBox(height: 320)),
              ),
            ),
          ],
        ),
      ),
    ]);
  }
}

class _FeaturePill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _FeaturePill(this.icon, this.label, this.color);
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: color, size: 20),
      ),
      const SizedBox(width: 10),
      Text(label, style: AppText.label.copyWith(height: 1.25)),
    ]);
  }
}

class _StatsBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final stats = [
      ['10K+', 'Happy Customers'],
      ['15+', 'Years of Experience'],
      ['30+', 'Countries Served'],
      ['99%', 'Satisfaction Rate'],
    ];
    return Band(
      padding: const EdgeInsets.fromLTRB(28, 0, 28, 10),
      child: Transform.translate(
        offset: const Offset(0, -28),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 18),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadow.lg, border: Border.all(color: AppColors.line)),
          child: Wrap(
            alignment: WrapAlignment.spaceEvenly,
            runSpacing: 18,
            children: stats
                .map((s) => SizedBox(
                      width: 160,
                      child: Column(children: [
                        Text(s[0], style: AppText.pageTitle.copyWith(color: AppColors.blue700, fontSize: 30)),
                        const SizedBox(height: 4),
                        Text(s[1], style: AppText.muted),
                      ]),
                    ))
                .toList(),
          ),
        ),
      ),
    );
  }
}

class _Solutions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 820;
    return Band(
      child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
        const Eyebrow('Solutions for Everyone'),
        const SizedBox(height: 14),
        Text('Choose What Suits You Best', style: AppText.pageTitle.copyWith(fontSize: wide ? 30 : 24), textAlign: TextAlign.center),
        const SizedBox(height: 34),
        Flex(
          direction: wide ? Axis.horizontal : Axis.vertical,
          children: [
            Expanded(flex: wide ? 1 : 0, child: _SolCard(
              icon: Icons.person_outline,
              title: 'For Individuals',
              intro: 'Buy or rent premium water purification systems for your home.',
              points: const ['Instant purchase or flexible rental options', 'Bulk orders', 'Fast delivery & installation'],
              image: 'assets/images/sol-individuals.png',
              ctaLabel: 'Shop Now',
              onTap: () => Navigator.of(context).pushNamed('/shop'),
              solid: true,
            )),
            SizedBox(width: wide ? 24 : 0, height: wide ? 0 : 24),
            Expanded(flex: wide ? 1 : 0, child: _SolCard(
              icon: Icons.apartment,
              title: 'For Companies',
              intro: 'Get a customised quotation tailored to your business needs.',
              points: const ['Personalised pricing', 'Bulk orders', 'Dedicated account manager', 'Dedicated support'],
              image: 'assets/images/sol-companies.png',
              ctaLabel: 'Request a Quotation',
              onTap: () => Navigator.of(context).pushNamed('/rfq'),
              solid: false,
            )),
          ],
        ),
      ]),
    );
  }
}

class _SolCard extends StatelessWidget {
  final IconData icon;
  final String title, intro, image, ctaLabel;
  final List<String> points;
  final VoidCallback onTap;
  final bool solid;
  const _SolCard({required this.icon, required this.title, required this.intro, required this.points, required this.image, required this.ctaLabel, required this.onTap, required this.solid});
  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.all(26),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: AppColors.blue700)),
              const SizedBox(width: 14),
              Text(title, style: AppText.h2.copyWith(fontSize: 20)),
            ]),
            const SizedBox(height: 14),
            Text(intro, style: AppText.bodyLg),
            const SizedBox(height: 16),
            ...points.map((p) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Icon(Icons.check, size: 18, color: AppColors.blue600),
                    const SizedBox(width: 10),
                    Expanded(child: Text(p, style: AppText.body)),
                  ]),
                )),
            const SizedBox(height: 8),
            PwtButton(ctaLabel, variant: solid ? PwtBtn.primary : PwtBtn.outline, onPressed: onTap),
          ]),
        ),
        Image.asset(image, height: 180, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 180, color: AppColors.soft)),
      ]),
    );
  }
}

class _TopProducts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 820;
    final items = kProducts.take(4).toList();
    return Band(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Eyebrow('Best Sellers'),
            const SizedBox(height: 10),
            Text('Our Top Products', style: AppText.pageTitle.copyWith(fontSize: wide ? 28 : 23)),
          ]),
          const Spacer(),
          TextButton(
            onPressed: () => Navigator.of(context).pushNamed('/shop'),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text('View All Products', style: AppText.label.copyWith(color: AppColors.blue700)),
              const Icon(Icons.arrow_forward, size: 16, color: AppColors.blue700),
            ]),
          ),
        ]),
        const SizedBox(height: 22),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: wide ? 4 : 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: 0.82,
          children: items
              .map((p) => InkWell(
                    onTap: () => Navigator.of(context).pushNamed('/product', arguments: p),
                    child: Container(
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(child: Padding(padding: const EdgeInsets.all(16), child: Center(child: Image.asset(p.image, fit: BoxFit.contain)))),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(p.name, style: AppText.h3),
                            const SizedBox(height: 2),
                            Text(p.sub, style: AppText.muted, maxLines: 1, overflow: TextOverflow.ellipsis),
                          ]),
                        ),
                      ]),
                    ),
                  ))
              .toList(),
        ),
      ]),
    );
  }
}

class _Process extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final steps = [
      ['1', 'Source', 'Carefully selected water sources, monitored for optimal quality and mineral content.', Icons.water_drop],
      ['2', 'Multi-Stage Filtration', 'Advanced filtration removes impurities through 5 purification stages.', Icons.filter_alt],
      ['3', 'Purified Perfection', 'Clean, safe and great-tasting water delivered to your home or business.', Icons.bolt],
      ['4', 'Delivered to You', 'Enjoy pure water with regular maintenance and filter replacements included.', Icons.home],
    ];
    final wide = MediaQuery.of(context).size.width > 820;
    return Band(
      color: AppColors.soft,
      child: Column(children: [
        const Eyebrow('Our Process'),
        const SizedBox(height: 14),
        Text('How Our Solution Works', style: AppText.pageTitle.copyWith(fontSize: wide ? 30 : 24), textAlign: TextAlign.center),
        const SizedBox(height: 30),
        Wrap(
          spacing: 16,
          runSpacing: 16,
          alignment: WrapAlignment.center,
          children: steps
              .map((s) => SizedBox(
                    width: wide ? 250 : double.infinity,
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line)),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(12)), child: Icon(s[3] as IconData, color: AppColors.blue700)),
                        const SizedBox(height: 14),
                        Text('Step ${s[0]}', style: AppText.muted.copyWith(color: AppColors.blue700, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(s[1] as String, style: AppText.h3),
                        const SizedBox(height: 8),
                        Text(s[2] as String, style: AppText.body.copyWith(height: 1.5)),
                      ]),
                    ),
                  ))
              .toList(),
        ),
      ]),
    );
  }
}

class _Benefits extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 820;
    final bens = [
      [Icons.water_drop, 'Better Taste', 'Remove chlorine and impurities that affect flavour and smell.'],
      [Icons.favorite_border, 'Better Health', 'Reduce exposure to harmful substances and volatile chemicals.'],
      [Icons.savings_outlined, 'Cost Effective', 'Economical systems that cut plastic waste and bottled water costs.'],
      [Icons.eco, 'Better Planet', 'Eco-friendly filters that support a sustainable future.'],
      [Icons.settings, 'Easy Maintenance', 'Simple filter changes and professional maintenance.'],
      [Icons.verified_outlined, 'Reliable Quality', 'Tested and certified systems, consistent every time.'],
    ];
    return Band(
      child: Container(
        padding: const EdgeInsets.all(34),
        decoration: BoxDecoration(color: AppColors.ink900, borderRadius: BorderRadius.circular(AppRadius.xl)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: Colors.white.withOpacity(.1), borderRadius: BorderRadius.circular(AppRadius.pill)),
            child: const Text('WHY PWT', style: TextStyle(color: Color(0xFF9CC1ED), fontWeight: FontWeight.w700, fontSize: 11.5, letterSpacing: .6)),
          ),
          const SizedBox(height: 14),
          Text('The Benefits You Can Feel', style: AppText.pageTitle.copyWith(color: Colors.white, fontSize: wide ? 28 : 23)),
          const SizedBox(height: 26),
          Wrap(
            spacing: 20,
            runSpacing: 22,
            children: bens
                .map((b) => SizedBox(
                      width: wide ? 320 : double.infinity,
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(width: 42, height: 42, decoration: BoxDecoration(color: AppColors.blue700.withOpacity(.25), borderRadius: BorderRadius.circular(11)), child: Icon(b[0] as IconData, color: const Color(0xFF9CC1ED), size: 20)),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(b[1] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                          const SizedBox(height: 4),
                          Text(b[2] as String, style: AppText.body.copyWith(color: const Color(0xFF9AA6BF), height: 1.5)),
                        ])),
                      ]),
                    ))
                .toList(),
          ),
        ]),
      ),
    );
  }
}

class _CtaBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 720;
    return Band(
      child: Container(
        clipBehavior: Clip.antiAlias,
        padding: const EdgeInsets.all(34),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppColors.blue700, AppColors.blue600]),
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        child: Flex(
          direction: wide ? Axis.horizontal : Axis.vertical,
          crossAxisAlignment: wide ? CrossAxisAlignment.center : CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: wide ? 1 : 0,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('Ready for pure water?', style: AppText.pageTitle.copyWith(color: Colors.white, fontSize: 24)),
                const SizedBox(height: 8),
                Text('Join thousands of happy customers across the UK. Get started today.', style: AppText.bodyLg.copyWith(color: Colors.white.withOpacity(.9))),
              ]),
            ),
            SizedBox(width: wide ? 20 : 0, height: wide ? 0 : 18),
            Wrap(spacing: 12, runSpacing: 12, children: [
              PwtButton('Shop Now', variant: PwtBtn.outline, onPressed: () => Navigator.of(context).pushNamed('/shop')),
              TextButton(onPressed: () => Navigator.of(context).pushNamed('/contact'), child: const Text('Contact Us', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
            ]),
          ],
        ),
      ),
    );
  }
}
