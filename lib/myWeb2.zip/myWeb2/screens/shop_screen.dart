import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

/// Shop — full-width responsive product grid (matches the approved Shop.html).
class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final trust = [
      [Icons.local_shipping_outlined, 'Fast Delivery', 'Quick delivery across the UK'],
      [Icons.shield_outlined, '2 Years Warranty', 'Full coverage on all products'],
      [Icons.support_agent, 'Expert Support', 'We are here to help you'],
      [Icons.swap_horiz, 'Easy Returns', '14 days return policy'],
    ];
    return StoreScaffold(active: '/shop', slivers: [
      SliverToBoxAdapter(
        child: Band(
          padding: const EdgeInsets.fromLTRB(32, 28, 32, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              InkWell(onTap: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false), child: Text('Home', style: AppText.muted.copyWith(color: AppColors.blue700))),
              Text('  ›  Shop', style: AppText.muted),
            ]),
            const SizedBox(height: 16),
            Text('All Products', style: AppText.headline(34)),
            const SizedBox(height: 6),
            Text('Showing 1–12 of 34 products', style: AppText.muted),
          ]),
        ),
      ),
      SliverToBoxAdapter(
        child: Band(child: LayoutBuilder(builder: (context, c) {
          final cols = c.maxWidth > 1000 ? 4 : c.maxWidth > 680 ? 3 : 2;
          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: kProducts.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, mainAxisSpacing: 18, crossAxisSpacing: 18, childAspectRatio: 0.72),
            itemBuilder: (_, i) => _ProductCard(kProducts[i]),
          );
        })),
      ),
      SliverToBoxAdapter(
        child: Band(color: AppColors.soft, child: Wrap(spacing: 18, runSpacing: 18, alignment: WrapAlignment.spaceBetween, children: trust.map((t) => SizedBox(
              width: 250,
              child: Row(children: [
                Container(width: 44, height: 44, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.line)), child: Icon(t[0] as IconData, color: AppColors.blue700, size: 22)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t[1] as String, style: AppText.label),
                  const SizedBox(height: 2),
                  Text(t[2] as String, style: AppText.muted, maxLines: 1, overflow: TextOverflow.ellipsis),
                ])),
              ]),
            )).toList())),
      ),
    ]);
  }
}

class _ProductCard extends StatelessWidget {
  final Product p;
  const _ProductCard(this.p);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).pushNamed('/product', arguments: p),
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(children: [
              Padding(padding: const EdgeInsets.all(16), child: Center(child: Image.asset(p.image, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined, size: 52, color: AppColors.blue200)))),
              if (p.tag == 'seller') Positioned(top: 10, left: 10, child: _ribbon('Best Seller', AppColors.blue700)),
              if (p.tag == 'new') Positioned(top: 10, left: 10, child: _ribbon('New', AppColors.orange)),
              if (p.discounted) Positioned(top: 10, right: 10, child: _ribbon('${p.discountPct}% OFF', AppColors.discount)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, style: AppText.h3),
              const SizedBox(height: 2),
              Text(p.sub, style: AppText.muted, maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 10),
              Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
                Text(money(p.price), style: AppText.price.copyWith(color: p.discounted ? AppColors.discount : AppColors.ink900)),
                if (p.discounted) ...[const SizedBox(width: 8), Text(money(p.oldPrice!), style: AppText.muted.copyWith(decoration: TextDecoration.lineThrough))],
              ]),
              const SizedBox(height: 12),
              PwtButton('View details', variant: PwtBtn.ghost, fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/product', arguments: p)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _ribbon(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
        decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(AppRadius.pill)),
        child: Text(t, style: AppText.muted.copyWith(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 10.5)),
      );
}
