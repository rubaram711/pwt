import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/site_chrome.dart';

class NavEntry {
  final String id, label, route;
  final IconData icon;
  const NavEntry(this.id, this.label, this.route, this.icon);
}

/// Dashboard layout: shared storefront header + left sidebar + scrollable content.
/// The sidebar swaps items for individual vs company accounts (read from AppState).
class DashboardShell extends StatelessWidget {
  final String active; // 'devices' | 'orders' | 'maintenance' | 'invoices' | 'settings' | 'profile'
  final Widget child;
  const DashboardShell({super.key, required this.active, required this.child});

  List<NavEntry> _items(bool isCompany) => isCompany
      ? const [
          NavEntry('devices', 'Devices', '/companyDashboard', Icons.grid_view_rounded),
          NavEntry('orders', 'Orders', '/companyOrders', Icons.inventory_2_outlined),
          NavEntry('maintenance', 'Maintenance', '/companyMaintenance', Icons.build_outlined),
          NavEntry('invoices', 'Invoices History', '/invoices', Icons.description_outlined),
          NavEntry('settings', 'Settings', '/settings', Icons.settings_outlined),
          NavEntry('profile', 'Profile', '/profile', Icons.person_outline),
        ]
      // Individual sidebar matches dash-shell.js: only these four. Orders &
      // Maintenance are reached from the device cards, not the sidebar.
      : const [
          NavEntry('devices', 'Devices', '/dashboard', Icons.grid_view_rounded),
          NavEntry('invoices', 'Invoices History', '/invoices', Icons.description_outlined),
          NavEntry('settings', 'Settings', '/settings', Icons.settings_outlined),
          NavEntry('profile', 'Profile', '/profile', Icons.person_outline),
        ];

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final items = _items(AppState.I.isCompany);
        final wide = MediaQuery.of(context).size.width > 900;
        return Scaffold(
          backgroundColor: AppColors.dashBg,
          appBar: SiteHeader(active: '/dashboard-hidden', showLeadingMenu: !wide),
          drawer: wide ? null : Drawer(child: SafeArea(child: _sidebar(context, items))),
          body: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (wide) SizedBox(width: 260, child: Container(color: Colors.white, child: _sidebar(context, items))),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(32, 28, 32, 60),
                child: Center(
                  child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1280), child: child),
                ),
              ),
            ),
          ]),
        );
      },
    );
  }

  Widget _sidebar(BuildContext outerContext, List<NavEntry> items) {
    return Builder(builder: (context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 16),
      ...items.map((n) {
        final on = n.id == active;
        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 3, 14, 3),
          child: Material(
            color: on ? AppColors.blue700 : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            child: InkWell(
              borderRadius: BorderRadius.circular(11),
              onTap: () {
                final scaffold = Scaffold.maybeOf(context);
                if (scaffold?.isDrawerOpen ?? false) scaffold!.closeDrawer();
                if (!on) Navigator.of(context).pushReplacementNamed(n.route);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                child: Row(children: [
                  Icon(n.icon, size: 20, color: on ? Colors.white : AppColors.ink400),
                  const SizedBox(width: 14),
                  Text(n.label, style: AppText.body.copyWith(color: on ? Colors.white : AppColors.ink700, fontWeight: on ? FontWeight.w600 : FontWeight.w500)),
                ]),
              ),
            ),
          ),
        );
      }),
      const SizedBox(height: 24),
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
        child: InkWell(
          borderRadius: BorderRadius.circular(11),
          onTap: () async {
            await AppState.I.signOut();
            if (context.mounted) Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false);
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            child: Row(children: [
              const Icon(Icons.logout, size: 20, color: AppColors.ink400),
              const SizedBox(width: 14),
              Text('Log Out', style: AppText.body.copyWith(color: AppColors.ink600)),
            ]),
          ),
        ),
      ),
    ]));
  }
}

/// Page header row used at the top of each dashboard page.
class DashHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? action;
  final List<String>? crumbs;
  const DashHeader({super.key, required this.title, this.subtitle, this.action, this.crumbs});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (crumbs != null) ...[
        Row(children: [
          Text(crumbs!.first, style: AppText.muted.copyWith(color: AppColors.blue700)),
          ...crumbs!.skip(1).map((c) => Text('  ›  $c', style: AppText.muted)),
        ]),
        const SizedBox(height: 12),
      ],
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: AppText.pageTitle),
          if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle!, style: AppText.muted)],
        ])),
        if (action != null) action!,
      ]),
      const SizedBox(height: 22),
    ]);
  }
}

/// White rounded dashboard card with optional header row.
class DashCard extends StatelessWidget {
  final String? title;
  final Widget? action;
  final Widget child;
  final EdgeInsets padding;
  const DashCard({super.key, this.title, this.action, required this.child, this.padding = const EdgeInsets.all(22)});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (title != null) ...[
          Row(children: [Expanded(child: Text(title!, style: AppText.h3)), if (action != null) action!]),
          const SizedBox(height: 16),
        ],
        child,
      ]),
    );
  }
}
