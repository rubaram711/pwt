import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'dashboard_shell.dart';

String _fmtDate(String iso, {bool weekday = false}) {
  if (iso.isEmpty) return 'To be confirmed';
  try {
    final d = DateTime.parse(iso);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final base = '${d.day.toString().padLeft(2, '0')} ${months[d.month - 1]} ${d.year}';
    return weekday ? '${days[d.weekday - 1]}, $base' : base;
  } catch (_) {
    return iso;
  }
}

class CompanyMaintenanceScreen extends StatelessWidget {
  const CompanyMaintenanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardShell(
      active: 'maintenance',
      child: AnimatedBuilder(
        animation: AppState.I,
        builder: (context, _) {
          final visits = AppState.I.maintenance;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            DashHeader(
              title: 'Maintenance',
              subtitle: 'Schedule and track service visits for your fleet',
              action: visits.isEmpty ? null : PwtButton('Schedule Maintenance', icon: Icons.add, onPressed: () => Navigator.of(context).pushNamed('/scheduleMaintenance')),
            ),
            if (visits.isEmpty)
              DashCard(child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 30),
                child: Center(child: Column(children: [
                  Container(width: 70, height: 70, decoration: BoxDecoration(color: AppColors.soft, shape: BoxShape.circle), child: const Icon(Icons.build_outlined, size: 32, color: AppColors.ink400)),
                  const SizedBox(height: 16),
                  Text('No maintenance scheduled', style: AppText.h2.copyWith(fontSize: 19)),
                  const SizedBox(height: 6),
                  ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Text("Keep your fleet running smoothly. Book a service visit for one or more of your devices and we'll handle the rest.", style: AppText.body.copyWith(color: AppColors.ink500), textAlign: TextAlign.center)),
                  const SizedBox(height: 18),
                  PwtButton('Schedule Maintenance', icon: Icons.add, onPressed: () => Navigator.of(context).pushNamed('/scheduleMaintenance')),
                ])),
              ))
            else ...[
              Text('Scheduled Maintenance', style: AppText.h3),
              const SizedBox(height: 12),
              ...List.generate(visits.length, (i) => _visitCard(context, visits[i], i)),
            ],
          ]);
        },
      ),
    );
  }

  Widget _visitCard(BuildContext context, MaintVisit v, int i) {
    final cancelled = v.status == 'Cancellation requested';
    return InkWell(
      onTap: () => Navigator.of(context).pushNamed('/maintenanceDetails', arguments: i),
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.build_outlined, color: AppColors.blue700)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Service visit — ${v.devices.length} device${v.devices.length > 1 ? 's' : ''}', style: AppText.h3.copyWith(fontSize: 15)),
              const SizedBox(height: 2),
              Text('${_fmtDate(v.date)} · ${v.slot}', style: AppText.muted),
            ])),
            cancelled ? StatusBadge.amber('Cancellation requested') : StatusBadge.blue('Scheduled'),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right, color: AppColors.ink400),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: v.devices.map((d) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5), decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.pill), border: Border.all(color: AppColors.line)), child: Text(d, style: AppText.muted.copyWith(fontWeight: FontWeight.w600)))).toList()),
        ]),
      ),
    );
  }
}

class ScheduleMaintenanceScreen extends StatefulWidget {
  const ScheduleMaintenanceScreen({super.key});
  @override
  State<ScheduleMaintenanceScreen> createState() => _ScheduleMaintenanceScreenState();
}

class _ScheduleMaintenanceScreenState extends State<ScheduleMaintenanceScreen> {
  final _fleet = const [
    ['d1', 'PW50-R × 18', 'Hot & Cold Dispenser', 'pw90.png', '2026-02-02'],
    ['d2', 'PW90-R CT × 40', 'Countertop RO', 'ct.png', '2026-05-20'],
    ['d3', 'S4 Sparkling × 24', 'Sparkling Dispenser', 's4.png', '2026-03-18'],
    ['d4', 'PW30-C × 28', 'Countertop Dispenser', 'pw0ctr.png', '2026-01-14'],
    ['d5', 'PW-RO5 × 10', 'RO System', 'ct.png', '2025-11-09'],
    ['d6', 'PW90-R × 22', 'Floor Unit', 'pw50.png', '2025-12-03'],
    ['d7', 'S18 UC × 12', 'Undercounter', 's4.png', '2026-04-27'],
    ['d8', 'PW50-R × 16', 'Hot & Cold Dispenser', 'pw90.png', '2025-09-21'],
  ];
  final Set<String> _selected = {};
  String _query = '';
  String _sort = 'type';
  DateTime? _date;
  int _slot = 0;
  final _slots = const ['Morning (8AM – 12PM)', 'Afternoon (12PM – 4PM)', 'Evening (4PM – 7PM)'];
  final _notes = TextEditingController();

  List<List<String>> get _filtered {
    var rows = _fleet.where((d) => d[1].toLowerCase().contains(_query.toLowerCase())).map((e) => e.cast<String>()).toList();
    rows.sort((a, b) {
      if (_sort == 'purchased') return DateTime.parse(b[4]).compareTo(DateTime.parse(a[4]));
      if (_sort == 'name') return a[1].compareTo(b[1]);
      return a[2].compareTo(b[2]);
    });
    return rows;
  }

  void _schedule() {
    final picked = _fleet.where((d) => _selected.contains(d[0])).map((d) => d[1] as String).toList();
    if (picked.isEmpty) return;
    AppState.I.addMaintenance(MaintVisit(devices: picked, date: _date?.toIso8601String().split('T').first ?? '', slot: _slots[_slot], notes: _notes.text.trim(), status: 'Scheduled'));
    Navigator.of(context).pushReplacementNamed('/companyMaintenance');
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 880;
    return DashboardShell(
      active: 'maintenance',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashHeader(
          title: 'Schedule Maintenance',
          subtitle: 'Select the devices that need a service visit',
          crumbs: const ['Maintenance', 'Schedule'],
          action: PwtButton('Back', variant: PwtBtn.outline, icon: Icons.arrow_back, onPressed: () => Navigator.of(context).pushReplacementNamed('/companyMaintenance')),
        ),
        Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: wide ? 3 : 0, child: DashCard(child: Column(children: [
            Row(children: [
              Expanded(child: TextField(decoration: const InputDecoration(hintText: 'Search devices by name', prefixIcon: Icon(Icons.search, size: 18)), onChanged: (v) => setState(() => _query = v))),
              const SizedBox(width: 12),
              DropdownButton<String>(value: _sort, underline: const SizedBox(), items: const [
                DropdownMenuItem(value: 'type', child: Text('Device type')),
                DropdownMenuItem(value: 'purchased', child: Text('Date purchased')),
                DropdownMenuItem(value: 'name', child: Text('Name (A–Z)')),
              ], onChanged: (v) => setState(() => _sort = v!)),
            ]),
            const SizedBox(height: 14),
            ..._filtered.map((d) {
              final on = _selected.contains(d[0]);
              return GestureDetector(
                onTap: () => setState(() => on ? _selected.remove(d[0]) : _selected.add(d[0])),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: on ? AppColors.blue50 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 1.5 : 1)),
                  child: Row(children: [
                    Icon(on ? Icons.check_box : Icons.check_box_outline_blank, color: on ? AppColors.blue700 : AppColors.ink300, size: 22),
                    const SizedBox(width: 10),
                    Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(8)), padding: const EdgeInsets.all(5), child: Image.asset('assets/images/${d[3]}', fit: BoxFit.contain)),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d[1], style: AppText.label), Text(d[2], style: AppText.muted)])),
                    Text('Purchased ${_fmtDate(d[4])}', style: AppText.muted),
                  ]),
                ),
              );
            }),
            if (_filtered.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text('No devices match your search.', style: AppText.muted)),
          ]))),
          SizedBox(width: wide ? 18 : 0, height: wide ? 0 : 16),
          Expanded(flex: wide ? 2 : 0, child: DashCard(title: 'Service details', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm)), child: Text('${_selected.length} device${_selected.length == 1 ? '' : 's'} selected', style: AppText.label)),
            const SizedBox(height: 14),
            Text('Preferred date', style: AppText.label),
            const SizedBox(height: 7),
            InkWell(
              onTap: () async {
                final d = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 3)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)));
                if (d != null) setState(() => _date = d);
              },
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14), decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(AppRadius.sm)), child: Row(children: [const Icon(Icons.calendar_today_outlined, size: 16, color: AppColors.ink400), const SizedBox(width: 10), Text(_date == null ? 'Select a date' : _fmtDate(_date!.toIso8601String()), style: AppText.body)])),
            ),
            const SizedBox(height: 14),
            Text('Time slot', style: AppText.label),
            const SizedBox(height: 7),
            DropdownButtonFormField<int>(value: _slot, isExpanded: true, items: List.generate(_slots.length, (i) => DropdownMenuItem(value: i, child: Text(_slots[i], style: AppText.body))), onChanged: (v) => setState(() => _slot = v!)),
            const SizedBox(height: 14),
            Text('Notes (optional)', style: AppText.label),
            const SizedBox(height: 7),
            TextField(controller: _notes, maxLines: 2, decoration: const InputDecoration(hintText: 'Access instructions, on-site contact, etc.')),
            const SizedBox(height: 16),
            PwtButton('Schedule visit', fullWidth: true, onPressed: _selected.isEmpty ? null : _schedule),
            if (_selected.isEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text('Select at least one device to continue.', style: AppText.muted)),
          ]))),
        ]),
      ]),
    );
  }
}

class MaintenanceDetailsScreen extends StatefulWidget {
  const MaintenanceDetailsScreen({super.key});
  @override
  State<MaintenanceDetailsScreen> createState() => _MaintenanceDetailsScreenState();
}

class _MaintenanceDetailsScreenState extends State<MaintenanceDetailsScreen> {
  int? _idx;
  final _slots = const ['Morning (8AM – 12PM)', 'Afternoon (12PM – 4PM)', 'Evening (4PM – 7PM)'];

  @override
  Widget build(BuildContext context) {
    _idx ??= (ModalRoute.of(context)?.settings.arguments as int?) ?? 0;
    final wide = MediaQuery.of(context).size.width > 880;
    return DashboardShell(
      active: 'maintenance',
      child: AnimatedBuilder(
        animation: AppState.I,
        builder: (context, _) {
          final all = AppState.I.maintenance;
          final exists = _idx! >= 0 && _idx! < all.length;
          if (!exists) {
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const DashHeader(title: 'Service Visit', subtitle: 'Scheduled maintenance details', crumbs: ['Maintenance', 'Service visit']),
              DashCard(child: Padding(padding: const EdgeInsets.symmetric(vertical: 30), child: Center(child: Column(children: [
                const Icon(Icons.error_outline, size: 36, color: AppColors.ink400),
                const SizedBox(height: 12),
                Text('Visit not found', style: AppText.h3),
                const SizedBox(height: 6),
                Text('This maintenance visit no longer exists.', style: AppText.muted),
                const SizedBox(height: 16),
                PwtButton('Back to Maintenance', onPressed: () => Navigator.of(context).pushReplacementNamed('/companyMaintenance')),
              ])))),
            ]);
          }
          final v = all[_idx!];
          final cancelled = v.status == 'Cancellation requested';
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            DashHeader(
              title: 'Service Visit',
              subtitle: 'Scheduled maintenance details',
              crumbs: const ['Maintenance', 'Service visit'],
              action: PwtButton('Back', variant: PwtBtn.outline, icon: Icons.arrow_back, onPressed: () => Navigator.of(context).pushReplacementNamed('/companyMaintenance')),
            ),
            Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(flex: wide ? 1 : 0, child: Column(children: [
                DashCard(title: 'Visit details', action: cancelled ? StatusBadge.amber('Cancellation requested') : StatusBadge.blue('Scheduled'), child: Column(children: [
                  _detail('Status', cancelled ? 'Cancellation requested' : 'Scheduled'),
                  _detail('Date', _fmtDate(v.date, weekday: true)),
                  _detail('Time slot', v.slot),
                  _detail('Devices', '${v.devices.length} device${v.devices.length == 1 ? '' : 's'}'),
                  if (v.notes.isNotEmpty) _detail('Notes', v.notes),
                ])),
                const SizedBox(height: 16),
                DashCard(title: 'Devices on this visit', child: Column(children: v.devices.map((d) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [
                      Container(width: 38, height: 38, decoration: BoxDecoration(color: AppColors.blue50, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.build_outlined, size: 18, color: AppColors.blue700)),
                      const SizedBox(width: 12),
                      Text(d, style: AppText.label),
                    ]))).toList())),
              ])),
              SizedBox(width: wide ? 18 : 0, height: wide ? 0 : 16),
              Expanded(flex: wide ? 1 : 0, child: Column(children: [
                DashCard(title: 'Manage visit', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(cancelled
                      ? 'A cancellation has been requested for this visit. Our team will confirm shortly. Changed your mind? You can keep the visit.'
                      : 'Need to change this visit? You can reschedule it or request a cancellation. Our team will confirm by email.', style: AppText.body.copyWith(color: AppColors.ink500, height: 1.55)),
                  const SizedBox(height: 16),
                  if (!cancelled) ...[
                    PwtButton('Reschedule', icon: Icons.calendar_today_outlined, fullWidth: true, onPressed: () => _reschedule(v)),
                    const SizedBox(height: 10),
                    PwtButton('Request cancellation', variant: PwtBtn.danger, fullWidth: true, onPressed: () {
                      v.status = 'Cancellation requested';
                      AppState.I.updateMaintenance(_idx!, v);
                    }),
                  ] else
                    PwtButton('Keep this visit', variant: PwtBtn.outline, fullWidth: true, onPressed: () {
                      v.status = 'Scheduled';
                      AppState.I.updateMaintenance(_idx!, v);
                    }),
                ])),
                const SizedBox(height: 16),
                DashCard(title: 'Service support', child: Row(children: [
                  Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.person_outline, color: AppColors.blue700)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('James Whitfield · Account Manager', style: AppText.label), const SizedBox(height: 2), Text('0800 123 4570 · james.w@pwt.com', style: AppText.muted)])),
                ])),
              ])),
            ]),
          ]);
        },
      ),
    );
  }

  Widget _detail(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 110, child: Text(k, style: AppText.muted)), Expanded(child: Text(v, style: AppText.label))]),
      );

  void _reschedule(MaintVisit v) {
    DateTime? newDate = v.date.isEmpty ? null : DateTime.tryParse(v.date);
    int slot = _slots.indexOf(v.slot).clamp(0, _slots.length - 1);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, set) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 22, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text('Reschedule Visit', style: AppText.h2.copyWith(fontSize: 19))), IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx))]),
          const SizedBox(height: 12),
          Text('New date', style: AppText.label),
          const SizedBox(height: 7),
          InkWell(
            onTap: () async {
              final d = await showDatePicker(context: ctx, initialDate: newDate ?? DateTime.now().add(const Duration(days: 3)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)));
              if (d != null) set(() => newDate = d);
            },
            child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14), decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(AppRadius.sm)), child: Text(newDate == null ? 'Select a date' : _fmtDate(newDate!.toIso8601String()), style: AppText.body)),
          ),
          const SizedBox(height: 14),
          Text('Time slot', style: AppText.label),
          const SizedBox(height: 7),
          DropdownButtonFormField<int>(value: slot, isExpanded: true, items: List.generate(_slots.length, (i) => DropdownMenuItem(value: i, child: Text(_slots[i], style: AppText.body))), onChanged: (val) => set(() => slot = val!)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: PwtButton('Cancel', variant: PwtBtn.outline, fullWidth: true, onPressed: () => Navigator.pop(ctx))),
            const SizedBox(width: 12),
            Expanded(child: PwtButton('Save changes', fullWidth: true, onPressed: () {
              v.date = newDate?.toIso8601String().split('T').first ?? '';
              v.slot = _slots[slot];
              v.status = 'Scheduled';
              AppState.I.updateMaintenance(_idx!, v);
              Navigator.pop(ctx);
            })),
          ]),
        ]),
      )),
    );
  }
}
