import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'login_screen.dart' show AuthShell;

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  int _acct = 0; // 0 individual, 1 company
  int _step = 1; // 1 mobile, 2 otp, 3 details
  final _phone = TextEditingController();
  final _otp = List.generate(6, (_) => TextEditingController());
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _email = TextEditingController();
  final _company = TextEditingController();
  bool _obscure = true;

  bool get isCompany => _acct == 1;

  Future<void> _register() async {
    final name = '${_first.text.trim()} ${_last.text.trim()}'.trim();
    final finalName = name.isEmpty ? 'PWT Member' : name;
    String initials(String s) {
      final parts = s.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
      return parts.take(2).map((p) => p[0].toUpperCase()).join();
    }
    final company = _company.text.trim();
    final ini = isCompany && company.isNotEmpty ? initials(company) : initials(finalName);
    await AppState.I.signIn(PwtUser(
      name: finalName,
      email: _email.text.trim().isEmpty ? 'member@email.com' : _email.text.trim(),
      initials: ini.isEmpty ? 'PW' : ini,
      accountType: isCompany ? 'company' : 'individual',
      company: company,
    ));
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil(isCompany ? '/companyDashboard' : '/dashboard', (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    return AuthShell(
      headline: 'Join thousands drinking better.',
      sub: 'Create your free PWT account to shop systems, set up rentals and keep your filters fresh — all in one dashboard.',
      bullets: const ['Free 7-day trial on rentals', 'Fast delivery & installation', 'Maintenance & filter reminders'],
      form: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextButton.icon(onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false), icon: const Icon(Icons.arrow_back, size: 16), label: const Text('Back to home'), style: TextButton.styleFrom(padding: EdgeInsets.zero)),
          const SizedBox(height: 12),
          _progress(),
          const SizedBox(height: 20),
          if (_step == 1) _mobileStep() else if (_step == 2) _otpStep() else _detailsStep(),
          const SizedBox(height: 16),
          Center(child: Wrap(children: [
            Text('Already have an account? ', style: AppText.body.copyWith(color: AppColors.ink500)),
            GestureDetector(onTap: () => Navigator.of(context).pushReplacementNamed('/login'), child: Text('Sign in', style: AppText.label.copyWith(color: AppColors.blue700))),
          ])),
        ]),
      ),
    );
  }

  Widget _progress() {
    final labels = ['Mobile', 'Verify', 'Details'];
    return Row(children: List.generate(3, (i) {
      final n = i + 1;
      final done = n < _step;
      final active = n == _step;
      return Expanded(child: Row(children: [
        Container(width: 26, height: 26, decoration: BoxDecoration(color: done || active ? AppColors.blue700 : Colors.white, shape: BoxShape.circle, border: Border.all(color: done || active ? AppColors.blue700 : AppColors.line, width: 1.5)), child: done ? const Icon(Icons.check, size: 14, color: Colors.white) : Center(child: Text('$n', style: AppText.muted.copyWith(color: active ? Colors.white : AppColors.ink400, fontWeight: FontWeight.w700)))),
        const SizedBox(width: 7),
        Text(labels[i], style: AppText.muted.copyWith(color: active ? AppColors.ink900 : AppColors.ink400, fontWeight: FontWeight.w600)),
        if (i < 2) Expanded(child: Container(height: 1.5, margin: const EdgeInsets.symmetric(horizontal: 8), color: done ? AppColors.blue700 : AppColors.line)),
      ]));
    }));
  }

  Widget _mobileStep() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Create your account', style: AppText.h2),
      const SizedBox(height: 6),
      Text("Enter your mobile number to get started — we'll text you a verification code.", style: AppText.body.copyWith(color: AppColors.ink500)),
      const SizedBox(height: 18),
      Segmented(options: const ['Personal', 'Business'], icons: const [Icons.person_outline, Icons.apartment], index: _acct, onChanged: (i) => setState(() => _acct = i)),
      const SizedBox(height: 18),
      Text('Mobile number', style: AppText.label),
      const SizedBox(height: 7),
      Row(children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15), decoration: BoxDecoration(border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(AppRadius.sm)), child: const Text('🇦🇪  +971', style: TextStyle(fontWeight: FontWeight.w600))),
        const SizedBox(width: 10),
        Expanded(child: TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: '50 123 4567'))),
      ]),
      const SizedBox(height: 20),
      PwtButton('Send verification code', fullWidth: true, onPressed: () => setState(() => _step = 2)),
    ]);
  }

  Widget _otpStep() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Verify your number', style: AppText.h2),
      const SizedBox(height: 6),
      Text('Enter the 6-digit code we sent by SMS.', style: AppText.body.copyWith(color: AppColors.ink500)),
      const SizedBox(height: 18),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: List.generate(6, (i) => SizedBox(
            width: 46,
            child: TextField(
              controller: _otp[i],
              textAlign: TextAlign.center,
              maxLength: 1,
              keyboardType: TextInputType.number,
              style: AppText.h3,
              decoration: const InputDecoration(counterText: ''),
              onChanged: (v) {
                if (v.isNotEmpty && i < 5) FocusScope.of(context).nextFocus();
              },
            ),
          ))),
      const SizedBox(height: 8),
      Text('Demo: enter any 6 digits to continue.', style: AppText.muted),
      const SizedBox(height: 18),
      PwtButton('Verify & continue', fullWidth: true, onPressed: () => setState(() => _step = 3)),
      const SizedBox(height: 8),
      Center(child: TextButton(onPressed: () => setState(() => _step = 1), child: const Text('Change number'))),
    ]);
  }

  Widget _detailsStep() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Complete your profile', style: AppText.h2),
      const SizedBox(height: 6),
      Text('Almost there — just a few details to finish setting up.', style: AppText.body.copyWith(color: AppColors.ink500)),
      const SizedBox(height: 18),
      if (isCompany) ...[
        Text('Company name', style: AppText.label),
        const SizedBox(height: 7),
        TextField(controller: _company, decoration: const InputDecoration(hintText: 'Acme Hospitality Ltd')),
        const SizedBox(height: 14),
      ],
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('First name', style: AppText.label), const SizedBox(height: 7), TextField(controller: _first, decoration: const InputDecoration(hintText: 'Sarah'))])),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Last name', style: AppText.label), const SizedBox(height: 7), TextField(controller: _last, decoration: const InputDecoration(hintText: 'Johnson'))])),
      ]),
      const SizedBox(height: 14),
      Text('Email address', style: AppText.label),
      const SizedBox(height: 7),
      TextField(controller: _email, decoration: const InputDecoration(hintText: 'you@email.com')),
      const SizedBox(height: 14),
      Text('Password', style: AppText.label),
      const SizedBox(height: 7),
      TextField(obscureText: _obscure, decoration: InputDecoration(hintText: 'At least 8 characters', suffixIcon: IconButton(icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 18), onPressed: () => setState(() => _obscure = !_obscure)))),
      const SizedBox(height: 20),
      PwtButton('Create Account', fullWidth: true, onPressed: _register),
    ]);
  }
}
