import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/dashboard_widgets.dart';
import 'dashboard_shell.dart';

class CompanyDevicesScreen extends StatefulWidget {
  const CompanyDevicesScreen({super.key});
  @override
  State<CompanyDevicesScreen> createState() => _CompanyDevicesScreenState();
}

class _CompanyDevicesScreenState extends State<CompanyDevicesScreen> {
  int _tab = 0;
  final _tabs = const ['All', 'Rented', 'Purchased'];

  final _fleet = const [
    ['pw90.png', 'PW50-R × 18', 'Hot & Cold Water Dispenser', 'Rental · 36 months', 'Next: £522 · 01 Jul 2026', 'Rented', true],
    ['ct.png', 'PW90-R CT × 40', 'Countertop RO System', 'Rental · 24 months', 'Next: £1,160 · 01 Jul 2026', 'Rented', false],
    ['s4.png', 'S4 Sparkling × 24', 'Sparkling Water Dispenser', 'Purchased · 18 Mar 2026', 'Warranty: 2 years', 'Purchased', false],
    ['pw0ctr.png', 'PW30-C × 28', 'Countertop Dispenser', 'Rental · 36 months', 'Next: £812 · 01 Jul 2026', 'Rented', false],
    ['pw90.png', 'PW50-R × 22', 'Hot & Cold Water Dispenser', 'Purchased · 02 Feb 2026', 'Warranty: 2 years', 'Purchased', false],
    ['ct.png', 'PW-RO5 × 10', 'Reverse Osmosis System', 'Rental · 24 months', 'Next: £290 · 01 Jul 2026', 'Rented', false],
  ];

  @override
  Widget build(BuildContext context) {
    final rows = _fleet.where((d) => _tab == 0 || d[5] == _tabs[_tab]).toList();
    return DashboardShell(
      active: 'devices',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashHeader(
          title: 'Devices',
          subtitle: 'All water systems across your business account.',
          action: PwtButton('Request Quotation', icon: Icons.add, onPressed: () => Navigator.of(context).pushNamed('/rfq')),
        ),
        const KpiGrid(tiles: [
          KpiTile(label: 'Total Devices', value: '142', sub: 'Across 6 sites', icon: Icons.inventory_2_outlined, iconColor: AppColors.blue700),
          KpiTile(label: 'Rented', value: '96', sub: 'Monthly billing', icon: Icons.autorenew, iconColor: AppColors.amber),
          KpiTile(label: 'Purchased', value: '46', sub: 'Owned outright', icon: Icons.check_circle_outline, iconColor: AppColors.green600),
        ]),
        const SizedBox(height: 18),
        DashCard(
          title: 'All Devices',
          action: Wrap(spacing: 6, children: List.generate(_tabs.length, (i) {
            final on = _tab == i;
            return GestureDetector(
              onTap: () => setState(() => _tab = i),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7), decoration: BoxDecoration(color: on ? AppColors.blue700 : AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.pill)), child: Text(_tabs[i], style: AppText.muted.copyWith(color: on ? Colors.white : AppColors.ink600, fontWeight: FontWeight.w600))),
            );
          })),
          child: Column(children: rows.map((d) => _deviceRow(context, d)).toList()),
        ),
      ]),
    );
  }

  Widget _deviceRow(BuildContext context, List d) {
    final wide = MediaQuery.of(context).size.width > 760;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm), border: Border.all(color: AppColors.line)),
      child: Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: wide ? 3 : 0, child: Row(children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(9), border: Border.all(color: AppColors.line)), padding: const EdgeInsets.all(6), child: Image.asset('assets/images/${d[0]}', fit: BoxFit.contain)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d[1], style: AppText.label),
            Text(d[2], style: AppText.muted),
            if (d[6] == true) Padding(padding: const EdgeInsets.only(top: 3), child: Row(children: [const Icon(Icons.build_outlined, size: 13, color: AppColors.blue700), const SizedBox(width: 5), Text('Maintenance scheduled · 20 Jun 2026', style: AppText.muted.copyWith(color: AppColors.blue700))])),
          ])),
        ])),
        SizedBox(width: wide ? 12 : 0, height: wide ? 0 : 10),
        Expanded(flex: wide ? 2 : 0, child: Column(crossAxisAlignment: wide ? CrossAxisAlignment.start : CrossAxisAlignment.start, children: [
          Text(d[3], style: AppText.body),
          Text(d[4], style: AppText.muted),
        ])),
        SizedBox(width: wide ? 12 : 0, height: wide ? 0 : 10),
        StatusBadge.forStatus(d[5]),
        SizedBox(width: wide ? 12 : 0, height: wide ? 0 : 10),
        PwtButton('Request maintenance', variant: PwtBtn.outline, onPressed: () => Navigator.of(context).pushReplacementNamed('/companyMaintenance')),
      ]),
    );
  }
}

class CompanyOrdersScreen extends StatefulWidget {
  const CompanyOrdersScreen({super.key});
  @override
  State<CompanyOrdersScreen> createState() => _CompanyOrdersScreenState();
}

class _CompanyOrdersScreenState extends State<CompanyOrdersScreen> {
  late List<Map<String, dynamic>> _orders;

  @override
  void initState() {
    super.initState();
    _orders = [
      {'img': 's4.png', 'name': 'S18 UC Undercounter', 'sub': '3-tap chilled & sparkling', 'po': '#PWT-Q-2026-0207', 'qty': '12', 'value': '£14,900', 'added': '03 Jun 2026', 'status': 'Quotation sent', 'agree': true},
      {'img': 'ct.png', 'name': 'PW90-R CT', 'sub': 'Touchless countertop', 'po': '#PWT-B-2026-0188', 'qty': '40', 'value': '£18,400', 'added': '28 May 2026', 'status': 'Confirmed', 'agree': false},
      {'img': 's4.png', 'name': 'S4 Sparkling', 'sub': 'Touch-free sparkling', 'po': '#PWT-B-2026-0181', 'qty': '24', 'value': '£21,600', 'added': '20 May 2026', 'status': 'In production', 'agree': false},
      {'img': 'pw90.png', 'name': 'PW50-R', 'sub': 'Hot & cold dispenser', 'po': '#PWT-B-2026-0174', 'qty': '18', 'value': '£12,420', 'added': '14 May 2026', 'status': 'Installing', 'agree': false},
      {'img': 'pw0ctr.png', 'name': 'Filter & Cartridge Sets', 'sub': 'Quarterly resupply', 'po': '#PWT-B-2026-0166', 'qty': '120', 'value': '£3,480', 'added': '02 May 2026', 'status': 'Delivered', 'agree': false},
    ];
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 880;
    return DashboardShell(
      active: 'orders',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DashHeader(
          title: 'Orders',
          subtitle: 'Your purchase orders and quotations, newest first',
          crumbs: const ['Dashboard', 'Orders'],
          action: PwtButton('New Bulk Order', icon: Icons.add, onPressed: () => Navigator.of(context).pushNamed('/rfq')),
        ),
        const KpiGrid(tiles: [
          KpiTile(label: 'Open POs', value: '7', sub: '2 awaiting approval'),
          KpiTile(label: 'Units on Order', value: '96', sub: 'across 4 sites'),
          KpiTile(label: 'Quotations', value: '3', sub: 'pending review'),
          KpiTile(label: 'Value on Order', value: '£55.9k', sub: 'Net 30 terms'),
        ]),
        const SizedBox(height: 18),
        DashCard(
          title: 'Orders',
          action: Text('Sorted by date · newest first', style: AppText.muted),
          child: DashTable(
            headers: const ['Product', 'PO Number', 'Qty', 'Value', 'Added', 'Status', ''],
            rows: List.generate(_orders.length, (i) {
              final o = _orders[i];
              return [
                ProdCell(image: 'assets/images/${o['img']}', name: o['name'], sub: o['sub']),
                Text(o['po'], style: AppText.label.copyWith(color: AppColors.blue700)),
                Text(o['qty'], style: AppText.label),
                Text(o['value'], style: AppText.body),
                Text(o['added'], style: AppText.body),
                Align(alignment: Alignment.centerLeft, child: StatusBadge.forStatus(o['status'])),
                Align(alignment: Alignment.centerLeft, child: o['agree'] == true
                    ? PwtButton('Agree', onPressed: () => setState(() {
                          o['status'] = 'Agreed · PO raised';
                          o['agree'] = false;
                        }))
                    : TextButton(onPressed: () {}, child: const Text('View'))),
              ];
            }),
          ),
        ),
        const SizedBox(height: 18),
        Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: wide ? 1 : 0, child: DashCard(
            title: 'Delivery & Install · PO #PWT-B-2026-0181',
            action: StatusBadge.blue('In production'),
            child: const Timeline(steps: [
              TimelineStep('Quotation approved', '20 May · PO raised', done: true),
              TimelineStep('Deposit invoiced (Net 30)', '21 May', done: true),
              TimelineStep('In production — 24 units', 'Batch QC in progress', active: true),
              TimelineStep('Phased delivery to 3 sites', 'From 12 June'),
              TimelineStep('Installation & staff training', '16–20 June'),
            ]),
          )),
          SizedBox(width: wide ? 18 : 0, height: wide ? 0 : 16),
          Expanded(flex: wide ? 1 : 0, child: DashCard(title: 'Bulk Order Support', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 42, height: 42, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.person_outline, color: AppColors.blue700)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('James Whitfield · Account Manager', style: AppText.label), const SizedBox(height: 2), Text('Direct: 0800 123 4570 · james.w@pwt.com', style: AppText.muted)])),
            ]),
            const SizedBox(height: 14),
            PwtButton('Request a Quotation', fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/rfq')),
            const SizedBox(height: 10),
            PwtButton('Download Account Statement', variant: PwtBtn.outline, fullWidth: true, onPressed: () => Navigator.of(context).pushReplacementNamed('/invoices')),
          ]))),
        ]),
      ]),
    );
  }
}
