import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/app_theme.dart';
import '../models/product.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/site_chrome.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});
  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final _gallery = const ['assets/images/pw90.png', 'assets/images/pw50.png', 'assets/images/pw0ctr.png', 'assets/images/ct.png', 'assets/images/s4.png'];
  int _img = 0;
  int _view = 0; // 0 individual, 1 company
  int _mode = 0; // 0 buy, 1 rent
  int _tab = 0;

  Product? _product;

  @override
  Widget build(BuildContext context) {
    _product ??= (ModalRoute.of(context)?.settings.arguments as Product?) ?? kProducts.first;
    final p = _product!;
    final wide = MediaQuery.of(context).size.width > 900;

    return StoreScaffold(active: '/shop', slivers: [
      SliverToBoxAdapter(
        child: Band(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            InkWell(onTap: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (r) => false), child: Text('Home', style: AppText.muted.copyWith(color: AppColors.blue700))),
            Text('  ›  ', style: AppText.muted),
            InkWell(onTap: () => Navigator.of(context).pushNamed('/shop'), child: Text('Shop', style: AppText.muted.copyWith(color: AppColors.blue700))),
            Text('  ›  ${p.name}', style: AppText.muted),
          ]),
          const SizedBox(height: 14),
          // view toggle
          ConstrainedBox(constraints: const BoxConstraints(maxWidth: 560), child: Segmented(options: const ['Individual — Buy / Rent', 'Company — Request Quote'], index: _view, onChanged: (i) => setState(() => _view = i))),
          const SizedBox(height: 22),
          Flex(direction: wide ? Axis.horizontal : Axis.vertical, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: wide ? 1 : 0, child: _gallerySection()),
            SizedBox(width: wide ? 30 : 0, height: wide ? 0 : 24),
            Expanded(flex: wide ? 1 : 0, child: _view == 0 ? _individualPane(p) : _companyPane()),
          ]),
          const SizedBox(height: 30),
          _detailTabs(),
        ])),
      ),
    ]);
  }

  Widget _gallerySection() {
    return Column(children: [
      Container(
        height: 380,
        decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.xl), border: Border.all(color: AppColors.line)),
        child: Stack(children: [
          Positioned(top: 14, left: 14, child: Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5), decoration: BoxDecoration(color: AppColors.blue700, borderRadius: BorderRadius.circular(AppRadius.pill)), child: Text('Best Seller', style: AppText.muted.copyWith(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 10.5)))),
          Center(child: Padding(padding: const EdgeInsets.all(24), child: Image.asset(_gallery[_img], fit: BoxFit.contain))),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: List.generate(_gallery.length, (i) {
        final on = i == _img;
        return Padding(
          padding: const EdgeInsets.only(right: 10),
          child: GestureDetector(
            onTap: () => setState(() => _img = i),
            child: Container(
              width: 64,
              height: 64,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? AppColors.blue600 : AppColors.line, width: on ? 2 : 1)),
              child: Image.asset(_gallery[i], fit: BoxFit.contain),
            ),
          ),
        );
      })),
    ]);
  }

  Widget _individualPane(Product p) {
    final isRent = _mode == 1;
    final feats = [
      [Icons.water_drop, 'Instant hot & cold water'],
      [Icons.bolt, 'Energy efficient'],
      [Icons.lock_outline, 'Child safety lock'],
      [Icons.diamond_outlined, 'Sleek modern design'],
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(p.name, style: AppText.headline(30)),
      const SizedBox(height: 4),
      Text(p.sub, style: AppText.bodyLg),
      const SizedBox(height: 10),
      Row(children: [
        ...List.generate(5, (i) => const Icon(Icons.star, size: 16, color: Color(0xFFF5B400))),
        const SizedBox(width: 8),
        Text('4.8', style: AppText.label),
        const SizedBox(width: 6),
        Text('(128 reviews)', style: AppText.muted),
      ]),
      const SizedBox(height: 14),
      Text('Sleek, modern and built for performance. The ${p.name} delivers refreshingly hot and cold water instantly, perfect for homes and offices.', style: AppText.body.copyWith(height: 1.6)),
      const SizedBox(height: 18),
      Wrap(spacing: 12, runSpacing: 12, children: feats.map((f) => SizedBox(
            width: 220,
            child: Row(children: [Icon(f[0] as IconData, size: 18, color: AppColors.blue600), const SizedBox(width: 8), Flexible(child: Text(f[1] as String, style: AppText.body))]),
          )).toList()),
      const SizedBox(height: 20),
      // price
      if (!isRent)
        Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
          Text(money(p.price), style: AppText.headline(28).copyWith(color: p.discounted ? AppColors.discount : AppColors.ink900)),
          if (p.discounted) ...[
            const SizedBox(width: 10),
            Text(money(p.oldPrice!), style: AppText.bodyLg.copyWith(decoration: TextDecoration.lineThrough)),
            const SizedBox(width: 10),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: AppColors.badgeGreenBg, borderRadius: BorderRadius.circular(AppRadius.pill)), child: Text('${p.discountPct}% OFF', style: AppText.muted.copyWith(color: AppColors.discount, fontWeight: FontWeight.w700))),
          ],
        ])
      else
        Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
          Text('£29', style: AppText.headline(28)),
          const SizedBox(width: 4),
          Text('/ month', style: AppText.bodyLg),
        ]),
      const SizedBox(height: 4),
      Text(isRent ? 'Billed monthly · cancel anytime' : 'You save ${money((p.oldPrice ?? p.price) - p.price)} · limited-time offer', style: AppText.muted.copyWith(color: AppColors.discount)),
      const SizedBox(height: 16),
      Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(AppRadius.sm + 2), border: Border.all(color: AppColors.line)), child: Row(children: [
        _modeTab('Buy', 0),
        _modeTab('Rent', 1),
      ])),
      const SizedBox(height: 14),
      PwtButton(isRent ? 'Start Rental' : 'Add to Cart', icon: Icons.shopping_cart_outlined, fullWidth: true, onPressed: () {
        AppState.I.addToCart(p, mode: isRent ? 'rent' : 'buy', rentTerm: isRent ? 36 : null);
        Navigator.of(context).pushNamed('/cart');
      }),
      const SizedBox(height: 10),
      PwtButton(isRent ? 'See Rental Plans' : 'Buy Now', variant: PwtBtn.outline, fullWidth: true, onPressed: () {
        AppState.I.addToCart(p, mode: isRent ? 'rent' : 'buy', rentTerm: isRent ? 36 : null);
        Navigator.of(context).pushNamed('/checkout', arguments: isRent ? 'rent' : 'buy');
      }),
      const SizedBox(height: 18),
      Row(children: const [
        Expanded(child: _Assurance(Icons.local_shipping_outlined, 'Free Delivery', '3–5 business days')),
        Expanded(child: _Assurance(Icons.build_outlined, 'Free Installation', 'On all orders')),
        Expanded(child: _Assurance(Icons.shield_outlined, '2 Years Warranty', 'Peace of mind')),
      ]),
    ]);
  }

  Widget _modeTab(String label, int i) {
    final on = _mode == i;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _mode = i),
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: on ? Colors.white : Colors.transparent, borderRadius: BorderRadius.circular(AppRadius.sm), boxShadow: on ? AppShadow.card : null),
        child: Text(label, style: AppText.label.copyWith(color: on ? AppColors.ink900 : AppColors.ink500)),
      ),
    ));
  }

  Widget _companyPane() {
    final checks = ['Personalised pricing', 'Bulk order discounts', 'Dedicated account manager', 'Dedicated after-sales support'];
    return Container(
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Interested in this product for your business?', style: AppText.h2.copyWith(fontSize: 20)),
        const SizedBox(height: 8),
        Text('Get a customized quotation tailored to your needs.', style: AppText.bodyLg),
        const SizedBox(height: 16),
        ...checks.map((c) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [const Icon(Icons.check_circle_outline, size: 18, color: AppColors.blue600), const SizedBox(width: 10), Text(c, style: AppText.body)]))),
        const SizedBox(height: 8),
        PwtButton('Request a Quotation', icon: Icons.description_outlined, fullWidth: true, onPressed: () => Navigator.of(context).pushNamed('/rfq')),
        const SizedBox(height: 12),
        Row(children: [const Icon(Icons.info_outline, size: 14, color: AppColors.ink400), const SizedBox(width: 8), Expanded(child: Text('Our team will get back to you within 24 hours.', style: AppText.muted))]),
      ]),
    );
  }

  Widget _detailTabs() {
    final tabs = ['Overview', 'Specifications', "What's in the Box", 'Reviews (128)', 'Documents'];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: List.generate(tabs.length, (i) {
          final on = _tab == i;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => setState(() => _tab = i),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(color: on ? AppColors.blue700 : Colors.white, borderRadius: BorderRadius.circular(AppRadius.pill), border: Border.all(color: on ? AppColors.blue700 : AppColors.line)),
                child: Text(tabs[i], style: AppText.label.copyWith(color: on ? Colors.white : AppColors.ink600)),
              ),
            ),
          );
        })),
      ),
      const SizedBox(height: 18),
      _tabBody(),
    ]);
  }

  Widget _tabBody() {
    switch (_tab) {
      case 1:
        return _bullets('Full technical specifications', ['Voltage: 220–240V / 50Hz', 'Heating power: 500W', 'Cooling power: 90W (compressor)', 'Filtration: 5-stage RO + UV', 'Weight: 18 kg', 'Material: Stainless steel + tempered glass', 'Noise level: < 40 dB']);
      case 2:
        return _bullets("What's included", ['${_product!.name} Water Dispenser', 'Starter filter set', 'Power cable (UK)', 'Drip tray (removable)', 'Installation guide', 'Warranty card']);
      case 3:
        return _reviews();
      case 4:
        return _docs();
      default:
        return _bullets('Premium hydration, every day.', ['Hot, cold & ambient water', 'Touch panel with child safety lock', 'Energy saving & eco-friendly', 'Removable drip tray for easy cleaning']);
    }
  }

  Widget _card(Widget child) => Container(width: double.infinity, padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: AppColors.line), boxShadow: AppShadow.card), child: child);

  Widget _bullets(String title, List<String> items) => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: AppText.h2.copyWith(fontSize: 19)),
        const SizedBox(height: 14),
        ...items.map((b) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check, size: 18, color: AppColors.blue600), const SizedBox(width: 10), Expanded(child: Text(b, style: AppText.body))]))),
      ]));

  Widget _reviews() {
    final revs = [
      ['SJ', 'Sarah J.', 'Verified buyer · 12 May 2026', 5, 'Genuinely tastes great. Installation took 15 minutes and the touch panel feels premium. Happy customer.'],
      ['MK', 'Michael K.', 'Verified buyer · 28 Apr 2026', 4, 'Solid build quality. Hot water is properly hot and cold is properly cold. Only wish the cold tank were a touch larger.'],
      ['AR', 'Aisha R.', 'Verified buyer · 03 Apr 2026', 5, "Beautiful design that doesn't look out of place in the kitchen. The kids love it (and the child-safety lock is appreciated)."],
    ];
    return _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: revs.map((r) => Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(radius: 16, backgroundColor: AppColors.blue100, child: Text(r[0] as String, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.blue800))),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r[1] as String, style: AppText.label), Text(r[2] as String, style: AppText.muted)]),
              const Spacer(),
              Row(children: List.generate(5, (i) => Icon(Icons.star, size: 14, color: i < (r[3] as int) ? const Color(0xFFF5B400) : AppColors.line))),
            ]),
            const SizedBox(height: 8),
            Text(r[4] as String, style: AppText.body.copyWith(height: 1.5)),
          ]),
        )).toList()));
  }

  Widget _docs() {
    final docs = [
      ['${_product!.name} User Manual', 'PDF · 2.4 MB'],
      ['Installation Guide', 'PDF · 1.1 MB'],
      ['CE / Safety Certificate', 'PDF · 480 KB'],
      ['Warranty Information', 'PDF · 220 KB'],
    ];
    return _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Manuals & certifications', style: AppText.h2.copyWith(fontSize: 19)),
      const SizedBox(height: 14),
      ...docs.map((d) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.soft, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.description_outlined, size: 20, color: AppColors.blue700)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d[0], style: AppText.label), Text(d[1], style: AppText.muted)])),
              TextButton.icon(onPressed: () {}, icon: const Icon(Icons.download, size: 14), label: const Text('Download')),
            ]),
          )),
    ]));
  }
}

class _Assurance extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  const _Assurance(this.icon, this.title, this.sub);
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Icon(icon, size: 20, color: AppColors.blue600),
      const SizedBox(height: 6),
      Text(title, style: AppText.muted.copyWith(fontWeight: FontWeight.w700, color: AppColors.ink800), textAlign: TextAlign.center),
      Text(sub, style: AppText.muted.copyWith(fontSize: 11), textAlign: TextAlign.center),
    ]);
  }
}
