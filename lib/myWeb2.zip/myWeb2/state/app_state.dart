import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';

/// Logged-in user (mirrors the prototype's localStorage `pwt_auth`).
class PwtUser {
  final String name;
  final String email;
  final String initials;
  final String accountType; // 'individual' | 'company'
  final String company;
  final String phone;
  const PwtUser({
    required this.name,
    required this.email,
    required this.initials,
    required this.accountType,
    this.company = '',
    this.phone = '',
  });

  bool get isCompany => accountType == 'company';

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'initials': initials,
        'accountType': accountType,
        'company': company,
        'phone': phone,
      };

  factory PwtUser.fromJson(Map<String, dynamic> j) => PwtUser(
        name: j['name'] ?? 'PWT Member',
        email: j['email'] ?? '',
        initials: j['initials'] ?? 'PW',
        accountType: j['accountType'] ?? 'individual',
        company: j['company'] ?? '',
        phone: j['phone'] ?? '',
      );

  /// Build an auth record the way the prototype's Login/Register did.
  static PwtUser fromLogin({required String email, required String accountType}) {
    final e = email.trim().toLowerCase();
    final local = e.contains('@') ? e.split('@').first : 'member';
    final domain = e.contains('@') ? e.split('@')[1].split('.').first : '';
    String title(String s) => s
        .replaceAll(RegExp(r'[._-]+'), ' ')
        .split(' ')
        .where((w) => w.isNotEmpty)
        .map((w) => w[0].toUpperCase() + w.substring(1))
        .join(' ')
        .trim();
    String initialsOf(String s) {
      final parts = s.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
      return parts.take(2).map((p) => p[0].toUpperCase()).join();
    }
    if (accountType == 'company') {
      final company = title(domain.isEmpty ? 'Your Company' : domain);
      return PwtUser(
        name: 'Sarah Johnson',
        email: e.isEmpty ? 'orders@company.com' : e,
        company: company.isEmpty ? 'Your Company' : company,
        initials: initialsOf(company).isEmpty ? 'CO' : initialsOf(company),
        accountType: 'company',
      );
    }
    final name = local.startsWith('sarah') ? 'Sarah Johnson' : (title(local).isEmpty ? 'PWT Member' : title(local));
    return PwtUser(
      name: name,
      email: e.isEmpty ? 'member@email.com' : e,
      initials: initialsOf(name).isEmpty ? 'PW' : initialsOf(name),
      accountType: 'individual',
    );
  }
}

/// One line in the cart.
class CartLine {
  final Product product;
  int qty;
  final String mode; // 'buy' | 'rent'
  final int? rentTerm; // months, when renting
  CartLine({required this.product, this.qty = 1, this.mode = 'buy', this.rentTerm});

  // Buy charges the actual selling price (product.price already reflects any
  // discount). product.oldPrice is only the struck-through "was" price.
  double get unit => mode == 'rent' ? (rentMonthly ?? 0) : product.price;
  double? get rentMonthly => mode == 'rent' ? _rentFor(rentTerm ?? 36) : null;
  double get lineTotal => unit * qty;

  static double _rentFor(int term) {
    switch (term) {
      case 24:
        return 29;
      case 48:
        return 22;
      default:
        return 25;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': product.id,
        'qty': qty,
        'mode': mode,
        'rentTerm': rentTerm,
      };

  static CartLine? fromJson(Map<String, dynamic> j) {
    final p = kProducts.where((x) => x.id == j['id']).cast<Product?>().firstWhere((x) => x != null, orElse: () => null);
    if (p == null) return null;
    return CartLine(product: p, qty: j['qty'] ?? 1, mode: j['mode'] ?? 'buy', rentTerm: j['rentTerm']);
  }
}

/// A scheduled maintenance visit (mirrors the prototype's `pwt_maint`).
class MaintVisit {
  List<String> devices;
  String date; // ISO yyyy-mm-dd or ''
  String slot;
  String notes;
  String status; // 'Scheduled' | 'Cancellation requested'
  MaintVisit({required this.devices, this.date = '', this.slot = '', this.notes = '', this.status = 'Scheduled'});

  Map<String, dynamic> toJson() => {
        'devices': devices,
        'date': date,
        'slot': slot,
        'notes': notes,
        'status': status,
      };

  factory MaintVisit.fromJson(Map<String, dynamic> j) => MaintVisit(
        devices: (j['devices'] as List).map((e) => e.toString()).toList(),
        date: j['date'] ?? '',
        slot: j['slot'] ?? '',
        notes: j['notes'] ?? '',
        status: j['status'] ?? 'Scheduled',
      );
}

/// Saved address (Profile).
class Address {
  int id;
  String label, line1, line2, city, postcode, country;
  bool isDefault;
  Address({required this.id, required this.label, required this.line1, this.line2 = '', required this.city, required this.postcode, this.country = 'United Kingdom', this.isDefault = false});
  String get full => [line1, line2, city, postcode, country].where((s) => s.isNotEmpty).join(', ');
}

/// Saved card (Profile).
class PayCard {
  int id;
  String brand; // VISA | MC | CARD
  String last4;
  String exp;
  bool isDefault;
  PayCard({required this.id, required this.brand, required this.last4, required this.exp, this.isDefault = false});
}

/// Global app state — single source of truth, persisted to shared_preferences.
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  static const _kAuth = 'pwt_auth';
  static const _kCart = 'pwt_cart';
  static const _kMaint = 'pwt_maint';

  PwtUser? user;
  final List<CartLine> cart = [];
  final List<MaintVisit> maintenance = [];

  bool _loaded = false;
  bool get loaded => _loaded;

  bool get isCompany => user?.isCompany ?? false;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    // auth
    final a = p.getString(_kAuth);
    if (a != null) {
      try {
        user = PwtUser.fromJson(jsonDecode(a));
      } catch (_) {}
    }
    // cart — seed with the prototype's default 2 items on first ever launch
    final c = p.getString(_kCart);
    cart.clear();
    if (c != null) {
      try {
        for (final e in (jsonDecode(c) as List)) {
          final line = CartLine.fromJson(e);
          if (line != null) cart.add(line);
        }
      } catch (_) {}
    } else {
      cart.addAll(_seedCart());
    }
    // maintenance
    final m = p.getString(_kMaint);
    maintenance.clear();
    if (m != null) {
      try {
        for (final e in (jsonDecode(m) as List)) {
          maintenance.add(MaintVisit.fromJson(e));
        }
      } catch (_) {}
    }
    _loaded = true;
    notifyListeners();
  }

  List<CartLine> _seedCart() {
    final pw50 = kProducts.firstWhere((p) => p.id == 'pw50-r');
    final pw30 = kProducts.firstWhere((p) => p.id == 'pw30-c');
    return [
      CartLine(product: pw50, qty: 1, mode: 'buy'),
      CartLine(product: pw30, qty: 1, mode: 'buy'),
    ];
  }

  // ---- auth ----
  Future<void> signIn(PwtUser u) async {
    user = u;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kAuth, jsonEncode(u.toJson()));
    notifyListeners();
  }

  Future<void> signOut() async {
    user = null;
    final p = await SharedPreferences.getInstance();
    await p.remove(_kAuth);
    notifyListeners();
  }

  // ---- cart ----
  int get cartCount => cart.fold(0, (s, l) => s + l.qty);
  double get subtotal => cart.fold(0, (s, l) => s + l.lineTotal);
  double get vat => (subtotal * 0.2);
  double get total => subtotal + vat;

  void addToCart(Product product, {String mode = 'buy', int qty = 1, int? rentTerm}) {
    final existing = cart.where((l) => l.product.id == product.id && l.mode == mode).cast<CartLine?>().firstWhere((l) => l != null, orElse: () => null);
    if (existing != null) {
      existing.qty += qty;
    } else {
      cart.add(CartLine(product: product, mode: mode, qty: qty, rentTerm: rentTerm));
    }
    _persistCart();
    notifyListeners();
  }

  void incQty(CartLine l) {
    l.qty++;
    _persistCart();
    notifyListeners();
  }

  void decQty(CartLine l) {
    if (l.qty > 1) {
      l.qty--;
      _persistCart();
      notifyListeners();
    }
  }

  void removeLine(CartLine l) {
    cart.remove(l);
    _persistCart();
    notifyListeners();
  }

  Future<void> _persistCart() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kCart, jsonEncode(cart.map((l) => l.toJson()).toList()));
  }

  // ---- maintenance ----
  void addMaintenance(MaintVisit v) {
    maintenance.insert(0, v);
    _persistMaint();
    notifyListeners();
  }

  void updateMaintenance(int idx, MaintVisit v) {
    if (idx >= 0 && idx < maintenance.length) {
      maintenance[idx] = v;
      _persistMaint();
      notifyListeners();
    }
  }

  void removeMaintenance(int idx) {
    if (idx >= 0 && idx < maintenance.length) {
      maintenance.removeAt(idx);
      _persistMaint();
      notifyListeners();
    }
  }

  Future<void> _persistMaint() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kMaint, jsonEncode(maintenance.map((v) => v.toJson()).toList()));
  }
}
