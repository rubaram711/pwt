// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
//
// import 'app.dart';
// import 'state/app_state.dart';
//
// /// Browser entry point.
// ///
// /// Mirrors the React build's startup order:
// ///   1. ensureInitialized + load persisted state
// ///   2. seed demo data (idempotent)
// ///   3. mount the SPA shell
// Future<void> main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   SystemChrome.setPreferredOrientations(const [
//     DeviceOrientation.portraitUp,
//     DeviceOrientation.portraitDown,
//     DeviceOrientation.landscapeLeft,
//     DeviceOrientation.landscapeRight,
//   ]);
//
//   // Load theme + language + auth + cart from SharedPreferences.
//   await AppState.instance.load();
//
//   runApp(const PwtApp());
// }
