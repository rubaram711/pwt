import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../theme.dart';
import 'common.dart';

/// Site footer. Slim variant for shop pages, full variant for the home
/// page (footer with columns of links + tagline + copyright).
class SiteFooter extends StatelessWidget {
  const SiteFooter({super.key, this.full = true});
  final bool full;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: isDark ? PwtColors.darkBg : PwtColors.lightBg1,
        border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
      ),
      padding: EdgeInsets.symmetric(horizontal: 28, vertical: full ? 56 : 32),
      child: MaxWidth(
        child: full ? _full(context) : _slim(context),
      ),
    );
  }

  Widget _slim(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          MonoTag(context.t('footer.copyright').toUpperCase()),
          MonoTag(context.t('footer.built_in').toUpperCase()),
        ],
      );

  Widget _full(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final col = w < 720 ? 1 : (w < 1024 ? 2 : 4);
    final groups = _Group._defaults(context);
    final brand = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Image.asset('assets/pwt-logo.png', width: 36, height: 36,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.water_drop_outlined, size: 32)),
          const SizedBox(width: 10),
          Text('PWT',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  )),
        ]),
        const SizedBox(height: 14),
        SizedBox(
          width: 280,
          child: Text(
            context.t('footer.tagline'),
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
      ],
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 56,
          runSpacing: 32,
          children: [
            SizedBox(width: w < 1024 ? double.infinity : 320, child: brand),
            ...groups.map((g) => SizedBox(width: 180, child: g)),
          ],
        ),
        const SizedBox(height: 40),
        const Divider(),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            MonoTag(context.t('footer.copyright').toUpperCase()),
            MonoTag(context.t('footer.built_in').toUpperCase()),
          ],
        ),
      ],
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.items});
  final String title;
  final List<(String, String)> items; // (label, href)

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        MonoTag(title.toUpperCase(), size: 11),
        const SizedBox(height: 12),
        for (final it in items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: InkWell(
              onTap: () => context.go(it.$2),
              child: Text(
                it.$1,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ),
      ],
    );
  }

  static List<_Group> _defaults(BuildContext c) => [
        _Group(title: c.t('nav.products'), items: const [
          ('PW90-R', '/products.html'),
          ('PW50-R', '/products.html'),
          ('S4 Sparkling', '/products.html'),
          ('Compare', '/products.html'),
        ]),
        _Group(title: 'Company', items: [
          (c.t('nav.about'), '/about.html'),
          (c.t('nav.contact'), '/contact.html'),
          ('Sustainability', '/about.html'),
          ('Careers', '/about.html'),
        ]),
        _Group(title: 'Account', items: [
          (c.t('nav.login'), '/login.html'),
          (c.t('nav.create_account'), '/login.html'),
          (c.t('nav.orders'), '/orders.html'),
          (c.t('nav.account_settings'), '/account.html'),
        ]),
      ];
}
