import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/products.dart';
import '../i18n.dart';
import '../state/app_state.dart';
import '../state/cart_store.dart';
import 'common.dart';

/// Homepage hero product carousel — 1:1 port of `slider.jsx`.
///
/// Shows prev / center / next at any time. Center card sits slightly lower,
/// at full scale and opacity. Side cards float higher, shrink to 0.58×,
/// fade to 0.28 opacity, and gain a soft blur. Arrows on either edge step
/// through the deck; ←/→ keyboard arrows work too. Below the stage we show
/// the active product's name, price, and an Add-to-cart button.
class ProductSlider extends StatefulWidget {
  const ProductSlider({super.key, this.height = 360});

  /// Total stage height in logical pixels. Caller is responsible for
  /// allocating enough width — the slider expands to its parent's max.
  final double height;

  @override
  State<ProductSlider> createState() => _ProductSliderState();
}

class _ProductSliderState extends State<ProductSlider> {
  int _idx = 0;
  final FocusNode _focus = FocusNode();

  List<CatalogueItem> get items => catalogue;

  void _go(int dir) {
    final n = items.length;
    setState(() => _idx = (_idx + dir + n) % n);
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final n = items.length;
    final active = items[_idx];
    final finalPrice = active.discount != null
        ? (active.price * (1 - active.discount! / 100)).round()
        : active.price;

    return Focus(
      focusNode: _focus,
      autofocus: false,
      onKeyEvent: (node, event) {
        if (event is KeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
            _go(-1);
            return KeyEventResult.handled;
          }
          if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
            _go(1);
            return KeyEventResult.handled;
          }
        }
        return KeyEventResult.ignored;
      },
      child: LayoutBuilder(builder: (context, c) {
        final stageW = c.maxWidth;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: widget.height,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  for (var i = 0; i < n; i++)_buildCard(i, n, stageW, widget.height),
                  Positioned(
                    left: 4,
                    child: _ArrowBtn(
                      icon: Icons.chevron_left,
                      onTap: () => _go(-1),
                    ),
                  ),
                  Positioned(
                    right: 4,
                    child: _ArrowBtn(
                      icon: Icons.chevron_right,
                      onTap: () => _go(1),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.18),
                    end: Offset.zero,
                  ).animate(anim),
                  child: child,
                ),
              ),
              child: _Info(
                key: ValueKey(active.id),
                item: active,
                finalPrice: finalPrice,
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildCard(int i, int n, double stageW, double stageH) {
    var offset = i - _idx;
    if (offset > n / 2) offset -= n;
    if (offset < -n / 2) offset += n;
    final abs = offset.abs();
    if (abs > 1) return const SizedBox.shrink();

    final isCenter = offset == 0;
    final p = items[i];
    final cardW = (stageW * 0.62).clamp(220.0, 380.0);
    final cardH = stageH - 24;

    // Translation as a fraction of card width to mirror the React `52%` shift.
    final x = offset * cardW * 0.52;
    final y = isCenter ? 14.0 : -22.0;
    final scale = isCenter ? 1.0 : 0.58;
    final opacity = isCenter ? 1.0 : 0.28;
    final blur = isCenter ? 0.0 : 2.5;
    final z = (10 - abs).toDouble();

    Widget cardChild = SizedBox(
      width: cardW,
      height: cardH,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Center(
            child: Image.asset(
              p.img,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => Container(
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .primary
                      .withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Center(
                  child: Icon(Icons.water_drop_outlined, size: 72),
                ),
              ),
            ),
          ),
          if (isCenter && p.discount != null)
            Positioned(
              top: -8,
              right: -8,
              child: _DiscountBurst(percent: p.discount!),
            ),
        ],
      ),
    );

    if (blur > 0) {
      cardChild = ImageFiltered(
        imageFilter: ui.ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: cardChild,
      );
    }


    return Positioned(
      child: IgnorePointer(
        ignoring: !isCenter,
        child: Center(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
            transform: Matrix4.identity()
              ..translate(x, y)
              ..scale(scale),
            transformAlignment: Alignment.center,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 420),
              curve: Curves.easeOutCubic,
              opacity: opacity,
              child: SizedBox.expand(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Faint stacked-card shadow only on the center card
                    if (isCenter)
                      IgnorePointer(
                        child: Container(
                          width: cardW * 0.92,
                          height: cardH * 0.88,
                          margin: const EdgeInsets.only(top: 20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(28),
                            boxShadow: [
                              BoxShadow(
                                color: Theme.of(context)
                                    .colorScheme
                                    .primary
                                    .withValues(alpha: 0.18),
                                blurRadius: 60,
                                spreadRadius: -8,
                                offset: const Offset(0, 30),
                              ),
                            ],
                          ),
                        ),
                      ),
                    cardChild,
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({super.key, required this.item, required this.finalPrice});
  final CatalogueItem item;
  final int finalPrice;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          item.name,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w500,
                letterSpacing: -0.01,
              ),
        ),
        const SizedBox(height: 4),
        MonoTag(item.tag.toUpperCase(), size: 11),
        const SizedBox(height: 10),
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            if (item.discount != null) ...[
              Opacity(
                opacity: 0.55,
                child: AedPrice(
                  value: item.price,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        decoration: TextDecoration.lineThrough,
                      ),
                ),
              ),
              const SizedBox(width: 12),
            ],
            AedPrice(
              value: finalPrice,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        OutlinedButton(
          onPressed: () async {
            final cart = AppState.instance.cart;
            await cart.add(CartItem(
              id: item.id,
              name: item.name,
              price: finalPrice,
              img: item.img,
              payType: cart.payType,
            ));
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('${context.t('cart.added')} · ${item.name}'),
                duration: const Duration(seconds: 2),
              ),
            );
          },
          style: OutlinedButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
            padding:
                const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          ),
          child: Text('+ ${context.t('common.add_to_cart')}'),
        ),
      ],
    );
  }
}

class _ArrowBtn extends StatelessWidget {
  const _ArrowBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(99),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Theme.of(context)
                .cardTheme
                .color
                ?.withValues(alpha: 0.75),
            borderRadius: BorderRadius.circular(99),
            border:
                Border.all(color: Theme.of(context).dividerColor, width: 1),
          ),
          child: Icon(icon, size: 24),
        ),
      ),
    );
  }
}

/// Green star-burst sticker that overlays the active card when the
/// product carries a discount. Matches the SVG in `slider.jsx`.
class _DiscountBurst extends StatelessWidget {
  const _DiscountBurst({required this.percent});
  final int percent;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 88,
      height: 88,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: const Size(88, 88),
            painter: _BurstPainter(),
          ),
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: const TextStyle(
                color: Color(0xFF062A0B),
                fontFamily: 'GeistMono',
                fontFamilyFallback: ['monospace'],
                fontSize: 11,
                fontWeight: FontWeight.w500,
                height: 1.1,
              ),
              children: [
                TextSpan(
                  text: '$percent%\n',
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const TextSpan(text: 'off'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BurstPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Same 20-vertex star path as the JSX version (100×100 viewBox,
    // scaled to `size`).
    const pts = <Offset>[
      Offset(50, 4), Offset(60, 18), Offset(78, 14), Offset(78, 32),
      Offset(94, 42), Offset(84, 56), Offset(94, 70), Offset(78, 78),
      Offset(74, 94), Offset(58, 88), Offset(50, 100), Offset(42, 88),
      Offset(26, 94), Offset(22, 78), Offset(6, 70), Offset(16, 56),
      Offset(6, 42), Offset(22, 32), Offset(22, 14), Offset(40, 18),
    ];
    final sx = size.width / 100;
    final sy = size.height / 100;
    final path = Path()..moveTo(pts.first.dx * sx, pts.first.dy * sy);
    for (final p in pts.skip(1)) {
      path.lineTo(p.dx * sx, p.dy * sy);
    }
    path.close();
    canvas.drawPath(
      path,
      Paint()..color = const Color(0xFF7CFF6B),
    );
  }

  @override
  bool shouldRepaint(covariant _BurstPainter old) => false;
}
