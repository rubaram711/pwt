import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../theme.dart';

/// Max content width matching the original site's `.wrap` container.
const double kMaxContentWidth = 1280.0;

/// Section padding — generous vertical rhythm like the original.
const EdgeInsets kSectionPadding = EdgeInsets.symmetric(
  horizontal: 32,
  vertical: 72,
);

/// Mobile-aware section padding.
EdgeInsets sectionPaddingFor(BuildContext context) {
  final w = MediaQuery.of(context).size.width;
  final hPad = w < 640 ? 20.0 : (w < 1024 ? 28.0 : 40.0);
  final vPad = w < 640 ? 48.0 : 80.0;
  return EdgeInsets.symmetric(horizontal: hPad, vertical: vPad);
}

/// Horizontal-only section padding, for use as a `Padding` between
/// content blocks where the vertical rhythm is handled separately.
EdgeInsets sectionHorizPaddingFor(BuildContext context) {
  final w = MediaQuery.of(context).size.width;
  final hPad = w < 640 ? 20.0 : (w < 1024 ? 28.0 : 40.0);
  return EdgeInsets.symmetric(horizontal: hPad);
}

/// Section padding with a custom top inset (vertical bottom stays default).
EdgeInsets sectionPaddingWithTop(BuildContext context, double top) {
  final w = MediaQuery.of(context).size.width;
  final hPad = w < 640 ? 20.0 : (w < 1024 ? 28.0 : 40.0);
  final vPad = w < 640 ? 48.0 : 80.0;
  return EdgeInsets.fromLTRB(hPad, top, hPad, vPad);
}

/// Constrains a child to [kMaxContentWidth] and centers it.
class MaxWidth extends StatelessWidget {
  const MaxWidth({super.key, required this.child, this.maxWidth = kMaxContentWidth});
  final Widget child;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}

/// Monospaced label / eyebrow like `// PWT · POINT-OF-USE WATER`.
class MonoTag extends StatelessWidget {
  const MonoTag(this.text, {super.key, this.color, this.size = 12});
  final String text;
  final Color? color;
  final double size;

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).textTheme.bodySmall?.color;
    return Text(
      text,
      style: TextStyle(
        fontFamily: 'GeistMono',
        fontFamilyFallback: const ['monospace', 'JetBrains Mono'],
        fontSize: size,
        letterSpacing: 1.4,
        color: c,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}

/// Headline with the same display sizing the original uses for hero titles.
class DisplayHeadline extends StatelessWidget {
  const DisplayHeadline(this.text, {super.key, this.color});
  final String text;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final fontSize = w < 640 ? 44.0 : (w < 1024 ? 60.0 : 80.0);
    return Text(
      text,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w300,
        height: 1.02,
        letterSpacing: -0.02,
        color: color ?? Theme.of(context).textTheme.displayLarge?.color,
      ),
    );
  }
}

/// AED price with the dirham SVG inline. Used wherever a price is shown.
class AedPrice extends StatelessWidget {
  const AedPrice({super.key, required this.value, this.style, this.suffix});
  final Object value; // num (formatted) or String (e.g. 'Quote')
  final TextStyle? style;
  final String? suffix; // e.g. '/ mo'

  @override
  Widget build(BuildContext context) {
    final base = style ?? Theme.of(context).textTheme.titleLarge;
    if (value is! num) {
      return Text(value.toString(), style: base);
    }
    final formatted = (value as num).toInt().toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
    final size = (base?.fontSize ?? 18) * 0.82;
    final color = base?.color ?? Theme.of(context).colorScheme.onSurface;
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 4.0),
          child: SvgPicture.asset(
            'assets/dirham.svg',
            width: size,
            height: size,
            colorFilter: ColorFilter.mode(color, BlendMode.srcIn),
            placeholderBuilder: (_) =>
                Text('AED', style: base?.copyWith(fontSize: size * 0.85)),
          ),
        ),
        Text(formatted, style: base),
        if (suffix != null) ...[
          const SizedBox(width: 4),
          Text(suffix!, style: base?.copyWith(
            fontWeight: FontWeight.w400,
            color: Theme.of(context).textTheme.bodyMedium?.color,
          )),
        ],
      ],
    );
  }
}

/// Pill-shaped chip / tag.
class Chip0 extends StatelessWidget {
  const Chip0({super.key, required this.label, this.icon, this.color});
  final String label;
  final IconData? icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: c.withValues(alpha: 0.32), width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: c),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontFamily: 'GeistMono',
              fontFamilyFallback: const ['monospace'],
              fontWeight: FontWeight.w500,
              letterSpacing: 0.6,
              color: c,
            ),
          ),
        ],
      ),
    );
  }
}

/// Empty-state placeholder shown in dashboards / orders when there's no data.
class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, required this.subtitle, this.icon = Icons.inbox_outlined});
  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 36, color: PwtColors.darkFgFaint),
          const SizedBox(height: 12),
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          Text(subtitle, style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
