import 'package:flutter/material.dart';

import 'header_nav.dart';
import 'site_footer.dart';
import 'whatsapp_fab.dart';

/// Standard page chrome — header on top, content below, footer at the
/// bottom of the scroll view, and a floating WhatsApp button. Every page
/// uses this; the content slot is whatever the page renders inside its
/// build() method.
class PwtScaffold extends StatelessWidget {
  const PwtScaffold({
    super.key,
    required this.active,
    required this.child,
    this.footerFull = true,
    this.padBody = false,
    this.scrollable = true,
  });

  /// Which nav item should be highlighted (`home`, `products`, …).
  final String active;

  /// Page body.
  final Widget child;

  /// Whether to render the full multi-column footer (home + about) or the
  /// slim variant (shop / dashboard pages).
  final bool footerFull;

  /// Wrap the body in vertical padding for pages whose first element
  /// isn't already padded.
  final bool padBody;

  /// Wrap the body in a SingleChildScrollView (default true).
  final bool scrollable;

  @override
  Widget build(BuildContext context) {
    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (padBody)
          Padding(padding: const EdgeInsets.symmetric(vertical: 40), child: child)
        else
          child,
        SiteFooter(full: footerFull),
      ],
    );
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: HeaderNav(active: active),
      body: scrollable
          ? SingleChildScrollView(
              child: body,
            )
          : body,
      floatingActionButton: const WhatsAppFab(),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}
