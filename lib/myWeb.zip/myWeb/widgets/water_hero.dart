import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// Animated water-blob backdrop. Mirrors the canvas animation from
/// `water-hero.jsx` — a few drifting radial-gradient blobs with a
/// subtle drift cycle. Cheap to run on web (one CustomPainter, repaints
/// at ~60fps).
class WaterHero extends StatefulWidget {
  const WaterHero({super.key, this.height = 540, this.child});

  final double height;
  final Widget? child;

  @override
  State<WaterHero> createState() => _WaterHeroState();
}

class _WaterHeroState extends State<WaterHero>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 32),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SizedBox(
      height: widget.height,
      width: double.infinity,
      child: Stack(
        fit: StackFit.expand,
        children: [
          AnimatedBuilder(
            animation: _ctrl,
            builder: (context, _) => CustomPaint(
              painter: _BlobPainter(
                t: _ctrl.value,
                dark: isDark,
              ),
            ),
          ),
          if (widget.child != null) widget.child!,
        ],
      ),
    );
  }
}

class _BlobPainter extends CustomPainter {
  _BlobPainter({required this.t, required this.dark});
  final double t;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    // Base wash.
    final bgPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: dark
            ? const [PwtColors.darkBg, Color(0xFF0A1822)]
            : const [PwtColors.lightBg, Color(0xFFE7F2F8)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // 3 drifting blobs.
    for (var i = 0; i < 3; i++) {
      final phase = t * 2 * math.pi + i * 2.094; // 2π/3
      final cx = size.width * (0.3 + 0.4 * (0.5 + 0.5 * math.sin(phase * 0.7 + i)));
      final cy = size.height * (0.4 + 0.3 * (0.5 + 0.5 * math.cos(phase * 0.5 + i * 1.7)));
      final r = math.min(size.width, size.height) * (0.32 + 0.06 * math.sin(phase * 0.9));
      final hue = dark ? 0xFF3FB6F6 : 0xFFBEE6FA;
      final blobPaint = Paint()
        ..shader = RadialGradient(
          colors: [
            Color(hue).withValues(alpha: dark ? 0.32 : 0.45),
            Color(hue).withValues(alpha: 0),
          ],
          stops: const [0.0, 1.0],
        ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r))
        ..blendMode = BlendMode.screen;
      canvas.drawCircle(Offset(cx, cy), r, blobPaint);
    }

    // Subtle horizontal lines (echo of the original site's grid feel).
    final linePaint = Paint()
      ..color = (dark ? Colors.white : Colors.black).withValues(alpha: 0.04)
      ..strokeWidth = 1;
    const lineCount = 8;
    for (var i = 0; i < lineCount; i++) {
      final y = (size.height / (lineCount - 1)) * i;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
  }

  @override
  bool shouldRepaint(_BlobPainter oldDelegate) =>
      oldDelegate.t != t || oldDelegate.dark != dark;
}
