import 'package:flutter/material.dart';

import '../i18n.dart';
import '../theme.dart';

/// Two-option segmented pill switch. Used as `AudienceSwitch` (Individual /
/// Business) on the hero and `PayTypeSwitch` (Buy / Rent) in the cart.
class PillSwitch<T> extends StatelessWidget {
  const PillSwitch({
    super.key,
    required this.value,
    required this.options,
    required this.onChanged,
    this.compact = false,
  });

  final T value;
  final List<PillOption<T>> options;
  final ValueChanged<T> onChanged;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final pad = compact ? const EdgeInsets.all(3) : const EdgeInsets.all(4);
    final radius = compact ? 99.0 : 99.0;
    return Container(
      padding: pad,
      decoration: BoxDecoration(
        color: isDark ? PwtColors.darkBg1 : Colors.white,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: isDark ? PwtColors.darkLine : PwtColors.lightLine,
          width: 1,
        ),
      ),
      child: IntrinsicWidth(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: options.map((opt) {
            final selected = opt.value == value;
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onChanged(opt.value),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.symmetric(
                  horizontal: compact ? 12 : 18,
                  vertical: compact ? 8 : 12,
                ),
                decoration: BoxDecoration(
                  color: selected ? scheme.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(radius),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (opt.icon != null) ...[
                      Icon(
                        opt.icon,
                        size: compact ? 14 : 16,
                        color: selected ? scheme.onPrimary : scheme.onSurface,
                      ),
                      SizedBox(width: compact ? 6 : 8),
                    ],
                    Text(
                      opt.label,
                      style: TextStyle(
                        fontSize: compact ? 13 : 14,
                        fontWeight: FontWeight.w500,
                        color: selected ? scheme.onPrimary : scheme.onSurface,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class PillOption<T> {
  const PillOption({required this.value, required this.label, this.icon});
  final T value;
  final String label;
  final IconData? icon;
}

/// Audience switch — convenience wrapper around [PillSwitch].
class AudienceSwitch extends StatelessWidget {
  const AudienceSwitch({super.key, required this.value, required this.onChanged});
  final String value;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return PillSwitch<String>(
      value: value,
      onChanged: onChanged,
      options: [
        PillOption(value: 'individual', label: context.t('aud.individual'), icon: Icons.home_outlined),
        PillOption(value: 'business', label: context.t('aud.business'), icon: Icons.business_center_outlined),
      ],
    );
  }
}

/// Buy / Rent switch — used in cart + checkout.
class PayTypeSwitch extends StatelessWidget {
  const PayTypeSwitch({super.key, required this.value, required this.onChanged, this.compact = false});
  final String value;
  final ValueChanged<String> onChanged;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return PillSwitch<String>(
      value: value,
      onChanged: onChanged,
      compact: compact,
      options: [
        PillOption(value: 'purchase', label: context.t('common.buy'), icon: Icons.shopping_bag_outlined),
        PillOption(value: 'rental', label: context.t('common.rent'), icon: Icons.event_repeat_outlined),
      ],
    );
  }
}
