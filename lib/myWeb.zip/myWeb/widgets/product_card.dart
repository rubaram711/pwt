import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../Models/Products/products_model.dart';
import '../data/products.dart';
import '../i18n.dart';
import '../state/app_state.dart';
import '../state/cart_store.dart';
import '../theme.dart';
import '../utils.dart';
import 'common.dart';

/// Product card used in the home product slider and the products catalogue.
class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.item});

  final ProductModel item;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () {
        // Drop the product id into the route so deep-links can land directly
        // on a specific model. The page handles the param.
        context.go('/products.html?id=${item.id}');
      },
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Theme.of(context).dividerColor,
            width: 1,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Image — uses a gradient placeholder backdrop like the site.
            AspectRatio(
              aspectRatio: 4 / 3,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: Theme.of(context).brightness == Brightness.dark
                        ? const [PwtColors.darkBg1, PwtColors.darkBg2]
                        : const [PwtColors.lightBg1, PwtColors.lightBg2],
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Image.network(
                    item.primaryImageUrl??'',
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined, size: 64),
                  ),
                ),
              ),
            ),
            // Body.
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MonoTag(item.code!.toUpperCase()),
                  const SizedBox(height: 8),
                  Text(
                    item.name??"",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w500,
                          letterSpacing: -0.01,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.shortDescription??'',
                    style: Theme.of(context).textTheme.bodyMedium,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 18),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AedPrice(value: item.prices),
                      if (item.startingPrice != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: scheme.primary,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(
                            '${item.discount}% ${context.t('products.discount')}',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5,
                              color: scheme.onPrimary,
                            ),
                          ),
                        ),
                      ],
                      const Spacer(),
                      FilledButton.tonal(
                        onPressed: () async {
                          final cart = AppState.instance.cart;
                          await cart.add(CartItem(
                            id: item.id.toString(),
                            name: item.name??'',
                            price: double.parse(item.startingPrice!.amount),
                            img: item.primaryImageUrl,
                            payType: cart.payType,
                          ));
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('${context.t('cart.added')} · ${item.name}'),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        },
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
                        ),
                        child: Text(context.t('common.add_to_cart')),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Horizontally-scrolling product strip — mirrors the hero slider on the
/// React build but renders as a simple scrollable strip (carousel chrome
/// is overkill once you can swipe natively).
class ProductStrip extends StatelessWidget {
  const ProductStrip({super.key, this.items});
  final List<CatalogueItem>? items;

  @override
  Widget build(BuildContext context) {
    final list = items ?? catalogue;
    final w = MediaQuery.of(context).size.width;
    final cardW = w < 640 ? w - 64 : 360.0;
    return SizedBox(
      height: 480,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 32),
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(width: 18),
        itemBuilder: (context, i) =>
            SizedBox(width: cardW,
                // child: ProductCard(item: list[i])
            ),
      ),
    );
  }
}
