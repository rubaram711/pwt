import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme.dart';
import 'common.dart';

/// "Five stages between the tap and your glass" — the vertical pipe
/// diagram with a droplet that flows down through 5 numbered nodes,
/// shifting hue from red to green. 1:1 port of the `Tech` section in
/// `app.jsx`.
///
/// The droplet animates from the top of the pipe to the bottom over
/// `5.5s`, loops forever, and crossfades between five accent colors so
/// each stage visibly "purifies" it. Hover (or tap) any stage on the
/// right to make its node light up and pulse in the diagram.
class TechDiagram extends StatefulWidget {
  const TechDiagram({super.key});

  @override
  State<TechDiagram> createState() => _TechDiagramState();
}

class _TechDiagramState extends State<TechDiagram>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  int _active = 2;

  static const _stages = <_Stage>[
    _Stage(
      n: '01',
      t: 'Sediment Filter',
      d: 'Reduces dirt, rust, silt, and pipe residue down to 5 microns.',
      removes: 'DIRT · RUST\nSILT',
    ),
    _Stage(
      n: '02',
      t: 'Carbon Block',
      d: 'Removes lead, chlorine, chemicals, and the solvents you smell '
          'before you taste them.',
      removes: 'LEAD · CHLORINE\nCHEMICALS',
    ),
    _Stage(
      n: '03',
      t: 'Reverse Osmosis',
      d: '0.0001-micron membrane reduces TDS, dissolved metals, and arsenic. '
          'The workhorse of the system.',
      removes: 'TDS · METALS\nARSENIC',
    ),
    _Stage(
      n: '04',
      t: 'Activated Carbon Polish',
      d: 'A granular activated carbon pass that polishes water for great '
          'taste.',
      removes: 'TASTE\nPOLISH',
    ),
    _Stage(
      n: '05',
      t: 'Boost™ Remineralization',
      d: 'Adds back calcium, magnesium, and electrolytes that make water '
          'taste like water.',
      removes: '+ Ca · Mg · K\nELECTROLYTES',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      duration: const Duration(milliseconds: 5500),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: sectionHorizPaddingFor(context),
      child: MaxWidth(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const MonoTag('// INSIDE EVERY UNIT'),
            const SizedBox(height: 14),
            Text(
              'Five stages between the tap and your glass.',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    fontWeight: FontWeight.w300,
                    height: 1.08,
                  ),
            ),
            const SizedBox(height: 18),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Text(
                'Each PWT unit puts every drop through a sealed five-stage '
                'purification path. Hover any stage to see what it removes.',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
            const SizedBox(height: 40),
            LayoutBuilder(builder: (context, c) {
              final wide = c.maxWidth >= 760;
              final visual = SizedBox(
                width: wide ? 320 : c.maxWidth,
                height: wide ? 620 : 520,
                child: _Diagram(
                  controller: _c,
                  active: _active,
                  stages: _stages,
                  isDark: isDark,
                ),
              );
              final list = Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (var i = 0; i < _stages.length; i++)
                    _StageRow(
                      stage: _stages[i],
                      active: i == _active,
                      onHover: () => setState(() => _active = i),
                    ),
                ],
              );
              if (wide) {
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    visual,
                    const SizedBox(width: 36),
                    Expanded(child: list),
                  ],
                );
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: visual),
                  const SizedBox(height: 28),
                  list,
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _Stage {
  const _Stage({
    required this.n,
    required this.t,
    required this.d,
    required this.removes,
  });
  final String n;
  final String t;
  final String d;
  final String removes;
}

class _Diagram extends StatelessWidget {
  const _Diagram({
    required this.controller,
    required this.active,
    required this.stages,
    required this.isDark,
  });
  final AnimationController controller;
  final int active;
  final List<_Stage> stages;
  final bool isDark;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return CustomPaint(
          painter: _DiagramPainter(
            t: controller.value,
            active: active,
            count: stages.length,
            accent: PwtColors.accent,
            accentDeep: PwtColors.accentDeep,
            accentPale: PwtColors.accentPale,
            nodeBg: isDark ? PwtColors.darkBg1 : Colors.white,
            border: isDark ? PwtColors.darkLine : PwtColors.lightLine,
          ),
          child: Stack(
            children: [
              for (var i = 0; i < stages.length; i++)
                _nodeLabel(context, i, stages[i].n),
              Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 12, bottom: 4),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .cardTheme
                          .color
                          ?.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Theme.of(context).dividerColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '// STAGE ${stages[active].n}',
                          style: TextStyle(
                            color: PwtColors.accent,
                            fontFamily: 'GeistMono',
                            fontFamilyFallback: const ['monospace'],
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          stages[active].t,
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// A small numeric label that sits ON the node circle. The painter draws
  /// the circle itself; this widget only renders the text so it can use
  /// the app's font without re-running text layout inside the painter.
  Widget _nodeLabel(BuildContext context, int i, String n) {
    return LayoutBuilder(builder: (context, c) {
      final cy = 80.0 + i * 110.0;
      final h = c.maxHeight > 0 ? c.maxHeight : 600.0;
      final w = c.maxWidth > 0 ? c.maxWidth : 320.0;
      // Painter uses a 400×600 viewBox; translate to our box.
      final px = (200 / 400) * w;
      final py = (cy / 600) * h;
      final isActive = i == active;
      return Positioned(
        left: px - 22,
        top: py - 12,
        width: 44,
        height: 24,
        child: Center(
          child: Text(
            n,
            style: TextStyle(
              color: isActive ? Colors.white : PwtColors.accent,
              fontFamily: 'GeistMono',
              fontFamilyFallback: const ['monospace'],
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    });
  }
}

class _DiagramPainter extends CustomPainter {
  _DiagramPainter({
    required this.t,
    required this.active,
    required this.count,
    required this.accent,
    required this.accentDeep,
    required this.accentPale,
    required this.nodeBg,
    required this.border,
  });

  final double t; // 0..1
  final int active;
  final int count;
  final Color accent;
  final Color accentDeep;
  final Color accentPale;
  final Color nodeBg;
  final Color border;

  // 400×600 viewBox to match the original SVG.
  static const _vbW = 400.0;
  static const _vbH = 600.0;

  Offset _scale(Offset p, Size s) =>
      Offset(p.dx * s.width / _vbW, p.dy * s.height / _vbH);

  @override
  void paint(Canvas canvas, Size s) {
    final sxr = s.width / _vbW;
    final syr = s.height / _vbH;
    final unit = (sxr + syr) / 2;

    // Pipe spine — vertical gradient from pale → accent → deep, low alpha
    final pipeRect = Rect.fromLTWH(
      195 * sxr,
      40 * syr,
      10 * sxr,
      520 * syr,
    );
    final pipePaint = Paint()
      ..shader = ui.Gradient.linear(
        pipeRect.topCenter,
        pipeRect.bottomCenter,
        [
          accentPale.withValues(alpha: 0.06),
          accent.withValues(alpha: 0.55),
          accentDeep.withValues(alpha: 0.30),
        ],
        const [0.0, 0.5, 1.0],
      );
    canvas.drawRRect(
      RRect.fromRectAndRadius(pipeRect, Radius.circular(5 * unit)),
      pipePaint,
    );

    // Stage nodes — fill if active, otherwise just an outlined ring.
    for (var i = 0; i < count; i++) {
      final cy = 80.0 + i * 110.0;
      final center = _scale(const Offset(200, 0), s).translate(0, cy * syr);
      final isActive = i == active;
      final r = (isActive ? 36.0 : 28.0) * unit;

      if (isActive) {
        // Soft outer glow.
        canvas.drawCircle(
          center,
          r * 1.4,
          Paint()
            ..color = accent.withValues(alpha: 0.30)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
        );
        canvas.drawCircle(
          center,
          r,
          Paint()..color = accent,
        );
      } else {
        canvas.drawCircle(
          center,
          r,
          Paint()..color = nodeBg,
        );
        canvas.drawCircle(
          center,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5 * unit
            ..color = accent,
        );
      }
    }

    // Output tail
    final tailPath = Path()
      ..moveTo(200 * sxr, 560 * syr)
      ..quadraticBezierTo(200 * sxr, 580 * syr, 220 * sxr, 590 * syr)
      ..lineTo(240 * sxr, 590 * syr);
    canvas.drawPath(
      tailPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2 * unit
        ..color = accent.withValues(alpha: 0.45),
    );
    canvas.drawCircle(
      _scale(const Offset(248, 590), s),
      4 * unit,
      Paint()..color = accent,
    );

    // Droplet — animates from top (y=40) to bottom (y=560), shifting hue
    // from red → orange → yellow → light green → green.
    final dy = 40 + (560 - 40) * t;
    final dropletCenter = _scale(Offset(200, dy), s);
    final color = _dropletColor(t);
    final opacity = _dropletOpacity(t);

    // Glow trail
    canvas.drawCircle(
      dropletCenter,
      12 * unit,
      Paint()
        ..color = color.withValues(alpha: 0.45 * opacity)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawCircle(
      dropletCenter,
      7 * unit,
      Paint()..color = color.withValues(alpha: opacity),
    );
  }

  /// Mirrors the React `<animate fill ...>` keyframes — six anchor colors,
  /// interpolated linearly by `t`.
  Color _dropletColor(double t) {
    const stops = <double>[0.00, 0.05, 0.25, 0.45, 0.65, 0.82, 0.92, 1.00];
    const colors = <Color>[
      Color(0xFFFF5252),
      Color(0xFFFF5252),
      Color(0xFFFF8A3D),
      Color(0xFFFFD23D),
      Color(0xFF9BE060),
      Color(0xFF3FE07A),
      Color(0xFF1CD07A),
      Color(0xFF1CD07A),
    ];
    for (var i = 1; i < stops.length; i++) {
      if (t <= stops[i]) {
        final span = stops[i] - stops[i - 1];
        final f = span == 0 ? 0.0 : (t - stops[i - 1]) / span;
        return Color.lerp(colors[i - 1], colors[i], f) ?? colors[i];
      }
    }
    return colors.last;
  }

  /// Fade in at start, hold, fade out at end. Same keyTimes as the SVG.
  double _dropletOpacity(double t) {
    const stops = <double>[0, 0.04, 0.2, 0.85, 0.95, 1.0];
    const vals = <double>[0, 1, 1, 1, 0, 0];
    for (var i = 1; i < stops.length; i++) {
      if (t <= stops[i]) {
        final span = stops[i] - stops[i - 1];
        final f = span == 0 ? 0.0 : (t - stops[i - 1]) / span;
        return vals[i - 1] + (vals[i] - vals[i - 1]) * f;
      }
    }
    return 0;
  }

  @override
  bool shouldRepaint(covariant _DiagramPainter old) =>
      old.t != t || old.active != active;
}

class _StageRow extends StatelessWidget {
  const _StageRow({
    required this.stage,
    required this.active,
    required this.onHover,
  });
  final _Stage stage;
  final bool active;
  final VoidCallback onHover;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return MouseRegion(
      onEnter: (_) => onHover(),
      child: GestureDetector(
        onTap: onHover,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            color: active
                ? scheme.primary.withValues(alpha: 0.08)
                : Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: active
                  ? scheme.primary.withValues(alpha: 0.55)
                  : Theme.of(context).dividerColor,
              width: 1,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 44,
                child: Text(
                  stage.n,
                  style: TextStyle(
                    color: scheme.primary,
                    fontFamily: 'GeistMono',
                    fontFamilyFallback: const ['monospace'],
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      stage.t,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      stage.d,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 130),
                child: Text(
                  stage.removes,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: 'GeistMono',
                    fontFamilyFallback: const ['monospace'],
                    fontSize: 10,
                    color: scheme.primary.withValues(alpha: 0.78),
                    height: 1.5,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
