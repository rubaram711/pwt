import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../theme.dart';
import 'cart_drawer.dart';
import 'common.dart';

/// Top navigation — sticky AppBar-style header. Mirrors `HeaderNav` in
/// `header.jsx`: logo + primary links + theme/lang toggles + cart + user
/// menu. On narrow screens the primary links collapse into a burger.
class HeaderNav extends StatefulWidget implements PreferredSizeWidget {
  const HeaderNav({super.key, this.active = 'home'});
  final String active;

  static const double _height = 72;

  @override
  Size get preferredSize => const Size.fromHeight(_height);

  @override
  State<HeaderNav> createState() => _HeaderNavState();
}

class _HeaderNavState extends State<HeaderNav> {
  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final w = MediaQuery.of(context).size.width;
        final compact = w < 880;
        return Container(
          decoration: BoxDecoration(
            color: (isDark ? PwtColors.darkBg : PwtColors.lightBg)
                .withValues(alpha: 0.78),
            border: Border(
              bottom: BorderSide(color: Theme.of(context).dividerColor, width: 1),
            ),
          ),
          height: HeaderNav._height,
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: MaxWidth(
                child: Row(
                  children: [
                    // Logo.
                    InkWell(
                      onTap: () => context.go('/'),
                      borderRadius: BorderRadius.circular(8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image.asset(
                            'assets/pwt-logo.png',
                            width: 32,
                            height: 32,
                            errorBuilder: (_, __, ___) =>
                                const Icon(Icons.water_drop_outlined, size: 32),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'PWT',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.4,
                                ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    // Primary nav (desktop).
                    if (!compact) _PrimaryNav(active: widget.active),
                    if (!compact) const SizedBox(width: 12),
                    // Actions.
                    _HeaderActions(compact: compact),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _PrimaryNav extends StatelessWidget {
  const _PrimaryNav({required this.active});
  final String active;

  @override
  Widget build(BuildContext context) {
    final entries = <(String, String, String)>[
      ('home', context.t('nav.home'), '/'),
      ('products', context.t('nav.products'), '/products.html'),
      ('about', context.t('nav.about'), '/about.html'),
      ('contact', context.t('nav.contact'), '/contact.html'),
    ];
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: entries.map((e) {
        final selected = e.$1 == active;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: TextButton(
            onPressed: () => context.go(e.$3),
            style: TextButton.styleFrom(
              foregroundColor: selected
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).textTheme.bodyMedium?.color,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            child: Text(
              e.$2,
              style: TextStyle(
                fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _HeaderActions extends StatelessWidget {
  const _HeaderActions({required this.compact});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final isDark = state.isDark;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Lang toggle.
        _IconChip(
          tooltip: state.locale.languageCode == 'en' ? 'العربية' : 'English',
          onTap: () => state.toggleLocale(),
          child: Text(
            state.locale.languageCode == 'en' ? 'ع' : 'EN',
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
          ),
        ),
        const SizedBox(width: 6),
        _IconChip(
          tooltip: isDark ? 'Light mode' : 'Dark mode',
          onTap: () => state.toggleTheme(),
          child: Icon(isDark ? Icons.dark_mode_outlined : Icons.light_mode_outlined, size: 18),
        ),
        const SizedBox(width: 6),
        // Cart.
        Stack(
          clipBehavior: Clip.none,
          children: [
            _IconChip(
              tooltip: context.t('nav.cart'),
              onTap: () => showCartDrawer(context),
              child: const Icon(Icons.shopping_bag_outlined, size: 18),
            ),
            if (state.cart.count > 0)
              Positioned(
                top: -4,
                right: -4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    '${state.cart.count}',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).colorScheme.onPrimary,
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(width: 10),
        // User menu (or guest).
        _UserMenu(),
        if (compact) ...[
          const SizedBox(width: 6),
          _IconChip(
            tooltip: 'Menu',
            onTap: () => _openMobileMenu(context),
            child: const Icon(Icons.menu, size: 20),
          ),
        ],
      ],
    );
  }

  void _openMobileMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.home_outlined),
              title: Text(context.t('nav.home')),
              onTap: () { Navigator.pop(context); context.go('/'); },
            ),
            ListTile(
              leading: const Icon(Icons.inventory_2_outlined),
              title: Text(context.t('nav.products')),
              onTap: () { Navigator.pop(context); context.go('/products.html'); },
            ),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: Text(context.t('nav.about')),
              onTap: () { Navigator.pop(context); context.go('/about.html'); },
            ),
            ListTile(
              leading: const Icon(Icons.mail_outline),
              title: Text(context.t('nav.contact')),
              onTap: () { Navigator.pop(context); context.go('/contact.html'); },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.login),
              title: Text(context.t('nav.login')),
              onTap: () { Navigator.pop(context); context.go('/login.html'); },
            ),
          ],
        ),
      ),
    );
  }
}

class _IconChip extends StatelessWidget {
  const _IconChip({required this.child, required this.onTap, this.tooltip});
  final Widget child;
  final VoidCallback onTap;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final btn = InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 36,
        height: 36,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(context).dividerColor, width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: child,
      ),
    );
    return tooltip != null ? Tooltip(message: tooltip!, child: btn) : btn;
  }
}

class _UserMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = AppState.instance.auth.user;
    if (user == null) {
      return _IconChip(
        tooltip: context.t('nav.login'),
        onTap: () => context.go('/login.html'),
        child: const Icon(Icons.person_outline, size: 18),
      );
    }
    return PopupMenuButton<String>(
      tooltip: user.name,
      offset: const Offset(0, 44),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Theme.of(context).dividerColor),
      ),
      color: Theme.of(context).cardTheme.color,
      onSelected: (key) async {
        switch (key) {
          case 'profile':
            context.go('/profile.html');
          case 'orders':
            context.go('/orders.html');
          case 'account':
            context.go('/account.html');
          case 'logout':
            await AppState.instance.auth.logout();
            if (context.mounted) context.go('/');
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem<String>(
          enabled: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(user.name, style: Theme.of(context).textTheme.titleMedium),
              Text(user.email, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(value: 'profile', child: Row(children: [
          const Icon(Icons.person_outline, size: 16),
          const SizedBox(width: 10),
          Text(user.isBusiness ? context.t('nav.dashboard') : context.t('nav.my_profile')),
        ])),
        if (!user.isBusiness)
          PopupMenuItem(value: 'orders', child: Row(children: [
            const Icon(Icons.inventory_2_outlined, size: 16),
            const SizedBox(width: 10),
            Text(context.t('nav.orders')),
          ])),
        if (!user.isBusiness)
          PopupMenuItem(value: 'account', child: Row(children: [
            const Icon(Icons.settings_outlined, size: 16),
            const SizedBox(width: 10),
            Text(context.t('nav.account_settings')),
          ])),
        const PopupMenuDivider(),
        PopupMenuItem(value: 'logout', child: Row(children: [
          const Icon(Icons.logout, size: 16),
          const SizedBox(width: 10),
          Text(context.t('nav.logout')),
        ])),
      ],
      child: Container(
        width: 36,
        height: 36,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text(
          _initials(user.name),
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 0.4,
          ),
        ),
      ),
    );
  }

  static String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    return parts.take(2).map((p) => p.isEmpty ? '' : p[0]).join().toUpperCase();
  }
}
