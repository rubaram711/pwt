/// Non-web stub for [openUrl] — does nothing. Replaced by the web variant
/// via conditional import in `whatsapp_fab.dart`.
void openUrl(String url) {
  // Intentionally empty: this project targets Flutter Web only.
}
