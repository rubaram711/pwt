import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../data/products.dart';
import '../i18n.dart';
import '../theme.dart';
import 'common.dart';

/// Brand art panel on the login page — auto-rotating product carousel
/// with cross-fade, captions, dot indicator, ripple rings, and floating
/// particles. 1:1 port of `LoginArt` in `login.html`.
class LoginCarousel extends StatefulWidget {
  const LoginCarousel({super.key});

  @override
  State<LoginCarousel> createState() => _LoginCarouselState();
}

class _LoginCarouselState extends State<LoginCarousel>
    with TickerProviderStateMixin {
  late final List<CatalogueItem> _items = catalogue;
  int _idx = 0;
  int _prev = 0;
  Timer? _timer;

  late final AnimationController _ripple;
  late final AnimationController _particles;
  late final List<_Particle> _particleSpecs;

  @override
  void initState() {
    super.initState();
    _ripple = AnimationController(
      duration: const Duration(seconds: 6),
      vsync: this,
    )..repeat();
    _particles = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    )..repeat();

    final rng = math.Random(42);
    _particleSpecs = List.generate(14, (i) {
      return _Particle(
        leftPct: 8 + rng.nextDouble() * 84,
        startBottomPct: -10 + rng.nextDouble() * 30,
        size: 4 + rng.nextDouble() * 10,
        delay: rng.nextDouble(),
        durScale: 0.85 + rng.nextDouble() * 0.75,
      );
    });

    _timer = Timer.periodic(const Duration(milliseconds: 3400), (_) {
      if (!mounted) return;
      setState(() {
        _prev = _idx;
        _idx = (_idx + 1) % _items.length;
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ripple.dispose();
    _particles.dispose();
    super.dispose();
  }

  void _setIdx(int i) {
    setState(() {
      _prev = _idx;
      _idx = i;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isDark
                ? const [Color(0xFF14283A), Color(0xFF0A1722)]
                : const [Color(0xFFEFF6FA), Color(0xFFDCE9F1)],
          ),
        ),
        child: Stack(
          children: [
            // Ambient blobs + animated ripple rings
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _ripple,
                builder: (context, _) => CustomPaint(
                  painter: _BackdropPainter(
                    t: _ripple.value,
                    isDark: isDark,
                  ),
                ),
              ),
            ),

            // Mono tagline top-left
            Positioned(
              top: 28,
              left: 28,
              child: MonoTag(
                context.t('login.tagline'),
                size: 11,
                color: isDark
                    ? PwtColors.accentPale.withValues(alpha: 0.85)
                    : PwtColors.accentDeep,
              ),
            ),

            // Product slide stage
            Positioned(
              top: 90,
              bottom: 140,
              left: 32,
              right: 32,
              child: ClipRect(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    for (var i = 0; i < _items.length; i++)
                      _SlideLayer(
                        key: ValueKey('s-${_items[i].id}'),
                        item: _items[i],
                        state: i == _idx
                            ? _SlideState.on
                            : (i == _prev
                                ? _SlideState.prev
                                : _SlideState.off),
                      ),
                  ],
                ),
              ),
            ),

            // Caption — name + tag, cross-fade between products
            Positioned(
              left: 28,
              right: 28,
              bottom: 64,
              height: 68,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 520),
                switchInCurve: Curves.easeOutCubic,
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.12),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: Column(
                  key: ValueKey('cap-${_items[_idx].id}'),
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _items[_idx].name,
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                            fontSize: 32,
                            color: isDark
                                ? const Color(0xFFF2F7FB)
                                : const Color(0xFF1A2632),
                          ),
                    ),
                    const SizedBox(height: 6),
                    MonoTag(
                      _items[_idx].tag.toUpperCase(),
                      size: 11,
                      color: isDark
                          ? PwtColors.accentPale.withValues(alpha: 0.8)
                          : PwtColors.accentDeep.withValues(alpha: 0.8),
                    ),
                  ],
                ),
              ),
            ),

            // Dot indicator
            Positioned(
              left: 28,
              bottom: 26,
              child: Row(
                children: [
                  for (var i = 0; i < _items.length; i++)
                    GestureDetector(
                      onTap: () => _setIdx(i),
                      behavior: HitTestBehavior.opaque,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 360),
                        curve: Curves.easeOutCubic,
                        width: i == _idx ? 28 : 8,
                        height: 8,
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          color: i == _idx
                              ? (isDark
                                  ? PwtColors.accent
                                  : PwtColors.accentDeep)
                              : (isDark
                                  ? Colors.white.withValues(alpha: 0.32)
                                  : PwtColors.accentDeep
                                      .withValues(alpha: 0.32)),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Floating particles
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _particles,
                  builder: (context, _) => LayoutBuilder(
                    builder: (context, c) => Stack(
                      children: [
                        for (final p in _particleSpecs)
                          _particleDot(p, c.maxWidth, c.maxHeight, isDark),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _particleDot(_Particle p, double w, double h, bool isDark) {
    // Each particle floats up 200px over its (8s × durScale) cycle.
    final raw = (_particles.value + p.delay) % 1.0;
    final t = raw; // 0..1
    final lifePos = t; // start at 0 (bottom), end at 1 (top)
    final y = h * (p.startBottomPct / 100) + lifePos * 200;
    final bottomY = h - y;
    final scale = 1 + lifePos * 0.2;
    double op;
    if (t < 0.15) {
      op = (t / 0.15) * 0.6;
    } else if (t < 0.85) {
      op = 0.6 - (t - 0.15) / 0.70 * 0.3;
    } else {
      op = 0.3 * (1 - (t - 0.85) / 0.15);
    }
    return Positioned(
      left: (p.leftPct / 100) * w - p.size / 2,
      bottom: bottomY,
      child: Opacity(
        opacity: op.clamp(0.0, 1.0),
        child: Transform.scale(
          scale: scale,
          child: Container(
            width: p.size,
            height: p.size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isDark
                  ? PwtColors.accent.withValues(alpha: 0.7)
                  : PwtColors.accentDeep.withValues(alpha: 0.55),
            ),
          ),
        ),
      ),
    );
  }
}

class _Particle {
  _Particle({
    required this.leftPct,
    required this.startBottomPct,
    required this.size,
    required this.delay,
    required this.durScale,
  });
  final double leftPct;
  final double startBottomPct;
  final double size;
  final double delay;
  final double durScale;
}

enum _SlideState { on, prev, off }

class _SlideLayer extends StatelessWidget {
  const _SlideLayer({super.key, required this.item, required this.state});
  final CatalogueItem item;
  final _SlideState state;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final on = state == _SlideState.on;
    final prev = state == _SlideState.prev;
    final dx = on ? 0.0 : (prev ? -80.0 : 80.0);
    final scale = on ? 1.0 : 0.9;
    final opacity = on ? 1.0 : 0.0;

    return AnimatedOpacity(
      duration: const Duration(milliseconds: 720),
      curve: Curves.easeOutCubic,
      opacity: opacity,
      child: AnimatedSlide(
        duration: const Duration(milliseconds: 880),
        curve: Curves.easeOutCubic,
        offset: Offset(dx / 200, 0),
        child: AnimatedScale(
          duration: const Duration(milliseconds: 880),
          curve: Curves.easeOutCubic,
          scale: scale,
          child: IgnorePointer(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: isDark
                            ? Colors.black.withValues(alpha: 0.55)
                            : PwtColors.accentDeep.withValues(alpha: 0.18),
                        blurRadius: 50,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Image.asset(
                    item.img,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => SizedBox(
                      width: 220,
                      height: 320,
                      child: Container(
                        decoration: BoxDecoration(
                          color: PwtColors.accent.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Center(
                          child: Icon(Icons.water_drop_outlined, size: 64),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Ambient gradient blobs + 4 expanding ripple rings, drawn behind the
/// product carousel. Animation drives ring radius + opacity oscillation.
class _BackdropPainter extends CustomPainter {
  _BackdropPainter({required this.t, required this.isDark});
  final double t;
  final bool isDark;

  @override
  void paint(Canvas canvas, Size s) {
    final blobBase = isDark
        ? const [
            Color(0x80277FBA),
            Color(0x66174D78),
            Color(0x4D2D6A95),
          ]
        : const [
            Color(0x6691CFE8),
            Color(0x66B2DAEF),
            Color(0x4CD9ECF5),
          ];

    // Three soft blurred blobs.
    final blobs = <_Blob>[
      _Blob(s.width * 0.25, s.height * 0.22, s.width * 0.55, s.height * 0.40,
          blobBase[0]),
      _Blob(s.width * 0.78, s.height * 0.78, s.width * 0.60, s.height * 0.42,
          blobBase[1]),
      _Blob(s.width * 0.55, s.height * 0.55, s.width * 0.50, s.height * 0.36,
          blobBase[2]),
    ];

    for (final b in blobs) {
      final paint = Paint()
        ..shader = ui.Gradient.radial(
          Offset(b.cx, b.cy),
          math.max(b.rx, b.ry),
          [b.color, b.color.withValues(alpha: 0)],
        )
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40);
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(b.cx, b.cy),
          width: b.rx * 2,
          height: b.ry * 2,
        ),
        paint,
      );
    }

    // Ripple rings emanating from a center point.
    final cx = s.width * 0.5;
    final cy = s.height * 0.55;
    for (var i = 0; i < 4; i++) {
      final phase = (t + i * 0.25) % 1.0;
      // Each ring grows from r=80+i*70 to r=150+i*70 then snaps back; we
      // mimic that with a triangle-wave on phase.
      final tri = phase < 0.5 ? phase * 2 : (1 - phase) * 2;
      final r0 = (80 + i * 70).toDouble();
      final r1 = (150 + i * 70).toDouble();
      final r = r0 + (r1 - r0) * tri;
      final baseAlpha = (0.5 - i * 0.1) * 0.4; // damped overall
      final alpha = baseAlpha * (1 - tri.abs());
      final ringColor = (isDark ? PwtColors.accent : PwtColors.accentDeep)
          .withValues(alpha: alpha.clamp(0.0, 0.5));
      canvas.drawCircle(
        Offset(cx, cy),
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.0
          ..color = ringColor,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BackdropPainter old) =>
      old.t != t || old.isDark != isDark;
}

class _Blob {
  _Blob(this.cx, this.cy, this.rx, this.ry, this.color);
  final double cx, cy, rx, ry;
  final Color color;
}
