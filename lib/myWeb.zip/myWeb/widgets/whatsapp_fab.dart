import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

import 'whatsapp_launcher_io.dart'
    if (dart.library.html) 'whatsapp_launcher_web.dart' as launcher;

/// Floating WhatsApp launcher — bottom-end of every page. Replaces
/// `whatsapp-float.js` from the React build. Implemented as a
/// FloatingActionButton positioned by the pages' Scaffold so it sits on
/// top of any scrollable content.
class WhatsAppFab extends StatelessWidget {
  const WhatsAppFab({super.key, this.phone = '971500000000'});
  final String phone;

  static const Color brandGreen = Color(0xFF25D366);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      heroTag: 'whatsapp-fab',
      onPressed: () => launcher.openUrl('https://wa.me/$phone'),
      backgroundColor: brandGreen,
      foregroundColor: Colors.white,
      elevation: 4,
      tooltip: 'WhatsApp',
      shape: const CircleBorder(),
      child: const Icon(Icons.chat_bubble_outline, size: 24),
    );
  }
}

bool get isFlutterWeb => kIsWeb;
