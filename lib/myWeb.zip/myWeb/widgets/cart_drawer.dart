import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../state/cart_store.dart';
import '../theme.dart';
import '../utils.dart';
import 'common.dart';
import 'pill_switch.dart';

/// Shows the cart as an end-side drawer / right sheet.
void showCartDrawer(BuildContext context) {
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Cart',
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (context, anim, secondary) {
      final w = MediaQuery.of(context).size.width;
      final sheetW = w < 480 ? w : 420.0;
      final isRtl = AppState.instance.isRtl;
      return Align(
        alignment: isRtl ? Alignment.centerLeft : Alignment.centerRight,
        child: Material(
          color: Theme.of(context).scaffoldBackgroundColor,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Theme.of(context).dividerColor),
          ),
          child: SizedBox(
            width: sheetW,
            height: double.infinity,
            child: SafeArea(child: _CartContent()),
          ),
        ),
      );
    },
    transitionBuilder: (context, anim, secondary, child) {
      final isRtl = AppState.instance.isRtl;
      final offset = Tween<Offset>(
        begin: Offset(isRtl ? -1 : 1, 0),
        end: Offset.zero,
      ).chain(CurveTween(curve: Curves.easeOutCubic)).animate(anim);
      return SlideTransition(position: offset, child: child);
    },
  );
}

class _CartContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance.cart,
      builder: (context, _) {
        final cart = AppState.instance.cart;
        return Column(
          children: [
            // Header.
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 12, 12),
              child: Row(
                children: [
                  Text(context.t('cart.title'),
                      style: Theme.of(context).textTheme.titleLarge),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, size: 20),
                  ),
                ],
              ),
            ),
            // Pay type switch.
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: PayTypeSwitch(
                  value: cart.payType,
                  compact: true,
                  onChanged: (v) => cart.setPayType(v),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Divider(height: 1),
            // Items.
            Expanded(
              child: cart.isEmpty ? _empty(context) : _list(context, cart),
            ),
            if (!cart.isEmpty) ...[
              const Divider(height: 1),
              _summary(context, cart),
            ],
          ],
        );
      },
    );
  }

  Widget _empty(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.shopping_bag_outlined, size: 48, color: PwtColors.darkFgFaint),
            const SizedBox(height: 16),
            Text(context.t('cart.empty'), style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(context.t('cart.empty_sub'),
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop();
                context.go('/products.html');
              },
              child: Text(context.t('cart.browse')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _list(BuildContext context, CartStore cart) {
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      itemCount: cart.items.length,
      separatorBuilder: (_, __) => const Divider(height: 24),
      itemBuilder: (context, i) {
        final item = cart.items[i];
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: Theme.of(context).cardTheme.color,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              padding: const EdgeInsets.all(6),
              child: item.img != null
                  ? Image.asset(item.img!, fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined))
                  : const Icon(Icons.water_drop_outlined),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  AedPrice(
                    value: item.price ?? 'Quote',
                    style: Theme.of(context).textTheme.bodyMedium,
                    suffix: cart.payType == 'rental' ? '/ mo' : null,
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    _QtyControl(
                      qty: item.qty,
                      onMinus: () => cart.updateQty(item.id, item.qty - 1),
                      onPlus: () => cart.updateQty(item.id, item.qty + 1),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => cart.remove(item.id),
                      child: Text(context.t('cart.remove')),
                    ),
                  ]),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _summary(BuildContext context, CartStore cart) {
    final isRental = cart.payType == 'rental';
    final monthly = cart.items.fold<num>(
        0,
        (s, it) => s + (it.price != null ? monthlyOf(it.price!) * it.qty : 0));
    final shown = isRental ? monthly : cart.subtotal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Text(context.t('cart.subtotal'),
                  style: Theme.of(context).textTheme.bodyMedium),
              const Spacer(),
              AedPrice(
                value: shown,
                style: Theme.of(context).textTheme.titleLarge,
                suffix: isRental ? '/ mo' : null,
              ),
            ],
          ),
          const SizedBox(height: 10),
          MonoTag(context.t('cart.free_warranty'), size: 10),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.go('/checkout.html');
            },
            child: Text(context.t('cart.checkout')),
          ),
        ],
      ),
    );
  }
}

class _QtyControl extends StatelessWidget {
  const _QtyControl({required this.qty, required this.onMinus, required this.onPlus});
  final int qty;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).dividerColor),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(
          onPressed: onMinus,
          icon: const Icon(Icons.remove, size: 14),
          padding: const EdgeInsets.all(4),
          constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Text('$qty', style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
        IconButton(
          onPressed: onPlus,
          icon: const Icon(Icons.add, size: 14),
          padding: const EdgeInsets.all(4),
          constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
        ),
      ]),
    );
  }
}
