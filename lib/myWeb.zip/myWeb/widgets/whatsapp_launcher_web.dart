import 'dart:html' as html;

/// Web implementation of [openUrl] — opens [url] in a new tab.
void openUrl(String url) {
  html.window.open(url, '_blank');
}
