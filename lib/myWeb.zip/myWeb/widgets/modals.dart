import 'package:flutter/material.dart';

import '../i18n.dart';
import '../state/app_state.dart';

/// Modal: schedule maintenance for a specific device.
/// Mirrors `ScheduleModal` in `indiv-profile.jsx`. Simple form: pick a date
/// + time slot + describe the issue. The original used a full calendar
/// widget; we use Flutter's native `showDatePicker`.
Future<bool?> showScheduleMaintenanceModal(
  BuildContext context, {
  required Map<String, dynamic> device,
}) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => _ScheduleDialog(device: device, isBusiness: false),
  );
}

/// Modal: request maintenance, business flavour. Same shape, lets the user
/// pick which device + a free-text issue.
Future<bool?> showBusinessMaintenanceModal(
  BuildContext context,
) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => const _ScheduleDialog(device: null, isBusiness: true),
  );
}

class _ScheduleDialog extends StatefulWidget {
  const _ScheduleDialog({required this.device, required this.isBusiness});
  final Map<String, dynamic>? device;
  final bool isBusiness;

  @override
  State<_ScheduleDialog> createState() => _ScheduleDialogState();
}

class _ScheduleDialogState extends State<_ScheduleDialog> {
  String _issue = 'filter';
  String _description = '';
  DateTime? _date;
  String _slot = '10:00 – 12:00';
  String? _deviceId;
  bool _busy = false;

  static const _slots = [
    '08:00 – 10:00',
    '10:00 – 12:00',
    '13:00 – 15:00',
    '15:00 – 17:00',
  ];

  static const _issues = [
    ('filter', 'maint.issue_filter'),
    ('slow', 'maint.issue_slow'),
    ('leak', 'maint.issue_leak'),
    ('display', 'maint.issue_display'),
    ('temp', 'maint.issue_temp'),
    ('inspect', 'maint.issue_inspect'),
    ('other', 'maint.issue_other'),
  ];

  @override
  void initState() {
    super.initState();
    _deviceId = widget.device?['id'] as String?;
    // Default to 5 days from now.
    _date = DateTime.now().add(const Duration(days: 5));
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    final state = AppState.instance;
    final devices = widget.isBusiness ? state.biz.devices : state.indiv.devices;
    final device = devices.firstWhere(
      (d) => d['id'] == _deviceId,
      orElse: () => devices.isNotEmpty ? devices.first : <String, dynamic>{},
    );
    final isoDate = _date == null
        ? null
        : '${_date!.year}-${_date!.month.toString().padLeft(2, '0')}-${_date!.day.toString().padLeft(2, '0')}';

    final req = <String, dynamic>{
      'id': 'M-${DateTime.now().millisecondsSinceEpoch}',
      'deviceId': device['id'],
      'deviceModel': device['model'],
      'deviceLocation': device['location'],
      'requestedAt': DateTime.now().millisecondsSinceEpoch,
      'scheduledDate': isoDate,
      'scheduledSlot': _slot,
      'issue': _issueLabel(),
      'description': _description,
      'status': 'scheduled',
    };
    if (widget.isBusiness) {
      await state.biz.addMaintenance(req);
    } else {
      await state.indiv.addMaintenance(req);
    }
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  String _issueLabel() {
    final entry = _issues.firstWhere((e) => e.$1 == _issue,
        orElse: () => ('other', 'maint.issue_other'));
    return tr(entry.$2);
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final devices = widget.isBusiness ? state.biz.devices : state.indiv.devices;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(context.t('maint.title')),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (widget.isBusiness && devices.isNotEmpty)
                DropdownButtonFormField<String>(
                  initialValue: _deviceId ?? devices.first['id'] as String,
                  decoration: InputDecoration(labelText: context.t('maint.device')),
                  items: devices
                      .map((d) => DropdownMenuItem<String>(
                            value: d['id'] as String,
                            child: Text('${d['model']} · ${d['location']}'),
                          ))
                      .toList(),
                  onChanged: (v) => setState(() => _deviceId = v),
                ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _issue,
                decoration:
                    InputDecoration(labelText: context.t('maint.issue_type')),
                items: _issues
                    .map((e) => DropdownMenuItem(
                          value: e.$1,
                          child: Text(tr(e.$2)),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _issue = v ?? 'filter'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                decoration: InputDecoration(
                  labelText: context.t('maint.description'),
                  hintText: context.t('maint.desc_placeholder'),
                ),
                maxLines: 3,
                onChanged: (v) => _description = v,
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: InputDecorator(
                    decoration: InputDecoration(
                      labelText: context.t('maint.preferred'),
                    ),
                    child: GestureDetector(
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: _date ?? DateTime.now().add(const Duration(days: 5)),
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (picked != null) setState(() => _date = picked);
                      },
                      child: Text(
                        _date == null
                            ? '—'
                            : '${_date!.year}-${_date!.month.toString().padLeft(2, '0')}-${_date!.day.toString().padLeft(2, '0')}',
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _slot,
                    decoration: InputDecoration(labelText: context.t('maint.slot')),
                    items: _slots
                        .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                        .toList(),
                    onChanged: (v) => setState(() => _slot = v ?? _slots[1]),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: Text(context.t('common.cancel')),
        ),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: _busy
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(context.t('maint.submit')),
        ),
      ],
    );
  }
}

// ─── Add payment method ──────────────────────────────────────────────────

Future<bool?> showAddPaymentModal(BuildContext context) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => const _AddPaymentDialog(),
  );
}

class _AddPaymentDialog extends StatefulWidget {
  const _AddPaymentDialog();
  @override
  State<_AddPaymentDialog> createState() => _AddPaymentDialogState();
}

class _AddPaymentDialogState extends State<_AddPaymentDialog> {
  final _holder = TextEditingController();
  final _number = TextEditingController();
  final _exp = TextEditingController();
  final _cvc = TextEditingController();
  bool _makeDefault = true;
  bool _busy = false;

  @override
  void dispose() {
    _holder.dispose();
    _number.dispose();
    _exp.dispose();
    _cvc.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final number = _number.text.replaceAll(RegExp(r'\s+'), '');
    if (number.length < 4) return;
    setState(() => _busy = true);

    final brand = number.startsWith('4')
        ? 'visa'
        : number.startsWith('5') || number.startsWith('2')
            ? 'mastercard'
            : 'card';
    final exp = _exp.text.split('/');
    final pm = {
      'id': 'pm-${DateTime.now().millisecondsSinceEpoch}',
      'brand': brand,
      'last4': number.substring(number.length - 4),
      'expMonth': int.tryParse(exp.first.trim()) ?? 12,
      'expYear': exp.length > 1 ? int.tryParse(exp[1].trim()) ?? 28 : 28,
      'holder': _holder.text.trim().isEmpty ? 'PWT Member' : _holder.text.trim(),
      'isDefault': _makeDefault,
    };
    await AppState.instance.biz.addPayment(pm);
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(context.t('payment.add')),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _holder,
                decoration: InputDecoration(labelText: context.t('payment.holder')),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _number,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: context.t('payment.number'),
                  hintText: '4242 4242 4242 4242',
                ),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: TextFormField(
                    controller: _exp,
                    decoration: InputDecoration(
                      labelText: context.t('payment.exp'),
                      hintText: '12/28',
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _cvc,
                    decoration: InputDecoration(labelText: context.t('payment.cvc')),
                    obscureText: true,
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(context.t('payment.make_default')),
                value: _makeDefault,
                onChanged: (v) => setState(() => _makeDefault = v ?? false),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: Text(context.t('common.cancel')),
        ),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: Text(context.t('payment.save')),
        ),
      ],
    );
  }
}
