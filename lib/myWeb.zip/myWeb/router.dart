import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'pages/about_page.dart';
import 'pages/account_page.dart';
import 'pages/checkout_page.dart';
import 'pages/contact_page.dart';
import 'pages/home_page.dart';
import 'pages/login_page.dart';
import 'pages/not_found_page.dart';
import 'pages/order_detail_page.dart';
import 'pages/orders_page.dart';
import 'pages/products_page.dart';
import 'pages/profile_page.dart';

/// SPA routing. Paths match the original site's `*.html` filenames so old
/// bookmarks keep working when the site is deployed at the root.
class PwtRouter {
  PwtRouter._();

  static final GoRouter config = GoRouter(
    initialLocation: '/',
    errorBuilder: (context, state) => const NotFoundPage(),
    routes: [
      GoRoute(path: '/', builder: (_, __) => const HomePage()),
      GoRoute(path: '/PWT Homepage.html', builder: (_, __) => const HomePage()),
      GoRoute(path: '/about.html', builder: (_, __) => const AboutPage()),
      GoRoute(path: '/products.html', builder: (_, __) => const ProductsPage()),
      GoRoute(path: '/contact.html', builder: (_, __) => const ContactPage()),
      GoRoute(path: '/login.html', builder: (_, __) => const LoginPage()),
      GoRoute(path: '/account.html', builder: (_, __) => const AccountPage()),
      GoRoute(path: '/profile.html', builder: (_, __) => const ProfilePage()),
      GoRoute(path: '/orders.html', builder: (_, __) => const OrdersPage()),
      GoRoute(
        path: '/order.html',
        builder: (context, state) {
          final id = state.uri.queryParameters['id'] ?? '';
          return OrderDetailPage(orderId: id);
        },
      ),
      GoRoute(path: '/checkout.html', builder: (_, __) => const CheckoutPage()),
    ],
  );
}
