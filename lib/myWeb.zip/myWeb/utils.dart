import 'package:intl/intl.dart';

import 'state/app_state.dart';

/// Format a timestamp / DateTime as a localised date. Mirrors `fmtDate` /
/// `fmtIDate` in the React project.
String fmtDate(Object? value,
    {bool short = true, bool weekday = false, bool yearOnly = false}) {
  if (value == null) return '—';
  DateTime? d;
  if (value is num) {
    d = DateTime.fromMillisecondsSinceEpoch(value.toInt());
  } else if (value is String) {
    final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})$').firstMatch(value);
    if (m != null) {
      d = DateTime(int.parse(m[1]!), int.parse(m[2]!), int.parse(m[3]!));
    } else {
      d = DateTime.tryParse(value);
    }
  } else if (value is DateTime) {
    d = value;
  }
  if (d == null) return '—';

  final lang = AppState.instance.locale.languageCode;
  if (yearOnly) return DateFormat.yMMM(lang).format(d);
  if (weekday) return DateFormat('EEE, MMM d, y', lang).format(d);
  return DateFormat(short ? 'MMM d, y' : 'MMMM d, y', lang).format(d);
}

/// Days remaining until [ts] (negative if overdue).
int daysUntil(int ts) =>
    ((ts - DateTime.now().millisecondsSinceEpoch) / 86400000).round();

/// Relative-date label (Today / 5 days ago / 3 mo ago / 2y ago).
String relDate(int ts) {
  final diff =
      (DateTime.now().millisecondsSinceEpoch - ts) / 86400000;
  if (diff < 1) return 'Today';
  if (diff < 30) return '${diff.floor()} days ago';
  if (diff < 365) return '${(diff / 30).floor()} mo ago';
  return '${(diff / 365).floor()}y ago';
}

/// Comma-format an integer with locale-aware digits.
String fmtThousands(num value) {
  final lang = AppState.instance.locale.languageCode;
  return NumberFormat.decimalPattern(lang).format(value);
}

/// AED price formatter — mirrors `fmtPrice` in `data.jsx`. Returns the raw
/// string for non-numeric prices ("Quote").
String fmtPrice(Object value) {
  if (value is num) return 'AED ${fmtThousands(value)}';
  return value.toString();
}

/// Rental factor calibrated against the seed ops data (PW90 1890 → ~280/mo).
const double rentFactor = 0.148;

/// Compute monthly rental price for a buy price. Rounded to nearest 5.
int monthlyOf(num buyPrice) =>
    ((buyPrice * rentFactor) / 5).round() * 5;
