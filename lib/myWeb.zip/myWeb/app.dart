// import 'package:flutter/material.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';
//
// import 'router.dart';
// import 'state/app_state.dart';
// import 'theme.dart';
//
// /// Root MaterialApp.router. Listens to [AppState] so theme + language
// /// changes rebuild the whole tree.
// class PwtApp extends StatelessWidget {
//   const PwtApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     final state = AppState.instance;
//     return ListenableBuilder(
//       listenable: state,
//       builder: (context, _) {
//         return MaterialApp.router(
//           title: 'PWT — Better water, by design',
//           debugShowCheckedModeBanner: false,
//           themeMode: state.themeMode,
//           theme: PwtTheme.light(),
//           darkTheme: PwtTheme.dark(),
//           locale: state.locale,
//           supportedLocales: const [Locale('en'), Locale('ar')],
//           localizationsDelegates: const [
//             GlobalMaterialLocalizations.delegate,
//             GlobalWidgetsLocalizations.delegate,
//             GlobalCupertinoLocalizations.delegate,
//           ],
//           routerConfig: PwtRouter.config,
//           builder: (context, child) {
//             // Force Directionality based on locale (RTL for Arabic).
//             return Directionality(
//               textDirection:
//                   state.locale.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
//               child: child ?? const SizedBox.shrink(),
//             );
//           },
//         );
//       },
//     );
//   }
// }
