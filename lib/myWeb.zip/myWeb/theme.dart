import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Brand palette + typography. Values lifted from the React project's
/// `styles.css` (the `:root` and `[data-theme="…"]` blocks) and translated
/// from `oklch(...)` to Material's HSL/sRGB approximations. They won't be
/// byte-identical to the CSS site — Flutter renders to canvas with no
/// access to the original CSS — but they share the same brand DNA:
/// deep cool-blue base + sky-blue accent.
class PwtColors {
  PwtColors._();

  // Accent (same across themes; deeper variant in light mode).
  static const accent = Color(0xFF3FB6F6);
  static const accentDeep = Color(0xFF1B7FBA);
  static const accentPale = Color(0xFFBEE6FA);

  // Dark theme surfaces.
  static const darkBg = Color(0xFF0D1F2D);
  static const darkBg1 = Color(0xFF132737);
  static const darkBg2 = Color(0xFF1A3146);
  static const darkLine = Color(0x66415A72);
  static const darkLineSoft = Color(0x2E415A72);
  static const darkFg = Color(0xFFF2F7FB);
  static const darkFgDim = Color(0xFFB9C8D4);
  static const darkFgFaint = Color(0xFF7C8E9D);

  // Light theme surfaces.
  static const lightBg = Color(0xFFF8FAFB);
  static const lightBg1 = Color(0xFFF1F4F6);
  static const lightBg2 = Color(0xFFE5EAEE);
  static const lightLine = Color(0xB3B6C0C9);
  static const lightLineSoft = Color(0x66B6C0C9);
  static const lightFg = Color(0xFF1A2632);
  static const lightFgDim = Color(0xFF4A5B6B);
  static const lightFgFaint = Color(0xFF74848F);

  // Semantic.
  static const good = Color(0xFF38B981);
  static const warn = Color(0xFFE8B842);
  static const bad = Color(0xFFE96B5C);
}

/// Theme builder. The mono accent and Geist typography come from the
/// original site; everything else is Material 3 defaults retuned to our
/// surfaces so widgets out-of-the-box look on-brand.
class PwtTheme {
  PwtTheme._();

  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    return _common(base, isDark: false).copyWith(
      scaffoldBackgroundColor: PwtColors.lightBg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: PwtColors.accentDeep,
        brightness: Brightness.light,
        primary: PwtColors.accentDeep,
        onPrimary: Colors.white,
        surface: PwtColors.lightBg,
        onSurface: PwtColors.lightFg,
      ),
      dividerColor: PwtColors.lightLine,
    );
  }

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    return _common(base, isDark: true).copyWith(
      scaffoldBackgroundColor: PwtColors.darkBg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: PwtColors.accent,
        brightness: Brightness.dark,
        primary: PwtColors.accent,
        onPrimary: const Color(0xFF001827),
        surface: PwtColors.darkBg,
        onSurface: PwtColors.darkFg,
      ),
      dividerColor: PwtColors.darkLine,
    );
  }

  static ThemeData _common(ThemeData base, {required bool isDark}) {
    final fg = isDark ? PwtColors.darkFg : PwtColors.lightFg;
    final fgDim = isDark ? PwtColors.darkFgDim : PwtColors.lightFgDim;
    final fgFaint = isDark ? PwtColors.darkFgFaint : PwtColors.lightFgFaint;

    // Geist + Geist Mono via the runtime lookup. We compose the TextTheme
    // by hand using `GoogleFonts.getFont(name)` (which IS public API in
    // every google_fonts release ≥ 5) so we don't depend on whichever
    // version added a generated `geistTextTheme()` accessor.
    TextStyle geist({double? size, FontWeight? weight, Color? color, double? height, double? letterSpacing}) {
      try {
        return GoogleFonts.getFont(
          'Geist',
          fontSize: size,
          fontWeight: weight,
          color: color,
          height: height,
          letterSpacing: letterSpacing,
        );
      } catch (_) {
        // If google_fonts can't resolve the family, fall back to system.
        return TextStyle(
          fontSize: size,
          fontWeight: weight,
          color: color,
          height: height,
          letterSpacing: letterSpacing,
        );
      }
    }

    TextStyle geistMono({double? size, FontWeight? weight, Color? color, double? letterSpacing}) {
      try {
        return GoogleFonts.getFont(
          'Geist Mono',
          fontSize: size,
          fontWeight: weight,
          color: color,
          letterSpacing: letterSpacing,
        );
      } catch (_) {
        return TextStyle(
          fontSize: size,
          fontWeight: weight,
          color: color,
          letterSpacing: letterSpacing,
          fontFamily: 'monospace',
        );
      }
    }

    return base.copyWith(
      textTheme: base.textTheme.copyWith(
        displayLarge: geist(size: 80, weight: FontWeight.w300, color: fg, height: 1.02, letterSpacing: -0.02),
        displayMedium: geist(size: 60, weight: FontWeight.w300, color: fg, height: 1.04, letterSpacing: -0.02),
        displaySmall: geist(size: 44, weight: FontWeight.w300, color: fg, height: 1.06, letterSpacing: -0.01),
        headlineLarge: geist(size: 36, weight: FontWeight.w400, color: fg, height: 1.1),
        headlineMedium: geist(size: 28, weight: FontWeight.w400, color: fg, height: 1.15),
        headlineSmall: geist(size: 22, weight: FontWeight.w500, color: fg, height: 1.2),
        titleLarge: geist(size: 19, weight: FontWeight.w500, color: fg),
        titleMedium: geist(size: 16, weight: FontWeight.w500, color: fg),
        titleSmall: geist(size: 14, weight: FontWeight.w500, color: fgDim),
        bodyLarge: geist(size: 16, weight: FontWeight.w400, color: fg, height: 1.5),
        bodyMedium: geist(size: 14, weight: FontWeight.w400, color: fgDim, height: 1.5),
        bodySmall: geist(size: 12, weight: FontWeight.w400, color: fgFaint, height: 1.4),
        labelLarge: geistMono(size: 13, weight: FontWeight.w500, color: fg, letterSpacing: 0.6),
        labelMedium: geistMono(size: 12, weight: FontWeight.w500, color: fgDim, letterSpacing: 0.5),
        labelSmall: geistMono(size: 11, weight: FontWeight.w500, color: fgFaint, letterSpacing: 0.5),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: isDark ? PwtColors.darkBg : PwtColors.lightBg,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        foregroundColor: fg,
      ),
      cardTheme: CardThemeData(
        color: isDark ? PwtColors.darkBg1 : Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: isDark ? PwtColors.darkLine : PwtColors.lightLine, width: 1),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark ? PwtColors.darkBg1 : Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: isDark ? PwtColors.darkLine : PwtColors.lightLine),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: isDark ? PwtColors.darkLine : PwtColors.lightLine),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: PwtColors.accent, width: 1.6),
        ),
        labelStyle: TextStyle(color: fgDim),
        hintStyle: TextStyle(color: fgFaint),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          backgroundColor: PwtColors.accent,
          foregroundColor: isDark ? const Color(0xFF001827) : Colors.white,
          textStyle: const TextStyle(fontWeight: FontWeight.w500, letterSpacing: 0.2),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          side: BorderSide(color: isDark ? PwtColors.darkLine : PwtColors.lightLine, width: 1.2),
          foregroundColor: fg,
          textStyle: const TextStyle(fontWeight: FontWeight.w500),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: PwtColors.accent,
          textStyle: const TextStyle(fontWeight: FontWeight.w500),
        ),
      ),
      iconTheme: IconThemeData(color: fgDim, size: 20),
      dividerTheme: DividerThemeData(
        color: isDark ? PwtColors.darkLineSoft : PwtColors.lightLineSoft,
        thickness: 1,
        space: 1,
      ),
      drawerTheme: DrawerThemeData(
        backgroundColor: isDark ? PwtColors.darkBg : Colors.white,
        shape: const RoundedRectangleBorder(),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: fg,
        unselectedLabelColor: fgFaint,
        indicatorColor: PwtColors.accent,
        dividerColor: Colors.transparent,
        labelStyle: const TextStyle(fontWeight: FontWeight.w500),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: isDark ? PwtColors.darkBg2 : PwtColors.lightFg,
        contentTextStyle: TextStyle(color: isDark ? PwtColors.darkFg : Colors.white),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

/// Convenience: monospaced "tag" label like `// PWT · POINT-OF-USE WATER`.
TextStyle monoLabel(BuildContext context, {Color? color}) {
  final base = Theme.of(context).textTheme.labelMedium ?? const TextStyle();
  return base.copyWith(
    color: color ?? base.color,
    letterSpacing: 0.6,
    fontWeight: FontWeight.w500,
  );
}
