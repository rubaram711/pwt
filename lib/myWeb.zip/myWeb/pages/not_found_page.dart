import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// 404 page. Mirrors the implicit error route on the React build.
class NotFoundPage extends StatelessWidget {
  const NotFoundPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: SizedBox(
        height: MediaQuery.of(context).size.height - 200,
        child: Center(
          child: MaxWidth(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const MonoTag('// 404'),
                  const SizedBox(height: 20),
                  Text('Page not found',
                      style: Theme.of(context).textTheme.displaySmall),
                  const SizedBox(height: 16),
                  Text(
                    'The page you were looking for has moved or never existed.',
                    style: Theme.of(context).textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: () => context.go('/'),
                    child: const Text('Back to home'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
