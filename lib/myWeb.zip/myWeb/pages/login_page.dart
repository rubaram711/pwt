import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/login_carousel.dart';
import '../widgets/pill_switch.dart';
import '../widgets/pwt_scaffold.dart';

/// Login + signup. Two-pane on wide screens (form + brand art), single
/// column on narrow. Mock auth — accepts any credentials.
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  final _company = TextEditingController();

  bool _isSignup = false;
  String _accountType = 'individual';
  bool _busy = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _company.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _busy = true);
    final auth = AppState.instance.auth;
    if (_accountType == 'business') {
      await auth.loginBusiness(
        email: _email.text.trim(),
        company: _company.text.trim().isEmpty ? 'Acme Holdings' : _company.text.trim(),
        name: _name.text.trim().isNotEmpty ? _name.text.trim() : null,
      );
    } else {
      await auth.loginIndividual(
        email: _email.text.trim(),
        name: _name.text.trim().isNotEmpty ? _name.text.trim() : null,
      );
    }
    if (!mounted) return;
    setState(() => _busy = false);
    context.go(_accountType == 'business' ? '/profile.html' : '/');
  }

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: Padding(
        padding: sectionPaddingFor(context),
        child: MaxWidth(
          child: LayoutBuilder(builder: (context, c) {
            final wide = c.maxWidth >= 1000;
            final form = _formCard(context);
            const art = SizedBox(
              height: 640,
              child: LoginCarousel(),
            );
            if (wide) {
              return Row(
                // crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: form),
                  const SizedBox(width: 28),
                  const Expanded(child: art),
                ],
              );
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [form, const SizedBox(height: 28), art],
            );
          }),
        ),
      ),
    );
  }

  Widget _formCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const MonoTag('// PWT'),
            const SizedBox(height: 16),
            Text(
              _isSignup ? context.t('login.create') : context.t('login.welcome'),
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    fontWeight: FontWeight.w300,
                  ),
            ),
            const SizedBox(height: 8),
            MonoTag(context.t('login.no_creds'), size: 11),
            const SizedBox(height: 22),
            AudienceSwitch(
              value: _accountType,
              onChanged: (v) => setState(() => _accountType = v),
            ),
            const SizedBox(height: 22),
            if (_isSignup) ...[
              TextFormField(
                controller: _name,
                decoration: InputDecoration(labelText: context.t('login.full_name')),
              ),
              const SizedBox(height: 12),
              if (_accountType == 'business') ...[
                TextFormField(
                  controller: _company,
                  decoration: InputDecoration(labelText: context.t('login.company')),
                  validator: (v) =>
                      (v ?? '').trim().isEmpty ? 'Required' : null,
                ),
                const SizedBox(height: 12),
              ],
            ],
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(labelText: context.t('login.email')),
              validator: (v) {
                final s = (v ?? '').trim();
                if (s.isEmpty) return 'Required';
                if (!s.contains('@')) return 'Invalid email';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _password,
              obscureText: true,
              decoration: InputDecoration(labelText: context.t('login.password')),
              validator: (v) =>
                  (v ?? '').isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: _busy ? null : _submit,
              child: _busy
                  ? const SizedBox(
                      height: 18, width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(_isSignup
                      ? (_accountType == 'business'
                          ? context.t('login.create_biz')
                          : context.t('login.create'))
                      : context.t('login.sign_in')),
            ),
            const SizedBox(height: 14),
            Center(
              child: TextButton(
                onPressed: () => setState(() => _isSignup = !_isSignup),
                child: Text(_isSignup
                    ? context.t('login.has_account') + ' ' + context.t('login.sign_in')
                    : context.t('login.no_account') + ' ' + context.t('login.sign_up')),
              ),
            ),
            const SizedBox(height: 4),
            Center(
              child: Text(
                context.t('login.legal'),
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
