import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../state/cart_store.dart';
import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// Multi-step checkout. Mirrors `checkout.html`:
///   1. Sign in (skipped if already authed)
///   2. Shipping address
///   3. Payment OR quote (depending on cart content)
///   4. Review
///   5. Confirmation
///
/// Quote flow kicks in when any cart item has a non-numeric "price"
/// (e.g. S4 Sparkling). Mirrors the React build's branch.
class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  int _step = 0;

  // Form fields.
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _addr1 = TextEditingController();
  final _addr2 = TextEditingController();
  final _city = TextEditingController();
  String _emirate = 'Dubai';
  String? _paymentId;
  String? _orderId;

  static const _emirates = [
    'Abu Dhabi', 'Dubai', 'Sharjah', 'Ajman', 'Umm Al Quwain',
    'Ras Al Khaimah', 'Fujairah',
  ];

  @override
  void initState() {
    super.initState();
    final u = AppState.instance.auth.user;
    if (u != null) {
      _name.text = u.name;
      _email.text = u.email;
      _step = 1; // Skip sign-in.
    }
    _paymentId = AppState.instance.biz.defaultPayment()?['id'] as String?;
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    _addr1.dispose();
    _addr2.dispose();
    _city.dispose();
    super.dispose();
  }

  bool get _isQuote =>
      AppState.instance.cart.items.any((it) => it.price == null);

  Future<void> _placeOrder() async {
    final state = AppState.instance;
    final items = state.cart.items;
    final subtotal = state.cart.subtotal;
    final vat = (subtotal * 0.05).round();
    final order = {
      'id': 'PWT-${DateTime.now().millisecondsSinceEpoch.toRadixString(36).toUpperCase()}',
      'date': DateTime.now().toIso8601String(),
      'purchaseType': state.cart.payType == 'rental' ? 'rental' : 'purchase',
      'items': items.map((it) => it.toMap()).toList(),
      'shipping': {
        'addr1': _addr1.text.trim(),
        'addr2': _addr2.text.trim(),
        'city': _city.text.trim(),
        'emirate': _emirate,
        'phone': _phone.text.trim(),
      },
      'subtotal': subtotal,
      'vat': vat,
      'shippingFee': 0,
      'total': (subtotal + vat).round(),
      'status': 'placed',
      if (_paymentId != null) 'paymentMethodId': _paymentId,
    };
    await state.auth.addOrder(order);
    _orderId = order['id'] as String;
    await state.cart.clear();
    setState(() => _step = 4);
  }

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          if (AppState.instance.cart.isEmpty && _step != 4) {
            return _emptyCart(context);
          }
          return Padding(
            padding: sectionPaddingFor(context),
            child: MaxWidth(
              maxWidth: 1100,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _stepper(context),
                  const SizedBox(height: 28),
                  LayoutBuilder(builder: (context, c) {
                    final wide = c.maxWidth >= 900 && _step != 4;
                    final left = _stepContent(context);
                    final right = _orderSummary(context);
                    if (!wide) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          left,
                          if (_step != 4) ...[
                            const SizedBox(height: 28),
                            right,
                          ],
                        ],
                      );
                    }
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 3, child: left),
                        const SizedBox(width: 28),
                        Expanded(flex: 2, child: right),
                      ],
                    );
                  }),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _emptyCart(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(60),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.shopping_bag_outlined, size: 48),
            const SizedBox(height: 12),
            Text(context.t('cart.empty'),
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => context.go('/products.html'),
              child: Text(context.t('cart.browse')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stepper(BuildContext context) {
    final labels = [
      context.t('checkout.step1'),
      context.t('checkout.step2'),
      _isQuote ? context.t('checkout.quote_title') : context.t('checkout.step3'),
      context.t('checkout.step4'),
      context.t('checkout.step5'),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++) ...[
            _stepDot(i, labels[i]),
            if (i < labels.length - 1)
              SizedBox(
                width: 32,
                child: Divider(
                  color: i < _step
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).dividerColor,
                  thickness: 1.4,
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _stepDot(int idx, String label) {
    final active = idx <= _step;
    final color = active
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).dividerColor;
    return Row(
      children: [
        Container(
          width: 24, height: 24,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: idx < _step ? color : Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(color: color, width: 1.4),
          ),
          child: idx < _step
              ? Icon(Icons.check, size: 14,
                  color: Theme.of(context).colorScheme.onPrimary)
              : Text('${idx + 1}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: color,
                  )),
        ),
        const SizedBox(width: 8),
        Text(label,
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: active
                  ? Theme.of(context).textTheme.bodyLarge?.color
                  : Theme.of(context).textTheme.bodySmall?.color,
            )),
      ],
    );
  }

  Widget _stepContent(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: switch (_step) {
        0 => _signInStep(context),
        1 => _shippingStep(context),
        2 => _isQuote ? _quoteStep(context) : _paymentStep(context),
        3 => _reviewStep(context),
        4 => _confirmationStep(context),
        _ => const SizedBox.shrink(),
      },
    );
  }

  Widget _signInStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.t('login.welcome'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        MonoTag(context.t('login.no_creds'), size: 11),
        const SizedBox(height: 18),
        TextField(
          controller: _email,
          decoration: InputDecoration(labelText: context.t('login.email')),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _name,
          decoration: const InputDecoration(labelText: 'Name'),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: () async {
            if (_email.text.isEmpty) return;
            await AppState.instance.auth.loginIndividual(
              email: _email.text.trim(),
              name: _name.text.trim().isEmpty ? null : _name.text.trim(),
            );
            setState(() => _step = 1);
          },
          child: Text(context.t('common.continue')),
        ),
      ],
    );
  }

  Widget _shippingStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.t('checkout.shipping_addr'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 14),
        TextField(
          controller: _name,
          decoration: const InputDecoration(labelText: 'Contact name'),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Phone'),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _addr1,
          decoration: InputDecoration(labelText: context.t('checkout.address_line1')),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _addr2,
          decoration: InputDecoration(labelText: context.t('checkout.address_line2')),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _city,
              decoration: InputDecoration(labelText: context.t('checkout.city')),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: DropdownButtonFormField<String>(
              initialValue: _emirate,
              decoration:
                  InputDecoration(labelText: context.t('checkout.emirate')),
              items: _emirates
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => setState(() => _emirate = v ?? 'Dubai'),
            ),
          ),
        ]),
        const SizedBox(height: 18),
        _navRow(
          onBack: () => setState(() => _step = 0),
          onNext: () {
            if (_addr1.text.isEmpty || _city.text.isEmpty) return;
            setState(() => _step = 2);
          },
        ),
      ],
    );
  }

  Widget _quoteStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.t('checkout.quote_title'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Text(context.t('checkout.quote_sub'),
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: _placeOrder,
          child: Text(context.t('checkout.submit_quote')),
        ),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () => setState(() => _step = 1),
          child: Text(context.t('common.back')),
        ),
      ],
    );
  }

  Widget _paymentStep(BuildContext context) {
    final payments = AppState.instance.biz.payments;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.t('payment.title'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 14),
        if (payments.isEmpty)
          EmptyState(
            title: context.t('payment.empty_title'),
            subtitle: context.t('payment.empty_desc'),
            icon: Icons.credit_card_outlined,
          )
        else
          for (final p in payments) ...[
            RadioListTile<String>(
              value: p['id'] as String,
              groupValue: _paymentId,
              onChanged: (v) => setState(() => _paymentId = v),
              activeColor: Theme.of(context).colorScheme.primary,
              title: Text('${(p['brand'] as String? ?? '').toUpperCase()} •••• ${p['last4']}'),
              subtitle: Text('Exp ${p['expMonth']}/${p['expYear']} · ${p['holder']}'),
            ),
          ],
        const SizedBox(height: 18),
        _navRow(
          onBack: () => setState(() => _step = 1),
          onNext: payments.isEmpty ? null : () => setState(() => _step = 3),
        ),
      ],
    );
  }

  Widget _reviewStep(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.t('checkout.review_title'),
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 14),
        ListenableBuilder(
          listenable: AppState.instance.cart,
          builder: (context, _) {
            final items = AppState.instance.cart.items;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: items
                  .map((it) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(children: [
                          Expanded(
                              child: Text('${it.name} × ${it.qty}',
                                  style:
                                      Theme.of(context).textTheme.bodyMedium)),
                          AedPrice(value: it.price ?? 'Quote'),
                        ]),
                      ))
                  .toList(),
            );
          },
        ),
        const Divider(height: 28),
        Text('Shipping to', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 6),
        Text(
          '${_name.text} · ${_addr1.text}, ${_city.text}, $_emirate',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 18),
        _navRow(
          onBack: () => setState(() => _step = 2),
          onNextLabel: context.t('checkout.place_order'),
          onNext: _placeOrder,
        ),
      ],
    );
  }

  Widget _confirmationStep(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.check,
                color: Theme.of(context).colorScheme.onPrimary, size: 28),
          ),
          const SizedBox(height: 16),
          Text(context.t('checkout.thanks'),
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(context.t('checkout.thanks_sub'),
              style: Theme.of(context).textTheme.bodyLarge,
              textAlign: TextAlign.center),
          const SizedBox(height: 18),
          if (_orderId != null) MonoTag('// ORDER · $_orderId', size: 11),
          const SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton(
                onPressed: () => context.go('/'),
                child: const Text('Back to home'),
              ),
              const SizedBox(width: 12),
              FilledButton(
                onPressed: () =>
                    context.go('/order.html?id=${_orderId ?? ''}'),
                child: Text(context.t('order.title')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _navRow({
    VoidCallback? onBack,
    VoidCallback? onNext,
    String? onNextLabel,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextButton(
          onPressed: onBack,
          child: Text(context.t('common.back')),
        ),
        FilledButton(
          onPressed: onNext,
          child: Text(onNextLabel ?? context.t('common.continue')),
        ),
      ],
    );
  }

  Widget _orderSummary(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance.cart,
      builder: (context, _) {
        final cart = AppState.instance.cart;
        final vat = (cart.subtotal * 0.05).round();
        return Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MonoTag('// ${context.t('cart.title').toUpperCase()}', size: 11),
              const SizedBox(height: 14),
              for (final it in cart.items) ...[
                Row(children: [
                  Expanded(
                      child: Text('${it.name} × ${it.qty}',
                          style: Theme.of(context).textTheme.bodyMedium)),
                  AedPrice(value: it.price ?? 'Quote'),
                ]),
                const SizedBox(height: 8),
              ],
              const Divider(height: 24),
              Row(children: [
                Text(context.t('cart.subtotal'),
                    style: Theme.of(context).textTheme.bodyMedium),
                const Spacer(),
                AedPrice(value: cart.subtotal),
              ]),
              const SizedBox(height: 6),
              Row(children: [
                Text(context.t('order.vat'),
                    style: Theme.of(context).textTheme.bodyMedium),
                const Spacer(),
                AedPrice(value: vat),
              ]),
              const SizedBox(height: 6),
              Row(children: [
                Text(context.t('order.shipping_fee'),
                    style: Theme.of(context).textTheme.bodyMedium),
                const Spacer(),
                Text(context.t('order.free'),
                    style: Theme.of(context).textTheme.bodyMedium),
              ]),
              const Divider(height: 24),
              Row(children: [
                Text(context.t('order.total'),
                    style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                AedPrice(
                  value: cart.subtotal + vat,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ]),
            ],
          ),
        );
      },
    );
  }
}
