import 'package:flutter/material.dart';

import '../../Backend/Products/get_products.dart';
import '../../Models/Products/products_model.dart';
import '../data/products.dart';
import '../i18n.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/product_card.dart';
import '../widgets/pwt_scaffold.dart';

/// Products catalogue page. Mirrors `products.html` — a grid of all five
/// units with their tag, price, description and discount badge.
class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  // bool isLoading = true;
  //
  // List<ProductModel> products = [];
  //
  // String? error;
  //
  // @override
  // void initState() {
  //   super.initState();
  //   loadProducts();
  // }
  //
  // Future<void> loadProducts() async {
  //
  //   setState(() {
  //     isLoading = true;
  //     error = null;
  //   });
  //
  //   final response = await getProducts();
  //
  //   if (response.success) {
  //
  //     products = response.data?.items ?? [];
  //
  //   } else {
  //
  //     error = response.message;
  //
  //   }
  //
  //   setState(() {
  //     isLoading = false;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    // if (isLoading) {
    //   return const Center(
    //     child: CircularProgressIndicator(),
    //   );
    // }
    // if (error != null) {
    //   return Center(
    //     child: Text(error!),
    //   );
    // }
    return PwtScaffold(
      active: 'products',
      child: Padding(
        padding: sectionPaddingFor(context),
        child: MaxWidth(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const MonoTag('// CATALOGUE'),
              const SizedBox(height: 16),
              DisplayHeadline(context.t('products.title')),
              const SizedBox(height: 16),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Text(
                  context.t('products.sub'),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
              const SizedBox(height: 40),
              LayoutBuilder(builder: (context, c) {
                final cols = c.maxWidth >= 1100
                    ? 3
                    : (c.maxWidth >= 720 ? 2 : 1);
                const gap = 20.0;
                final cardW = (c.maxWidth - gap * (cols - 1)) / cols;
                return Wrap(
                  spacing: gap,
                  runSpacing: gap,
                  children: AppState.instance.products.products
                      .map((p) =>
                          SizedBox(width: cardW, child: ProductCard(item: p)))
                      .toList(),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
