import 'package:flutter/material.dart';

import '../i18n.dart';
import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// Contact page — form (name / email / phone / message) + contact details.
class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _message = TextEditingController();
  bool _submitted = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    _message.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      setState(() => _submitted = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'contact',
      child: Padding(
        padding: sectionPaddingFor(context),
        child: MaxWidth(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const MonoTag('// CONTACT'),
              const SizedBox(height: 18),
              DisplayHeadline(context.t('contact.title')),
              const SizedBox(height: 18),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Text(
                  context.t('contact.sub'),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
              const SizedBox(height: 40),
              LayoutBuilder(builder: (context, c) {
                final wide = c.maxWidth >= 880;
                final form = _form(context);
                final details = _details(context);
                if (wide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 3, child: form),
                      const SizedBox(width: 32),
                      Expanded(flex: 2, child: details),
                    ],
                  );
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [form, const SizedBox(height: 32), details],
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _form(BuildContext context) {
    if (_submitted) {
      return Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.4)),
        ),
        child: Row(
          children: [
            Icon(Icons.check_circle_outline, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(context.t('contact.thanks'), style: Theme.of(context).textTheme.titleMedium)),
          ],
        ),
      );
    }
    return Form(
      key: _formKey,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _field(context, _name, context.t('contact.form.name'),
                validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null),
            const SizedBox(height: 14),
            _field(context, _email, context.t('contact.form.email'),
                keyboardType: TextInputType.emailAddress,
                validator: (v) {
                  final s = (v ?? '').trim();
                  if (s.isEmpty) return 'Required';
                  if (!s.contains('@')) return 'Invalid email';
                  return null;
                }),
            const SizedBox(height: 14),
            _field(context, _phone, context.t('contact.form.phone'),
                keyboardType: TextInputType.phone),
            const SizedBox(height: 14),
            _field(context, _message, context.t('contact.form.message'),
                maxLines: 5,
                validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: _submit,
              child: Text(context.t('contact.form.submit')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _details(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _DetailRow(icon: Icons.location_on_outlined, label: 'Office', value: 'Al Quoz, Dubai · UAE'),
          SizedBox(height: 18),
          _DetailRow(icon: Icons.phone_outlined, label: 'Support', value: '+971 4 400 0000'),
          SizedBox(height: 18),
          _DetailRow(icon: Icons.mail_outline, label: 'Email', value: 'hello@pwt.ae'),
          SizedBox(height: 18),
          _DetailRow(icon: Icons.schedule_outlined, label: 'Hours', value: 'Sun – Thu, 9:00 – 18:00'),
        ],
      ),
    );
  }

  Widget _field(BuildContext context, TextEditingController c, String label,
      {int maxLines = 1,
      TextInputType? keyboardType,
      String? Function(String?)? validator}) {
    return TextFormField(
      controller: c,
      maxLines: maxLines,
      keyboardType: keyboardType,
      validator: validator,
      decoration: InputDecoration(labelText: label),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MonoTag(label.toUpperCase(), size: 10),
              const SizedBox(height: 4),
              Text(value, style: Theme.of(context).textTheme.bodyLarge),
            ],
          ),
        ),
      ],
    );
  }
}
