import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../utils.dart';
import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// Orders list — auth-gated, shows the signed-in user's order history.
class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final user = AppState.instance.auth.user;
          if (user == null) return _authGate(context);
          if (user.isBusiness) {
            // Business users see orders inside the dashboard.
            Future.microtask(() => context.go('/profile.html'));
            return const SizedBox.shrink();
          }
          final orders = AppState.instance.auth.getOrders();
          return Padding(
            padding: sectionPaddingFor(context),
            child: MaxWidth(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MonoTag('// ORDERS'),
                  const SizedBox(height: 18),
                  DisplayHeadline(context.t('nav.orders')),
                  const SizedBox(height: 32),
                  if (orders.isEmpty)
                    EmptyState(
                      title: context.t('dash.empty_orders_title'),
                      subtitle: context.t('dash.empty_orders_desc'),
                      icon: Icons.inbox_outlined,
                    )
                  else
                    Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardTheme.color,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Theme.of(context).dividerColor),
                      ),
                      child: Column(
                        children: [
                          for (var i = 0; i < orders.length; i++) ...[
                            _OrderRow(order: orders[i]),
                            if (i < orders.length - 1)
                              Divider(height: 1, color: Theme.of(context).dividerColor),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _authGate(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(60),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_outline, size: 40),
            const SizedBox(height: 12),
            Text('Sign in to continue',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => context.go('/login.html'),
              child: Text(context.t('nav.login')),
            ),
          ],
        ),
      ),
    );
  }
}

class _OrderRow extends StatelessWidget {
  const _OrderRow({required this.order});
  final Map<String, dynamic> order;

  @override
  Widget build(BuildContext context) {
    final id = order['id'] as String;
    final items = (order['items'] as List?)?.length ?? 0;
    final total = order['total'];
    return InkWell(
      onTap: () => context.go('/order.html?id=$id'),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
        child: Row(
          children: [
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(id, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text(
                    fmtDate(order['date']),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Expanded(child: Text('$items items', style: Theme.of(context).textTheme.bodyMedium)),
            Expanded(child: Text((order['status'] as String? ?? 'placed').toUpperCase(),
                style: Theme.of(context).textTheme.bodySmall)),
            AedPrice(value: total is num ? total : 0,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right, size: 18),
          ],
        ),
      ),
    );
  }
}
