import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../data/products.dart';
import '../i18n.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/pill_switch.dart';
import '../widgets/product_card.dart';
import '../widgets/product_slider.dart';
import '../widgets/pwt_scaffold.dart';
import '../widgets/tech_diagram.dart';
import '../widgets/water_hero.dart';

/// Landing page. Hero with audience switch, drifting water backdrop, then
/// product strip, how-it-works, sustainability, and footer. Mirrors the
/// sections in `app.jsx`.
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      child: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final audience = AppState.instance.audience;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _Hero(audience: audience),
              const _SectionSpacer(),
              _SectionHeading(
                tag: '// CATALOGUE',
                title: context.t('products.title'),
                subtitle: context.t('products.sub'),
              ),
              const SizedBox(height: 28),
              ProductStrip(items: catalogue),
              const _SectionSpacer(),
              const _HowItWorks(),
              const _SectionSpacer(),
              const TechDiagram(),
              const _SectionSpacer(),
              const _Sustainability(),
              const _SectionSpacer(),
            ],
          );
        },
      ),
    );
  }
}

class _SectionSpacer extends StatelessWidget {
  const _SectionSpacer();
  @override
  Widget build(BuildContext context) => SizedBox(
        height: MediaQuery.of(context).size.width < 640 ? 48 : 96,
      );
}

class _Hero extends StatelessWidget {
  const _Hero({required this.audience});
  final String audience;

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final w = MediaQuery.of(context).size.width;
    final isBiz = audience == 'business';
    final heroH = w < 640 ? 920.0 : 760.0;
    return Stack(
      children: [
        WaterHero(height: heroH),
        Positioned.fill(
          child: Padding(
            padding: sectionPaddingWithTop(context, 56),
            child: MaxWidth(
              child: LayoutBuilder(builder: (context, c) {
                final wide = c.maxWidth >= 960;
                final leftCol = Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AudienceSwitch(
                      value: audience,
                      onChanged: (v) => state.setAudience(v),
                    ),
                    const SizedBox(height: 24),
                    MonoTag(isBiz
                        ? context.t('hero.biz.eyebrow')
                        : context.t('hero.indiv.eyebrow')),
                    const SizedBox(height: 18),
                    DisplayHeadline(isBiz
                        ? context.t('hero.biz.title')
                        : context.t('hero.indiv.title')),
                    const SizedBox(height: 22),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 540),
                      child: Text(
                        isBiz
                            ? context.t('hero.biz.body')
                            : context.t('hero.indiv.body'),
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ),
                    const SizedBox(height: 30),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        FilledButton(
                          onPressed: () => context.go('/products.html'),
                          child: Text(isBiz
                              ? context.t('common.request_quote')
                              : context.t('common.order_now')),
                        ),
                        OutlinedButton(
                          onPressed: () => context.go('/products.html'),
                          child: Text(context.t('common.view_products')),
                        ),
                      ],
                    ),
                  ],
                );
                // Right-hand ProductSlider — the animated 3-card carousel.
                const slider = SizedBox(
                  height: 460,
                  child: ProductSlider(height: 315),
                );
                if (wide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(flex: 5, child: leftCol),
                      const SizedBox(width: 32),
                      const Expanded(flex: 5, child: slider),
                    ],
                  );
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    leftCol,
                    const SizedBox(height: 32),
                    slider,
                  ],
                );
              }),
            ),
          ),
        ),
      ],
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({required this.tag, required this.title, this.subtitle});
  final String tag;
  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: sectionHorizPaddingFor(context),
      child: MaxWidth(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MonoTag(tag),
            const SizedBox(height: 12),
            Text(title,
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.w300,
                      height: 1.08,
                    )),
            if (subtitle != null) ...[
              const SizedBox(height: 14),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Text(subtitle!, style: Theme.of(context).textTheme.bodyLarge),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _HowItWorks extends StatelessWidget {
  const _HowItWorks();

  @override
  Widget build(BuildContext context) {
    final steps = const [
      ('01', 'Source', 'Tap water — same the city sends to every building.'),
      ('02', 'Five-stage filter', 'Sediment · Carbon · RO · Boost™ · Post — sealed path, no air, no swap-outs.'),
      ('03', 'Tank + UV', 'Cold + hot tanks held below 4 °C / above 90 °C, UV-finished on dispense.'),
      ('04', 'Dispense', 'Touchless sensor, color-changing indicator, sparkling on demand.'),
      ('05', 'Service', 'We monitor filter health remotely. Our technician comes when it\'s time.'),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeading(
          tag: '// HOW IT WORKS',
          title: context.t('common.how_it_works'),
          subtitle: 'Five stages, one sealed water path, monitored end-to-end.',
        ),
        const SizedBox(height: 30),
        Padding(
          padding: sectionHorizPaddingFor(context),
          child: MaxWidth(
            child: LayoutBuilder(builder: (context, c) {
              final wide = c.maxWidth >= 1024;
              final cols = wide ? 5 : (c.maxWidth >= 640 ? 2 : 1);
              return Wrap(
                spacing: 16,
                runSpacing: 16,
                children: steps.map((s) {
                  final w = wide
                      ? (c.maxWidth - 16 * (cols - 1)) / cols
                      : (c.maxWidth - 16 * (cols - 1)) / cols;
                  return SizedBox(width: w, child: _StepCard(num: s.$1, title: s.$2, body: s.$3));
                }).toList(),
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _StepCard extends StatelessWidget {
  const _StepCard({required this.num, required this.title, required this.body});
  final String num;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(num,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w300,
                color: Theme.of(context).colorScheme.primary,
                letterSpacing: -0.02,
              )),
          const SizedBox(height: 10),
          Text(title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                  )),
          const SizedBox(height: 8),
          Text(body, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

class _Sustainability extends StatelessWidget {
  const _Sustainability();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: sectionHorizPaddingFor(context),
      child: MaxWidth(
        child: Container(
          padding: const EdgeInsets.all(40),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary.withValues(alpha: 0.14),
                Theme.of(context).colorScheme.primary.withValues(alpha: 0.02),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: LayoutBuilder(builder: (context, c) {
            final wide = c.maxWidth >= 720;
            final children = [
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const MonoTag('// SUSTAINABILITY'),
                    const SizedBox(height: 16),
                    Text(
                      'A bottle a day, gone.',
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                            fontWeight: FontWeight.w300,
                          ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'An average home with PWT eliminates around 1,200 single-use bottles per year. '
                      'A small office: 12,000+. We track it for you on your dashboard.',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 32),
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: const [
                    _Stat(value: '1,200+', label: 'bottles avoided / home / yr'),
                    SizedBox(height: 12),
                    _Stat(value: '12,000+', label: 'bottles avoided / office / yr'),
                    SizedBox(height: 12),
                    _Stat(value: '0', label: 'plastic waste shipped from our service'),
                  ],
                ),
              ),
            ];
            return wide
                ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: children)
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      children[0],
                      const SizedBox(height: 24),
                      children[2],
                    ],
                  );
          }),
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.label});
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  )),
          const SizedBox(height: 6),
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
