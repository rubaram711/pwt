import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../utils.dart';
import '../widgets/common.dart';
import '../widgets/modals.dart';
import '../widgets/pwt_scaffold.dart';

/// Profile page. Routes to either the business dashboard or the individual
/// profile based on the signed-in user's account type. Mirrors the
/// `profile.html` entry point in the React build, which made the same
/// choice inside `profile.html`.
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final user = AppState.instance.auth.user;
          if (user == null) {
            return Padding(
              padding: const EdgeInsets.all(60),
              child: Center(
                child: FilledButton(
                  onPressed: () => context.go('/login.html'),
                  child: Text(context.t('nav.login')),
                ),
              ),
            );
          }
          return Padding(
            padding: sectionPaddingFor(context),
            child: MaxWidth(
              child: user.isBusiness
                  ? const _BusinessDashboard()
                  : const _IndividualProfile(),
            ),
          );
        },
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
// Business dashboard
// ──────────────────────────────────────────────────────────────────────────

class _BusinessDashboard extends StatefulWidget {
  const _BusinessDashboard();
  @override
  State<_BusinessDashboard> createState() => _BusinessDashboardState();
}

class _BusinessDashboardState extends State<_BusinessDashboard>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final user = state.auth.user!;
    final devices = state.biz.devices;
    final maint = state.biz.maintenance;

    final activeCount = devices.where((d) => d['status'] == 'active').length;
    final needs = devices.where((d) => d['status'] == 'needs-service').length;
    final openReqs = maint.where((m) => m['status'] == 'scheduled').length;
    final avgHealth = devices.isEmpty
        ? 0
        : devices
                .map((d) => (d['filterHealth'] as num?)?.toInt() ?? 0)
                .reduce((a, b) => a + b) ~/
            devices.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        MonoTag(context.t('dash.fleet_sub')),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: DisplayHeadline(context.t('dash.fleet_title'))),
            FilledButton.icon(
              onPressed: () => context.go('/products.html'),
              icon: const Icon(Icons.add, size: 16),
              label: Text(context.t('dash.new_order')),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(user.company ?? user.name,
            style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 28),
        _statsRow(context, activeCount, needs, openReqs, avgHealth),
        const SizedBox(height: 28),
        TabBar(
          controller: _tabs,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: [
            Tab(text: context.t('dash.devices')),
            Tab(text: context.t('dash.maint')),
            Tab(text: context.t('dash.orders')),
          ],
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 600,
          child: TabBarView(
            controller: _tabs,
            children: [
              _devicesTab(context, devices),
              _maintTab(context, maint),
              _ordersTab(context),
            ],
          ),
        ),
      ],
    );
  }

  Widget _statsRow(BuildContext context, int active, int needs, int open, int health) {
    final items = [
      (context.t('dash.stat_active'), '$active', context.t('dash.all_op')),
      (context.t('dash.stat_needs'), '$needs', needs > 0 ? 'Action required' : 'OK'),
      (context.t('dash.stat_open'), '$open', 'Scheduled'),
      (context.t('dash.stat_health'), '$health%', 'Across fleet'),
    ];
    return LayoutBuilder(builder: (context, c) {
      final cols = c.maxWidth >= 880 ? 4 : (c.maxWidth >= 520 ? 2 : 1);
      const gap = 14.0;
      final cardW = (c.maxWidth - gap * (cols - 1)) / cols;
      return Wrap(
        spacing: gap, runSpacing: gap,
        children: items
            .map((it) => SizedBox(
                  width: cardW,
                  child: _StatCard(label: it.$1, value: it.$2, hint: it.$3),
                ))
            .toList(),
      );
    });
  }

  Widget _devicesTab(BuildContext context, List<Map<String, dynamic>> devices) {
    if (devices.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_devices_title'),
        subtitle: context.t('dash.empty_devices_desc'),
        icon: Icons.water_drop_outlined,
      );
    }
    return ListView.separated(
      itemCount: devices.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => _DeviceRow(device: devices[i]),
    );
  }

  Widget _maintTab(BuildContext context, List<Map<String, dynamic>> maint) {
    if (maint.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_maint_title'),
        subtitle: context.t('dash.empty_maint_desc'),
        icon: Icons.build_outlined,
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: FilledButton.tonalIcon(
            onPressed: () => showBusinessMaintenanceModal(context),
            icon: const Icon(Icons.add, size: 16),
            label: Text(context.t('dash.req_maint')),
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView.separated(
            itemCount: maint.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => _MaintRow(req: maint[i]),
          ),
        ),
      ],
    );
  }

  Widget _ordersTab(BuildContext context) {
    final orders = AppState.instance.auth.getOrders();
    if (orders.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_orders_title'),
        subtitle: context.t('dash.empty_orders_desc'),
        icon: Icons.inbox_outlined,
      );
    }
    return ListView.separated(
      itemCount: orders.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => _OrderRow(order: orders[i]),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.hint});
  final String label;
  final String value;
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MonoTag(label.toUpperCase(), size: 10),
          const SizedBox(height: 8),
          Text(value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.primary,
                  )),
          const SizedBox(height: 4),
          Text(hint, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _DeviceRow extends StatelessWidget {
  const _DeviceRow({required this.device});
  final Map<String, dynamic> device;

  @override
  Widget build(BuildContext context) {
    final health = (device['filterHealth'] as num?)?.toInt() ?? 0;
    final healthColor = health >= 70
        ? const Color(0xFF38B981)
        : health >= 35
            ? const Color(0xFFE8B842)
            : const Color(0xFFE96B5C);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: LayoutBuilder(builder: (context, c) {
        final compact = c.maxWidth < 700;
        return Row(
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.water_drop_outlined),
            ),
            const SizedBox(width: 14),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(device['model'] as String? ?? '',
                      style: Theme.of(context).textTheme.titleMedium),
                  Text(device['location'] as String? ?? '',
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
            if (!compact) ...[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MonoTag(context.t('dash.col_health'), size: 10),
                    const SizedBox(height: 4),
                    Row(children: [
                      Container(
                        width: 70, height: 6,
                        decoration: BoxDecoration(
                          color: Theme.of(context).dividerColor,
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: FractionallySizedBox(
                          alignment: AlignmentDirectional.centerStart,
                          widthFactor: (health / 100).clamp(0, 1),
                          child: Container(
                            decoration: BoxDecoration(
                              color: healthColor,
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text('$health%', style: Theme.of(context).textTheme.bodySmall),
                    ]),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MonoTag(context.t('dash.col_installed'), size: 10),
                    const SizedBox(height: 4),
                    Text(fmtDate(device['installed']),
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
            ],
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: device['status'] == 'active'
                    ? const Color(0xFF38B981).withValues(alpha: 0.2)
                    : const Color(0xFFE96B5C).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                (device['status'] as String? ?? '').toUpperCase(),
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: device['status'] == 'active'
                      ? const Color(0xFF1F8A5B)
                      : const Color(0xFFC23B2D),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _MaintRow extends StatelessWidget {
  const _MaintRow({required this.req});
  final Map<String, dynamic> req;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(req['issue'] as String? ?? '',
                    style: Theme.of(context).textTheme.titleMedium),
                Text(
                    '${req['deviceModel']} · ${req['deviceLocation']}',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          Expanded(
            child: Text(
              fmtDate(req['scheduledFor'] ?? req['scheduledDate']),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: req['status'] == 'resolved'
                  ? const Color(0xFF38B981).withValues(alpha: 0.2)
                  : Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(99),
            ),
            child: Text(
              (req['status'] as String? ?? 'scheduled').toUpperCase(),
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: req['status'] == 'resolved'
                    ? const Color(0xFF1F8A5B)
                    : Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderRow extends StatelessWidget {
  const _OrderRow({required this.order});
  final Map<String, dynamic> order;
  @override
  Widget build(BuildContext context) {
    final items = (order['items'] as List?)?.length ?? 0;
    return InkWell(
      onTap: () => context.go('/order.html?id=${order['id']}'),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Row(children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(order['id'] as String? ?? '',
                    style: Theme.of(context).textTheme.titleMedium),
                Text(fmtDate(order['date']),
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          Expanded(child: Text('$items items',
              style: Theme.of(context).textTheme.bodyMedium)),
          AedPrice(value: order['total'] is num ? order['total'] : 0,
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(width: 8),
          const Icon(Icons.chevron_right, size: 18),
        ]),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────────────
// Individual profile
// ──────────────────────────────────────────────────────────────────────────

class _IndividualProfile extends StatefulWidget {
  const _IndividualProfile();
  @override
  State<_IndividualProfile> createState() => _IndividualProfileState();
}

class _IndividualProfileState extends State<_IndividualProfile>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final user = state.auth.user!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const MonoTag('// PROFILE'),
        const SizedBox(height: 14),
        DisplayHeadline(user.name),
        const SizedBox(height: 8),
        Text(user.email, style: Theme.of(context).textTheme.bodyLarge),
        const SizedBox(height: 28),
        TabBar(
          controller: _tabs,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: [
            Tab(text: context.t('dash.devices')),
            Tab(text: context.t('dash.maint')),
            Tab(text: context.t('dash.orders')),
          ],
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 600,
          child: TabBarView(
            controller: _tabs,
            children: [
              _indivDevices(context, state.indiv.devices),
              _indivMaint(context, state.indiv.maintenance),
              _indivOrders(context, state.auth.getOrders()),
            ],
          ),
        ),
      ],
    );
  }

  Widget _indivDevices(BuildContext context, List<Map<String, dynamic>> devices) {
    if (devices.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_devices_title'),
        subtitle: context.t('dash.empty_devices_desc'),
        icon: Icons.water_drop_outlined,
      );
    }
    return ListView.separated(
      itemCount: devices.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) {
        final d = devices[i];
        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Row(children: [
            Container(
              width: 56, height: 56,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: d['img'] != null
                  ? Image.asset(d['img'] as String, fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined))
                  : const Icon(Icons.water_drop_outlined),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(d['model'] as String? ?? '',
                      style: Theme.of(context).textTheme.titleMedium),
                  Text(d['location'] as String? ?? '',
                      style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 6),
                  Text(
                    'Installed ${fmtDate(d['installed'])} · Filter ${d['filterHealth']}%',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            FilledButton.tonal(
              onPressed: () => showScheduleMaintenanceModal(context, device: d),
              child: Text(context.t('dash.schedule_maint')),
            ),
          ]),
        );
      },
    );
  }

  Widget _indivMaint(BuildContext context, List<Map<String, dynamic>> maint) {
    if (maint.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_maint_title'),
        subtitle: context.t('dash.empty_maint_desc'),
        icon: Icons.build_outlined,
      );
    }
    return ListView.separated(
      itemCount: maint.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => _MaintRow(req: maint[i]),
    );
  }

  Widget _indivOrders(BuildContext context, List<Map<String, dynamic>> orders) {
    if (orders.isEmpty) {
      return EmptyState(
        title: context.t('dash.empty_orders_title'),
        subtitle: context.t('dash.empty_orders_desc'),
        icon: Icons.inbox_outlined,
      );
    }
    return ListView.separated(
      itemCount: orders.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => _OrderRow(order: orders[i]),
    );
  }
}
