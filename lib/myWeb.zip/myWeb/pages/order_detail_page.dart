import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../utils.dart';
import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// Single order page — line items, shipping, totals, status.
class OrderDetailPage extends StatelessWidget {
  const OrderDetailPage({super.key, required this.orderId});
  final String orderId;

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: ListenableBuilder(
        listenable: AppState.instance.auth,
        builder: (context, _) {
          final user = AppState.instance.auth.user;
          if (user == null) {
            return Padding(
              padding: const EdgeInsets.all(60),
              child: Center(
                child: FilledButton(
                  onPressed: () => context.go('/login.html'),
                  child: Text(context.t('nav.login')),
                ),
              ),
            );
          }
          final orders = AppState.instance.auth.getOrders();
          final order = orders.where((o) => o['id'] == orderId).cast<Map<String, dynamic>?>().firstOrNull;
          if (order == null) {
            return Padding(
              padding: const EdgeInsets.all(60),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Order not found', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () => context.go('/orders.html'),
                      child: Text(context.t('order.back')),
                    ),
                  ],
                ),
              ),
            );
          }
          return Padding(
            padding: sectionPaddingFor(context),
            child: MaxWidth(child: _OrderDetail(order: order)),
          );
        },
      ),
    );
  }
}

class _OrderDetail extends StatelessWidget {
  const _OrderDetail({required this.order});
  final Map<String, dynamic> order;

  @override
  Widget build(BuildContext context) {
    final items = (order['items'] as List? ?? []).cast<Map<String, dynamic>>();
    final shipping = (order['shipping'] as Map?)?.cast<String, dynamic>() ?? {};
    final isRental = order['purchaseType'] == 'rental';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextButton(
          onPressed: () => context.go('/orders.html'),
          child: Text(context.t('order.back')),
        ),
        const SizedBox(height: 18),
        MonoTag('// ${context.t('order.title').toUpperCase()} · ${order['id']}'),
        const SizedBox(height: 12),
        DisplayHeadline(context.t('order.title')),
        const SizedBox(height: 28),
        LayoutBuilder(builder: (context, c) {
          final wide = c.maxWidth >= 880;
          final left = _itemList(context, items);
          final right = _summary(context, isRental, shipping);
          if (wide) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 3, child: left),
                const SizedBox(width: 28),
                Expanded(flex: 2, child: right),
              ],
            );
          }
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [left, const SizedBox(height: 24), right]);
        }),
      ],
    );
  }

  Widget _itemList(BuildContext context, List<Map<String, dynamic>> items) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MonoTag(context.t('order.line_items'), size: 11),
          const SizedBox(height: 16),
          for (var i = 0; i < items.length; i++) ...[
            Row(
              children: [
                Container(
                  width: 56, height: 56,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Theme.of(context).dividerColor),
                  ),
                  child: items[i]['img'] != null
                      ? Image.asset(items[i]['img'] as String, fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const Icon(Icons.water_drop_outlined))
                      : const Icon(Icons.water_drop_outlined),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(items[i]['name'] as String? ?? '', style: Theme.of(context).textTheme.titleMedium),
                      if (items[i]['cat'] != null)
                        Text(items[i]['cat'] as String, style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
                AedPrice(value: items[i]['price'] ?? 0),
              ],
            ),
            if (i < items.length - 1) const Divider(height: 28),
          ],
        ],
      ),
    );
  }

  Widget _summary(BuildContext context, bool isRental, Map<String, dynamic> shipping) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MonoTag(context.t('order.shipping'), size: 11),
          const SizedBox(height: 12),
          if (shipping.isNotEmpty) ...[
            Text(shipping['addr1'] as String? ?? '',
                style: Theme.of(context).textTheme.bodyMedium),
            Text(
              '${shipping['city'] ?? ''} · ${shipping['emirate'] ?? ''}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 6),
            Text(shipping['phone'] as String? ?? '',
                style: Theme.of(context).textTheme.bodySmall),
          ],
          const Divider(height: 28),
          _row(context, context.t('cart.subtotal'), order['subtotal']),
          const SizedBox(height: 6),
          _row(context, context.t('order.vat'), order['vat']),
          const SizedBox(height: 6),
          _row(context, context.t('order.shipping_fee'),
              order['shippingFee'] == 0 ? context.t('order.free') : order['shippingFee']),
          const Divider(height: 28),
          _row(context, context.t('order.total'), order['total'], emphasise: true,
              suffix: isRental ? '/ mo' : null),
          const SizedBox(height: 18),
          OutlinedButton(
            onPressed: () {},
            child: Text(context.t('order.invoice')),
          ),
        ],
      ),
    );
  }

  Widget _row(BuildContext context, String label, Object? value,
      {bool emphasise = false, String? suffix}) {
    final style = emphasise
        ? Theme.of(context).textTheme.titleLarge
        : Theme.of(context).textTheme.bodyMedium;
    return Row(
      children: [
        Text(label, style: style),
        const Spacer(),
        if (value is num)
          AedPrice(value: value, style: style, suffix: suffix)
        else
          Text(value?.toString() ?? '—', style: style),
      ],
    );
  }
}
