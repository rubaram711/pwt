import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../i18n.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/modals.dart';
import '../widgets/pwt_scaffold.dart';

/// Individual account settings page. Mirrors `account.html` + the
/// account section of `indiv-profile.jsx`. Personal details form + payment
/// methods grid.
class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  late final TextEditingController _name;
  late final TextEditingController _email;
  late final TextEditingController _phone;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    final u = AppState.instance.auth.user;
    _name = TextEditingController(text: u?.name ?? '');
    _email = TextEditingController(text: u?.email ?? '');
    _phone = TextEditingController();
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    super.dispose();
  }

  void _save() {
    setState(() => _saved = true);
    Future.delayed(const Duration(seconds: 2),
        () => mounted ? setState(() => _saved = false) : null);
  }

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'home',
      footerFull: false,
      child: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final user = AppState.instance.auth.user;
          if (user == null) {
            return Padding(
              padding: const EdgeInsets.all(60),
              child: Center(
                child: FilledButton(
                  onPressed: () => context.go('/login.html'),
                  child: Text(context.t('nav.login')),
                ),
              ),
            );
          }
          if (user.isBusiness) {
            Future.microtask(() => context.go('/profile.html'));
            return const SizedBox.shrink();
          }
          return Padding(
            padding: sectionPaddingFor(context),
            child: MaxWidth(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const MonoTag('// SETTINGS'),
                  const SizedBox(height: 18),
                  DisplayHeadline(context.t('nav.account_settings')),
                  const SizedBox(height: 36),
                  _personalDetails(context),
                  const SizedBox(height: 32),
                  _paymentsCard(context),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _personalDetails(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Text('Personal details', style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            if (_saved) MonoTag('// ${context.t('common.save').toUpperCase()}D', size: 11),
          ]),
          const SizedBox(height: 6),
          Text('Used on invoices and service tickets.',
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 20),
          LayoutBuilder(builder: (context, c) {
            final wide = c.maxWidth >= 600;
            return Wrap(
              spacing: 16, runSpacing: 16,
              children: [
                SizedBox(
                  width: wide ? (c.maxWidth - 16) / 2 : c.maxWidth,
                  child: TextFormField(
                    controller: _name,
                    decoration: const InputDecoration(labelText: 'Full name'),
                  ),
                ),
                SizedBox(
                  width: wide ? (c.maxWidth - 16) / 2 : c.maxWidth,
                  child: TextFormField(
                    controller: _email,
                    decoration: InputDecoration(labelText: context.t('login.email')),
                  ),
                ),
                SizedBox(
                  width: wide ? (c.maxWidth - 16) / 2 : c.maxWidth,
                  child: TextFormField(
                    controller: _phone,
                    decoration: const InputDecoration(labelText: 'Phone'),
                    keyboardType: TextInputType.phone,
                  ),
                ),
              ],
            );
          }),
          const SizedBox(height: 18),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilledButton(
              onPressed: _save,
              child: Text(context.t('common.save')),
            ),
          ),
        ],
      ),
    );
  }

  Widget _paymentsCard(BuildContext context) {
    final payments = AppState.instance.biz.payments;
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(context.t('payment.title'),
                  style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              OutlinedButton.icon(
                onPressed: () => showAddPaymentModal(context),
                icon: const Icon(Icons.add, size: 16),
                label: Text(context.t('payment.add')),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(context.t('payment.sub'),
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 20),
          if (payments.isEmpty)
            EmptyState(
              title: context.t('payment.empty_title'),
              subtitle: context.t('payment.empty_desc'),
              icon: Icons.credit_card_outlined,
            )
          else
            LayoutBuilder(builder: (context, c) {
              final cols = c.maxWidth >= 720 ? 2 : 1;
              const gap = 14.0;
              final cardW = (c.maxWidth - gap * (cols - 1)) / cols;
              return Wrap(
                spacing: gap, runSpacing: gap,
                children: payments
                    .map((p) => SizedBox(
                          width: cardW,
                          child: _PaymentCard(payment: p),
                        ))
                    .toList(),
              );
            }),
        ],
      ),
    );
  }
}

class _PaymentCard extends StatelessWidget {
  const _PaymentCard({required this.payment});
  final Map<String, dynamic> payment;

  @override
  Widget build(BuildContext context) {
    final isDefault = payment['isDefault'] == true;
    final brand = (payment['brand'] as String? ?? 'card').toUpperCase();
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            MonoTag(brand, size: 11),
            const SizedBox(width: 10),
            Text(
              '•••• ${payment['last4']}',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontFamily: 'GeistMono',
                    fontFamilyFallback: const ['monospace'],
                  ),
            ),
            const Spacer(),
            if (isDefault)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(context.t('payment.default'),
                    style: TextStyle(
                      fontSize: 10,
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w700,
                    )),
              ),
          ]),
          const SizedBox(height: 6),
          Text(
            'Exp ${(payment['expMonth'] as int? ?? 12).toString().padLeft(2, '0')}/${payment['expYear']} · ${payment['holder']}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 14),
          Row(children: [
            if (!isDefault)
              TextButton(
                onPressed: () =>
                    AppState.instance.biz.setDefaultPayment(payment['id'] as String),
                child: Text(context.t('payment.make_default')),
              ),
            const Spacer(),
            TextButton(
              onPressed: () =>
                  AppState.instance.biz.removePayment(payment['id'] as String),
              child: Text(context.t('payment.remove')),
            ),
          ]),
        ],
      ),
    );
  }
}
