import 'package:flutter/material.dart';

import '../i18n.dart';
import '../widgets/common.dart';
import '../widgets/pwt_scaffold.dart';

/// About page — company narrative.
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PwtScaffold(
      active: 'about',
      child: Padding(
        padding: sectionPaddingFor(context),
        child: MaxWidth(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const MonoTag('// PWT'),
              const SizedBox(height: 18),
              DisplayHeadline(context.t('about.title')),
              const SizedBox(height: 24),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Text(
                  context.t('about.lead'),
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w400,
                        height: 1.4,
                      ),
                ),
              ),
              const SizedBox(height: 36),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Text(
                  context.t('about.body'),
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
              const SizedBox(height: 64),
              LayoutBuilder(builder: (context, c) {
                final wide = c.maxWidth >= 720;
                final pillars = const [
                  _Pillar(
                    title: 'Engineered, not assembled.',
                    body:
                        'Every PWT unit is designed end-to-end — water path, filtration cartridge, control board, dispense mechanism. We do not white-label.',
                  ),
                  _Pillar(
                    title: 'Service is the product.',
                    body:
                        'Filter health is monitored remotely. Our technicians come to your floor on the day it makes sense, not on a paper calendar.',
                  ),
                  _Pillar(
                    title: 'Built for the Gulf.',
                    body:
                        'Designed in Dubai for the water, climate, and floor-plans of the GCC. Tested at 50 °C ambient and post-RO conductivity below 20 µS/cm.',
                  ),
                ];
                if (wide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (var i = 0; i < pillars.length; i++) ...[
                        Expanded(child: pillars[i]),
                        if (i < pillars.length - 1) const SizedBox(width: 24),
                      ],
                    ],
                  );
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < pillars.length; i++) ...[
                      pillars[i],
                      if (i < pillars.length - 1) const SizedBox(height: 18),
                    ],
                  ],
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _Pillar extends StatelessWidget {
  const _Pillar({required this.title, required this.body});
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                    height: 1.25,
                  )),
          const SizedBox(height: 12),
          Text(body, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
