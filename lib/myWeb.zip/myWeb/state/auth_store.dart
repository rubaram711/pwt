import 'package:flutter/foundation.dart';

import 'store.dart';

/// Mock auth — same shape and storage key as `PWTAuth` in `header.jsx`.
/// No real backend; login accepts any credentials.
class AuthUser {
  const AuthUser({
    required this.id,
    required this.email,
    required this.name,
    required this.type, // 'individual' | 'business'
    this.company,
    this.createdAt,
  });

  factory AuthUser.fromMap(Map<String, dynamic> m) => AuthUser(
        id: m['id'] as String? ?? 'u-anon',
        email: m['email'] as String? ?? 'demo@pwt.ae',
        name: m['name'] as String? ?? 'Member',
        type: m['type'] as String? ?? m['accountType'] as String? ?? 'individual',
        company: m['company'] as String?,
        createdAt: m['createdAt'] as int?,
      );

  final String id;
  final String email;
  final String name;
  final String type;
  final String? company;
  final int? createdAt;

  bool get isBusiness => type == 'business';

  Map<String, dynamic> toMap() => {
        'id': id,
        'email': email,
        'name': name,
        'type': type,
        if (company != null) 'company': company,
        if (createdAt != null) 'createdAt': createdAt,
      };
}

class AuthStore extends ChangeNotifier {
  AuthStore();

  static const _key = 'pwt-user';
  static const _ordersKey = 'pwt-orders';

  AuthUser? _user;
  AuthUser? get user => _user;
  bool get isSignedIn => _user != null;

  void load() {
    final map = Store.readJson<Map<String, dynamic>>(_key);
    if (map != null) {
      try {
        _user = AuthUser.fromMap(map);
      } catch (_) {
        _user = null;
      }
    }
  }

  Future<AuthUser> loginIndividual({
    required String email,
    String? name,
  }) async {
    final u = AuthUser(
      id: 'u-${DateTime.now().millisecondsSinceEpoch}',
      email: email,
      name: name ?? _nameFromEmail(email),
      type: 'individual',
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    _user = u;
    await Store.writeJson(_key, u.toMap());
    notifyListeners();
    return u;
  }

  Future<AuthUser> loginBusiness({
    required String email,
    required String company,
    String? name,
  }) async {
    final u = AuthUser(
      id: 'u-${DateTime.now().millisecondsSinceEpoch}',
      email: email,
      name: name ?? _nameFromEmail(email),
      type: 'business',
      company: company,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    _user = u;
    await Store.writeJson(_key, u.toMap());
    notifyListeners();
    return u;
  }

  Future<void> logout() async {
    _user = null;
    await Store.remove(_key);
    notifyListeners();
  }

  // ─── Orders ───────────────────────────────────────────────────────────

  List<Map<String, dynamic>> getOrders() {
    final raw = Store.readJson<List<dynamic>>(_ordersKey) ?? const [];
    return raw.cast<Map<String, dynamic>>();
  }

  Future<void> addOrder(Map<String, dynamic> order) async {
    final list = getOrders()..insert(0, order);
    await Store.writeJson(_ordersKey, list);
    notifyListeners();
  }

  Future<void> setOrders(List<Map<String, dynamic>> orders) async {
    await Store.writeJson(_ordersKey, orders);
    notifyListeners();
  }

  static String _nameFromEmail(String email) {
    final at = email.indexOf('@');
    final raw = at > 0 ? email.substring(0, at) : email;
    if (raw.isEmpty) return 'PWT Member';
    return raw[0].toUpperCase() + raw.substring(1);
  }
}
