import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Thin wrapper around SharedPreferences that mirrors the React build's
/// `localStorage` access pattern. Same keys (`pwt-user`, `pwt-cart`, …)
/// so a half-migrated deployment keeps sharing state.
class Store {
  Store._();

  static SharedPreferences? _prefs;
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;
    _prefs = await SharedPreferences.getInstance();
    _initialized = true;
  }

  static String? readString(String key) => _prefs?.getString(key);

  static Future<void> writeString(String key, String value) async {
    await _prefs?.setString(key, value);
  }

  static Future<void> remove(String key) async {
    await _prefs?.remove(key);
  }

  static T? readJson<T>(String key) {
    final raw = _prefs?.getString(key);
    if (raw == null || raw.isEmpty) return null;
    try {
      return jsonDecode(raw) as T?;
    } catch (_) {
      return null;
    }
  }

  static Future<void> writeJson(String key, Object value) async {
    await _prefs?.setString(key, jsonEncode(value));
  }
}
