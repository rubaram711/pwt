import 'package:flutter/foundation.dart';

import 'store.dart';

/// Cart line item. Kept as a typed value class but serialises to the same
/// JSON shape the React build uses, so the two stores are interop-compatible.
class CartItem {
  CartItem({
    required this.id,
    required this.name,
    required this.price, // num for purchase, null for "Quote"
    this.qty = 1,
    this.img,
    this.payType, // 'purchase' or 'rental'
  });

  factory CartItem.fromMap(Map<String, dynamic> m) => CartItem(
        id: m['id'] as String,
        name: m['name'] as String? ?? '',
        price: m['price'] is num ? m['price'] as num : null,
        qty: (m['qty'] as num?)?.toInt() ?? 1,
        img: m['img'] as String?,
        payType: m['payType'] as String? ?? m['type'] as String?,
      );

  final String id;
  final String name;
  final num? price;
  int qty;
  final String? img;
  final String? payType;

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        if (price != null) 'price': price,
        'qty': qty,
        if (img != null) 'img': img,
        if (payType != null) 'payType': payType,
      };

  CartItem copyWith({int? qty}) => CartItem(
        id: id,
        name: name,
        price: price,
        qty: qty ?? this.qty,
        img: img,
        payType: payType,
      );
}

class CartStore extends ChangeNotifier {
  CartStore();

  static const _key = 'pwt-cart';
  static const _typeKey = 'pwt-cart-type';

  final List<CartItem> _items = [];
  String _payType = 'purchase';

  List<CartItem> get items => List.unmodifiable(_items);
  String get payType => _payType;
  int get count =>
      _items.fold(0, (sum, item) => sum + item.qty);
  num get subtotal => _items.fold<num>(
      0,
      (sum, item) =>
          sum + (item.price ?? 0) * item.qty);
  bool get isEmpty => _items.isEmpty;

  void load() {
    final raw = Store.readJson<List<dynamic>>(_key) ?? const [];
    _items
      ..clear()
      ..addAll(raw
          .cast<Map<String, dynamic>>()
          .map(CartItem.fromMap));
    _payType = Store.readString(_typeKey) ?? 'purchase';
  }

  Future<void> _persist() async {
    await Store.writeJson(_key, _items.map((i) => i.toMap()).toList());
  }

  Future<void> add(CartItem item) async {
    final idx = _items.indexWhere((i) => i.id == item.id);
    if (idx >= 0) {
      _items[idx].qty += item.qty;
    } else {
      _items.add(item);
    }
    await _persist();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _items.removeWhere((i) => i.id == id);
    await _persist();
    notifyListeners();
  }

  Future<void> updateQty(String id, int qty) async {
    if (qty <= 0) return remove(id);
    final idx = _items.indexWhere((i) => i.id == id);
    if (idx >= 0) {
      _items[idx].qty = qty;
      await _persist();
      notifyListeners();
    }
  }

  Future<void> clear() async {
    _items.clear();
    await _persist();
    notifyListeners();
  }

  Future<void> setPayType(String type) async {
    _payType = type == 'rental' ? 'rental' : 'purchase';
    await Store.writeString(_typeKey, _payType);
    notifyListeners();
  }
}
