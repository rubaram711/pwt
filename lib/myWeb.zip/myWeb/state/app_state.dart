import 'package:flutter/material.dart';

import '../../Services/dio_service.dart';
import '../../State/product_store.dart';
import '../data/biz_data.dart';
import '../data/indiv_data.dart';
import 'auth_store.dart';
import 'cart_store.dart';
import 'store.dart';

/// Top-level state container. Pulls together the four sub-stores
/// (auth, cart, language, theme) so the root widget only listens to one
/// thing. Sub-stores are themselves ChangeNotifiers if a widget wants to
/// listen to just one.
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState instance = AppState._();

  final AuthStore auth = AuthStore();
  final CartStore cart = CartStore();
  final BizData biz = BizData();
  final IndivData indiv = IndivData();
  final ProductStore products = ProductStore();

  Future<void> initialize() async {

    await products.loadProducts();

  }

  late final DioService dioService = DioService();

  // ─── Locale (EN/AR) ──────────────────────────────────────────────────

  static const _localeKey = 'pwt-lang';
  Locale _locale = const Locale('en');
  Locale get locale => _locale;
  bool get isRtl => _locale.languageCode == 'ar';

  Future<void> setLocale(Locale locale) async {
    if (locale.languageCode == _locale.languageCode) return;
    _locale = locale;
    await Store.writeString(_localeKey, locale.languageCode);
    notifyListeners();
  }

  Future<void> toggleLocale() async {
    await setLocale(
        _locale.languageCode == 'en' ? const Locale('ar') : const Locale('en'));
  }

  // ─── Theme mode ──────────────────────────────────────────────────────

  static const _themeKey = 'pwt-theme';
  ThemeMode _themeMode = ThemeMode.dark; // matches original default
  ThemeMode get themeMode => _themeMode;
  bool get isDark => _themeMode == ThemeMode.dark;

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    final key = switch (mode) {
      ThemeMode.dark => 'dark',
      ThemeMode.light => 'light',
      ThemeMode.system => 'system',
    };
    await Store.writeString(_themeKey, key);
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    await setThemeMode(isDark ? ThemeMode.light : ThemeMode.dark);
  }

  // ─── Audience (individual / business) ────────────────────────────────

  static const _audKey = 'pwt-audience';
  String _audience = 'individual';
  String get audience => _audience;

  Future<void> setAudience(String aud) async {
    _audience = aud == 'business' ? 'business' : 'individual';
    await Store.writeString(_audKey, _audience);
    notifyListeners();
  }

  // ─── Init ────────────────────────────────────────────────────────────

  Future<void> load() async {
    await Store.init();
    // Locale.
    final l = Store.readString(_localeKey);
    if (l == 'ar' || l == 'en') _locale = Locale(l!);
    // Theme.
    final t = Store.readString(_themeKey);
    if (t == 'light') _themeMode = ThemeMode.light;
    else if (t == 'system') _themeMode = ThemeMode.system;
    else _themeMode = ThemeMode.dark;
    // Audience.
    final a = Store.readString(_audKey);
    if (a == 'individual' || a == 'business') _audience = a!;
    // Auth + cart.
    auth.load();
    cart.load();
    // Seed business + individual mock data (idempotent).
    await biz.seed(auth);
    await indiv.seed(auth, biz);
    // Re-emit whenever any sub-store changes so a single listener on
    // AppState catches everything.
    auth.addListener(notifyListeners);
    cart.addListener(notifyListeners);
    biz.addListener(notifyListeners);
    indiv.addListener(notifyListeners);
  }
}
