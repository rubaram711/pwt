/// Product catalogue — 1:1 port of `data.jsx` / `products.html` / `slider.jsx`.
/// Prices that are non-numeric (e.g. 'Quote') stay as `String`; consumers
/// must check the runtime type before formatting.

// class Product {
//   const Product({
//     required this.id,
//     required this.name,
//     required this.cat,
//     required this.tagline,//description
//     required this.price, // int OR String ('Quote')
//     required this.audience, // 'individual' | 'business' | 'both'
//     required this.tag,//code
//     this.feature = false,
//     this.weight,
//     this.dims,
//     this.cold,
//     this.hot,
//     this.voltage,
//     this.features = const [],//specs
//   });
//
//   final String id;
//   final String name;
//   final String cat;
//   final String tagline;
//   final Object price;
//   final String audience;
//   final String tag;
//   final bool feature;
//   final String? weight;
//   final String? dims;
//   final String? cold;
//   final String? hot;
//   final String? voltage;
//   final List<String> features;
// }
//
// /// Sourced from `data.jsx`.
// const products = <Product>[
//   Product(
//     id: 'pw50',
//     name: 'PW50-R',
//     cat: 'Floor-Standing · Touch',
//     tagline:
//         'Capacitive-touch activation, hot/cold dispense, activated-oxygen self-cleaning. Built for homes and small offices.',
//     price: 890,
//     audience: 'individual',
//     tag: 'PW50R // TOUCH',
//     weight: '55 lbs',
//     dims: '12.99″ W × 48.84″ H × 17.2″ L',
//     cold: '1.82 gal',
//     hot: '0.5 gal',
//     voltage: '120v/60Hz · 220v/50Hz',
//     features: [
//       'Capacitive touch sensors',
//       'Activated oxygen self-clean',
//       'Anti-microbial faceplate',
//       '24/7 system monitoring',
//     ],
//   ),
//   Product(
//     id: 'pw90ct',
//     name: 'PW90-R CT',
//     cat: 'Countertop · Touchless',
//     tagline:
//         'The countertop edition. Five full-size filters in a side-access housing. Fits under standard cabinets.',
//     price: 1490,
//     audience: 'individual',
//     tag: 'PW90CT // COUNTERTOP',
//     weight: '46.3 lb (21 kg)',
//     dims: '17.8″ H × 11.7″ W × 19.5″ D',
//     cold: '1 gal (3.8 L)',
//     hot: '0.5 gal (1.9 L)',
//     voltage: '120v/60Hz · 220v/50Hz',
//     features: [
//       'Touchless sensor activation',
//       'Color-changing dispense indicator',
//       'Side-panel filter access',
//       'Anti-microbial surfaces',
//     ],
//   ),
//   Product(
//     id: 'pw90',
//     name: 'PW90-R',
//     cat: 'Floor-Standing · Touchless · LCD',
//     tagline:
//         'The flagship. Touchless dispense, real-time LCD status, eco-mode, and a 3-gallon cold tank.',
//     price: 1890,
//     feature: true,
//     audience: 'both',
//     tag: 'PW90R // FLAGSHIP',
//     weight: '69.9 lbs (31.7 kg)',
//     dims: '14″ W × 50.9″ H × 17″ L',
//     cold: '3 gal (11 L)',
//     hot: '0.5 gal (2 L)',
//     voltage: '120v/60Hz · 220v/50Hz',
//     features: [
//       'Touchless sensor activation',
//       'Real-time LCD status',
//       'Eco-mode power save',
//       'Activated oxygen self-clean',
//     ],
//   ),
//   Product(
//     id: 's4',
//     name: 'S4',
//     cat: 'Sparkling · Touch-Free',
//     tagline:
//         'Restaurant-grade sparkling, hot, cold, and ambient. Available as countertop or freestanding.',
//     price: 'Quote',
//     audience: 'business',
//     feature: true,
//     tag: 'S4 // SPARKLING',
//     weight: '71.9 lb (CT) · 88.9 lb (FS)',
//     dims: '17.8″ H × 14.2″ W × 23.3″ D (CT)',
//     cold: '60 L/hour',
//     hot: '0.33 gal (1.25 L)',
//     voltage: '110v/60Hz · 4.9 A',
//     features: [
//       'Touch-free sensor',
//       'Sparkling + hot + cold + ambient',
//       'Removable nozzle for cleaning',
//       'Low-CO₂ indicator',
//     ],
//   ),
//   Product(
//     id: 's18uc',
//     name: 'S18 UC',
//     cat: 'Under-Counter · 3-Tap Tower',
//     tagline:
//         'Up to 180 L/h of chilled, sparkling, and ambient water. 22-lb ice bank, 3-tap chrome tower, R290 refrigerant.',
//     price: 'Quote',
//     audience: 'business',
//     tag: 'S18UC // 3-TAP',
//     weight: '20 lb (tap) · 94 lb (under-counter)',
//     dims: 'Tap 25.5″h × 5.2″w · UC 25.2″h × 18″w × 23″d',
//     cold: '180 L/hour',
//     hot: '— (cold + sparkling + ambient)',
//     voltage: '115v/60Hz · 7 A',
//     features: [
//       '3-tap chrome tower',
//       '22-lb ice bank chiller',
//       'R290 natural refrigerant',
//       'Programmable flow meter',
//     ],
//   ),
// ];

class ConfigOption {
  const ConfigOption({
    required this.id,
    required this.name,
    required this.price,
    this.sub,
  });
  final String id;
  final String name;
  final int price;
  final String? sub;
}

/// Configurator options (from `data.jsx`).
const configOptions = <String, List<ConfigOption>>{
  'finish': [
    ConfigOption(id: 'graphite', name: 'Graphite', price: 0),
    ConfigOption(id: 'pearl', name: 'Pearl White', price: 80),
    ConfigOption(id: 'aqua', name: 'Aqua', price: 120),
  ],
  'filter': [
    ConfigOption(id: 'std', name: 'Standard 4-Stage', price: 0, sub: 'Sediment + Carbon + RO + Post'),
    ConfigOption(id: 'plus', name: 'Plus + Boost™', price: 240, sub: 'Adds Boost™ remineralization'),
  ],
  'service': [
    ConfigOption(id: 'self', name: 'Self-Install', price: 0, sub: 'Ships in 3 days'),
    ConfigOption(id: 'pro', name: 'Pro Install', price: 180, sub: 'Technician on-site'),
  ],
  'sub': [
    ConfigOption(id: 'none', name: 'No Subscription', price: 0, sub: 'Filters as needed'),
    ConfigOption(id: 'auto', name: 'AutoCare', price: 24, sub: 'Filter mailers + monitoring · /mo'),
  ],
};

/// Catalogue rows shown on the public `/products` page (subset of [products]
/// plus discount metadata). Mirrors `CATALOGUE` in `products.html`.
class CatalogueItem {
  const CatalogueItem({
    required this.id,
    required this.name,
    required this.tag,
    required this.price,
    required this.img,
    required this.desc,
    this.discount,
  });
  final String id;
  final String name;
  final String tag;
  final int price;
  final String img;
  final String desc;
  final int? discount; // percent
}

const catalogue = <CatalogueItem>[
  CatalogueItem(
    id: 'pw90',
    name: 'PW90-R',
    tag: 'Floor-Standing · LCD',
    price: 1890,
    img: 'assets/products/pw90.png',
    desc: 'Flagship floor unit. Hot · ambient · cold · sparkling, with a 7-inch service display.',
  ),
  CatalogueItem(
    id: 'pw50',
    name: 'PW50-R',
    tag: 'Floor-Standing · Touch',
    price: 890,
    img: 'assets/products/pw50.png',
    desc: 'Compact floor unit. Touch dispense, sealed five-stage path.',
  ),
  CatalogueItem(
    id: 'pw90ct',
    name: 'PW90-R CT',
    tag: 'Countertop · Touchless',
    price: 1490,
    img: 'assets/products/pw90ct.png',
    desc: 'Countertop unit with touchless dispense for shared spaces.',
    discount: 15,
  ),
  CatalogueItem(
    id: 'ct',
    name: 'CT Edition',
    tag: 'Compact Countertop',
    price: 1290,
    img: 'assets/products/ct.png',
    desc: 'Minimal countertop for small kitchens. Same five-stage spec.',
  ),
  CatalogueItem(
    id: 's4',
    name: 'S4 Sparkling',
    tag: 'Floor · Sparkling',
    price: 4290,
    img: 'assets/products/s4.png',
    desc:
        'Floor-standing with on-demand sparkling. For hospitality and offices.',
    discount: 10,
  ),
];

/// Hero slider items (subset shown on the home hero) — see `slider.jsx`.
const sliderProducts = catalogue; // identical for now

/// Picks the product image given a model name string. Mirrors the
/// `modelImg` / `indivModelImg` helpers in `biz-dashboard.jsx` and
/// `indiv-profile.jsx`.
String productImg(String model) {
  final m = model.toLowerCase();
  if (m.contains('s4')) return 'assets/products/s4.png';
  if (m.contains('s18') || m.contains('uc')) return 'assets/products/s4.png';
  if (m.contains('ct') || m.contains('90-r ct')) return 'assets/products/pw90ct.png';
  if (m.contains('50')) return 'assets/products/pw50.png';
  return 'assets/products/pw90.png';
}

/// Format an AED price exactly like the original `fmtPrice` in `data.jsx`.
String fmtPrice(Object value) {
  if (value is num) return 'AED ${_thousands(value.toInt())}';
  return value.toString();
}

/// Comma-formatted integer. Locale-aware enough for this site (en-US digits).
String _thousands(int n) {
  final s = n.abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  return n < 0 ? '-${buf.toString()}' : buf.toString();
}

/// Public helper so other modules don't need to re-implement comma formatting.
String formatThousands(num value) => _thousands(value.toInt());
