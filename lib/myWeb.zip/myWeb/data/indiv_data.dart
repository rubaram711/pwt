import 'package:flutter/foundation.dart';

import '../state/auth_store.dart';
import '../state/store.dart';
import 'biz_data.dart';

/// Mock individual-profile data — devices, maintenance, payment methods.
/// 1:1 port of the `PWT_INDIV` object at the top of `indiv-profile.jsx`.
class IndivData extends ChangeNotifier {
  IndivData();

  static const _keyDevices = 'pwt-indiv-devices';
  static const _keyMaint = 'pwt-indiv-maint';
  static const _keyPaySeeded = 'pwt-indiv-payments-seeded';
  static const _seedVersionKey = 'pwt-indiv-seed-version';
  static const _seedVersion = '3';

  final List<Map<String, dynamic>> _devices = [];
  final List<Map<String, dynamic>> _maintenance = [];

  List<Map<String, dynamic>> get devices => List.unmodifiable(_devices);
  List<Map<String, dynamic>> get maintenance =>
      List.unmodifiable(_maintenance);

  Future<void> seed(AuthStore auth, BizData biz) async {
    final v = Store.readString(_seedVersionKey);
    if (v != _seedVersion) {
      await Store.remove(_keyDevices);
      await Store.remove(_keyMaint);
      await Store.writeString(_seedVersionKey, _seedVersion);
    }

    _loadFromStore();

    if (_devices.isEmpty) {
      final today = DateTime.now().millisecondsSinceEpoch;
      const day = 86400000;
      await setDevices([
        {
          'id': 'D-A01',
          'model': 'PW90-R',
          'serial': 'PW90R-25-A031',
          'location': 'Living Room',
          'purchaseType': 'rental',
          'installed': today - 92 * day,
          'filterHealth': 78,
          'monthlyRent': 280,
          'nextDueDate': today + 11 * day,
          'paymentMethodId': 'pm-indiv-1',
          'img': 'assets/products/pw90.png',
          'cat': 'Floor-Standing · Touchless',
        },
        {
          'id': 'D-A02',
          'model': 'PW50-R',
          'serial': 'PW50R-25-C014',
          'location': 'Kitchen',
          'purchaseType': 'purchased',
          'installed': today - 38 * day,
          'filterHealth': 91,
          'purchasePrice': 890,
          'warrantyEnds': today + 1100 * day,
          'img': 'assets/products/pw50.png',
          'cat': 'Floor-Standing · Touch',
        },
      ]);
    }

    if (_maintenance.isEmpty) {
      final now = DateTime.now();
      final seedDate = now.add(const Duration(days: 5));
      final isoDate =
          '${seedDate.year}-${seedDate.month.toString().padLeft(2, '0')}-${seedDate.day.toString().padLeft(2, '0')}';
      await setMaintenance([
        {
          'id': 'M-1042',
          'deviceId': 'D-A01',
          'deviceModel': 'PW90-R',
          'deviceLocation': 'Living Room',
          'requestedAt': now.millisecondsSinceEpoch - 2 * 86400000,
          'scheduledDate': isoDate,
          'scheduledSlot': '10:00 – 12:00',
          'issue': 'Annual filter replacement',
          'status': 'scheduled',
        },
      ]);
    }

    // Seed an individual's default payment method via the shared biz store.
    if (Store.readString(_keyPaySeeded) == null && biz.payments.isEmpty) {
      final holder = auth.user?.name ?? 'PWT Member';
      await biz.setPayments([
        {
          'id': 'pm-indiv-1',
          'brand': 'visa',
          'last4': '4242',
          'expMonth': 9,
          'expYear': 28,
          'holder': holder,
          'isDefault': true,
        },
      ]);
    }
    await Store.writeString(_keyPaySeeded, '1');
  }

  void _loadFromStore() {
    _devices
      ..clear()
      ..addAll((Store.readJson<List<dynamic>>(_keyDevices) ?? const [])
          .cast<Map<String, dynamic>>());
    _maintenance
      ..clear()
      ..addAll((Store.readJson<List<dynamic>>(_keyMaint) ?? const [])
          .cast<Map<String, dynamic>>());
  }

  Future<void> setDevices(List<Map<String, dynamic>> list) async {
    _devices
      ..clear()
      ..addAll(list);
    await Store.writeJson(_keyDevices, list);
    notifyListeners();
  }

  Future<void> setMaintenance(List<Map<String, dynamic>> list) async {
    _maintenance
      ..clear()
      ..addAll(list);
    await Store.writeJson(_keyMaint, list);
    notifyListeners();
  }

  Future<void> addMaintenance(Map<String, dynamic> req) async {
    await setMaintenance([req, ..._maintenance]);
  }

  Future<void> cancelMaintenance(String id) async {
    await setMaintenance(_maintenance.where((m) => m['id'] != id).toList());
  }
}
