import 'package:flutter/foundation.dart';

import '../state/auth_store.dart';
import '../state/store.dart';

/// Mock business demo data — devices, maintenance, payments. 1:1 port of
/// `biz-data.jsx`. Exposes the data as ChangeNotifier-backed lists so
/// widgets can subscribe with `ListenableBuilder`.
class BizData extends ChangeNotifier {
  BizData();

  static const _keyDevices = 'pwt-biz-devices';
  static const _keyMaint = 'pwt-biz-maintenance';
  static const _keyPayments = 'pwt-biz-payments';
  static const _keyOrdersSeeded = 'pwt-biz-orders-seeded';
  static const _seedVersionKey = 'pwt-biz-seed-version';
  static const _seedVersion = '2';

  final List<Map<String, dynamic>> _devices = [];
  final List<Map<String, dynamic>> _maintenance = [];
  final List<Map<String, dynamic>> _payments = [];

  List<Map<String, dynamic>> get devices => List.unmodifiable(_devices);
  List<Map<String, dynamic>> get maintenance => List.unmodifiable(_maintenance);
  List<Map<String, dynamic>> get payments => List.unmodifiable(_payments);

  Map<String, dynamic>? defaultPayment() {
    for (final p in _payments) {
      if (p['isDefault'] == true) return p;
    }
    return _payments.isNotEmpty ? _payments.first : null;
  }

  // ───────────────────────────────────────────────────────────────────────
  // Seed + load
  // ───────────────────────────────────────────────────────────────────────

  Future<void> seed(AuthStore auth) async {
    // Bump version → wipe old data to keep rental / purchase fields in sync.
    final v = Store.readString(_seedVersionKey);
    if (v != _seedVersion) {
      await Store.remove(_keyDevices);
      await Store.remove(_keyMaint);
      await Store.remove(_keyPayments);
      await Store.remove(_keyOrdersSeeded);
      await Store.writeString(_seedVersionKey, _seedVersion);
    }

    _loadFromStore();

    if (_devices.isEmpty) {
      final today = DateTime.now().millisecondsSinceEpoch;
      const day = 86400000;
      await setDevices([
        _dev('D-001', 'PW90-R', 'PW90R-24-A031', 'HQ · Reception, Floor 1',
            installed: today - 220 * day, filterHealth: 78, lastService: today - 38 * day,
            status: 'active', purchaseType: 'rental', monthlyRent: 280,
            nextDueDate: today + 12 * day, paymentMethodId: 'pm-1'),
        _dev('D-002', 'PW90-R', 'PW90R-24-A044', 'HQ · Break Room, Floor 2',
            installed: today - 220 * day, filterHealth: 62, lastService: today - 50 * day,
            status: 'active', purchaseType: 'rental', monthlyRent: 280,
            nextDueDate: today + 12 * day, paymentMethodId: 'pm-1'),
        _dev('D-003', 'PW90-R CT', 'PW90CT-25-B012', 'HQ · Boardroom, Floor 3',
            installed: today - 90 * day, filterHealth: 92, lastService: today - 28 * day,
            status: 'active', purchaseType: 'rental', monthlyRent: 220,
            nextDueDate: today + 18 * day, paymentMethodId: 'pm-1'),
        _dev('D-004', 'PW50-R', 'PW50R-23-C007', 'Annex · Pantry',
            installed: today - 410 * day, filterHealth: 22, lastService: today - 110 * day,
            status: 'needs-service', purchaseType: 'purchased',
            purchasePrice: 890, warrantyEnds: today + 320 * day),
        _dev('D-005', 'S18 UC', 'S18UC-25-D101', 'HQ · Cafeteria',
            installed: today - 60 * day, filterHealth: 95, lastService: today - 18 * day,
            status: 'active', purchaseType: 'rental', monthlyRent: 540,
            nextDueDate: today + 6 * day, paymentMethodId: 'pm-2'),
        _dev('D-006', 'S4 Sparkling', 'S4-25-E055', 'HQ · Executive Lounge',
            installed: today - 120 * day, filterHealth: 84, lastService: today - 32 * day,
            status: 'active', purchaseType: 'purchased',
            purchasePrice: 4290, warrantyEnds: today + 600 * day),
        _dev('D-007', 'PW90-R', 'PW90R-24-A088', 'Branch Office · Lobby',
            installed: today - 180 * day, filterHealth: 45, lastService: today - 72 * day,
            status: 'active', purchaseType: 'rental', monthlyRent: 280,
            nextDueDate: today + 12 * day, paymentMethodId: 'pm-1'),
        _dev('D-008', 'CT Edition', 'CT-25-F022', 'Showroom · Front',
            installed: today - 40 * day, filterHealth: 98, lastService: today - 8 * day,
            status: 'active', purchaseType: 'purchased',
            purchasePrice: 1290, warrantyEnds: today + 700 * day),
      ]);
    }

    if (_maintenance.isEmpty) {
      final today = DateTime.now().millisecondsSinceEpoch;
      const day = 86400000;
      await setMaintenance([
        {
          'id': 'M-2042',
          'deviceId': 'D-004',
          'deviceModel': 'PW50-R',
          'deviceLocation': 'Annex · Pantry',
          'issue': 'Filter past life',
          'description': 'Filter health is below 25%, unit needs scheduled service.',
          'requestedAt': today - 6 * day,
          'status': 'scheduled',
          'scheduledFor': today + 2 * day,
          'technician': 'Hassan A.',
        },
        {
          'id': 'M-2038',
          'deviceId': 'D-002',
          'deviceModel': 'PW90-R',
          'deviceLocation': 'HQ · Break Room, Floor 2',
          'issue': 'Slow dispense',
          'description': 'Cold output is slower than usual since last week.',
          'requestedAt': today - 14 * day,
          'status': 'resolved',
          'scheduledFor': today - 10 * day,
          'technician': 'Yara K.',
        },
      ]);
    }

    if (_payments.isEmpty) {
      await setPayments([
        {
          'id': 'pm-1', 'brand': 'visa', 'last4': '4242',
          'expMonth': 12, 'expYear': 28, 'holder': 'Acme Holdings', 'isDefault': true,
        },
        {
          'id': 'pm-2', 'brand': 'mastercard', 'last4': '8821',
          'expMonth': 6, 'expYear': 27, 'holder': 'Acme Holdings', 'isDefault': false,
        },
      ]);
    }

    // Seed sample orders for business users so the dashboard isn't empty.
    final user = auth.user;
    if (user != null &&
        user.isBusiness &&
        Store.readString(_keyOrdersSeeded) == null &&
        auth.getOrders().isEmpty) {
      final today = DateTime.now().millisecondsSinceEpoch;
      const day = 86400000;
      await auth.addOrder({
        'id': 'PWT-${(today - 60 * day).toRadixString(36)}',
        'date': DateTime.fromMillisecondsSinceEpoch(today - 90 * day).toIso8601String(),
        'purchaseType': 'rental',
        'items': [
          {
            'id': 'pw90', 'name': 'PW90-R', 'cat': 'Floor-Standing · LCD',
            'price': 280, 'img': 'assets/products/pw90.png',
            'purchaseType': 'rental', 'monthlyRent': 280,
          },
          {
            'id': 'pw90', 'name': 'PW90-R', 'cat': 'Floor-Standing · LCD',
            'price': 280, 'img': 'assets/products/pw90.png',
            'purchaseType': 'rental', 'monthlyRent': 280,
          },
          {
            'id': 'pw90ct', 'name': 'PW90-R CT', 'cat': 'Countertop · Touchless',
            'price': 220, 'img': 'assets/products/pw90ct.png',
            'purchaseType': 'rental', 'monthlyRent': 220,
          },
        ],
        'shipping': {
          'addr1': 'Office Tower, Sheikh Zayed Rd', 'city': 'Dubai',
          'emirate': 'Dubai', 'phone': '+971 4 400 0000',
        },
        'subtotal': 780, 'vat': 39, 'shippingFee': 0, 'total': 819,
        'status': 'delivered', 'paymentMethodId': 'pm-1',
        'monthlyTotal': 780, 'nextDueDate': today + 12 * day,
      });
      await auth.addOrder({
        'id': 'PWT-${(today - 220 * day).toRadixString(36)}',
        'date': DateTime.fromMillisecondsSinceEpoch(today - 220 * day).toIso8601String(),
        'purchaseType': 'purchase',
        'items': [
          {
            'id': 'pw50', 'name': 'PW50-R', 'cat': 'Floor-Standing · Touch',
            'price': 890, 'img': 'assets/products/pw50.png',
            'purchaseType': 'purchased',
          },
          {
            'id': 's4', 'name': 'S4 Sparkling', 'cat': 'Floor · Sparkling',
            'price': 4290, 'img': 'assets/products/s4.png',
            'purchaseType': 'purchased',
          },
        ],
        'shipping': {
          'addr1': 'Annex Building 2', 'city': 'Dubai',
          'emirate': 'Dubai', 'phone': '+971 4 400 0000',
        },
        'subtotal': 5180, 'vat': 259, 'shippingFee': 0, 'total': 5439,
        'status': 'delivered', 'paymentMethodId': 'pm-2',
      });
      await Store.writeString(_keyOrdersSeeded, '1');
    }
  }

  void _loadFromStore() {
    _devices
      ..clear()
      ..addAll((Store.readJson<List<dynamic>>(_keyDevices) ?? const [])
          .cast<Map<String, dynamic>>());
    _maintenance
      ..clear()
      ..addAll((Store.readJson<List<dynamic>>(_keyMaint) ?? const [])
          .cast<Map<String, dynamic>>());
    _payments
      ..clear()
      ..addAll((Store.readJson<List<dynamic>>(_keyPayments) ?? const [])
          .cast<Map<String, dynamic>>());
  }

  // ───────────────────────────────────────────────────────────────────────
  // Mutations
  // ───────────────────────────────────────────────────────────────────────

  Future<void> setDevices(List<Map<String, dynamic>> list) async {
    _devices
      ..clear()
      ..addAll(list);
    await Store.writeJson(_keyDevices, list);
    notifyListeners();
  }

  Future<void> setMaintenance(List<Map<String, dynamic>> list) async {
    _maintenance
      ..clear()
      ..addAll(list);
    await Store.writeJson(_keyMaint, list);
    notifyListeners();
  }

  Future<void> addMaintenance(Map<String, dynamic> req) async {
    final next = [req, ..._maintenance];
    await setMaintenance(next);
  }

  Future<void> setPayments(List<Map<String, dynamic>> list) async {
    _payments
      ..clear()
      ..addAll(list);
    await Store.writeJson(_keyPayments, list);
    notifyListeners();
  }

  Future<void> addPayment(Map<String, dynamic> p) async {
    final list = [..._payments];
    if (p['isDefault'] == true) {
      for (var i = 0; i < list.length; i++) {
        list[i] = {...list[i], 'isDefault': false};
      }
    }
    list.add(p);
    await setPayments(list);
  }

  Future<void> removePayment(String id) async {
    final list = _payments.where((p) => p['id'] != id).toList();
    if (list.isNotEmpty && !list.any((p) => p['isDefault'] == true)) {
      list[0] = {...list[0], 'isDefault': true};
    }
    await setPayments(list);
  }

  Future<void> setDefaultPayment(String id) async {
    final list = _payments
        .map((p) => {...p, 'isDefault': p['id'] == id})
        .toList();
    await setPayments(list);
  }

  // Tiny helper for the seed data above.
  Map<String, dynamic> _dev(
    String id,
    String model,
    String serial,
    String location, {
    required int installed,
    required int filterHealth,
    required int lastService,
    required String status,
    required String purchaseType,
    int? monthlyRent,
    int? nextDueDate,
    String? paymentMethodId,
    int? purchasePrice,
    int? warrantyEnds,
  }) =>
      {
        'id': id,
        'model': model,
        'serial': serial,
        'location': location,
        'installed': installed,
        'filterHealth': filterHealth,
        'lastService': lastService,
        'status': status,
        'purchaseType': purchaseType,
        if (monthlyRent != null) 'monthlyRent': monthlyRent,
        if (nextDueDate != null) 'nextDueDate': nextDueDate,
        if (paymentMethodId != null) 'paymentMethodId': paymentMethodId,
        if (purchasePrice != null) 'purchasePrice': purchasePrice,
        if (warrantyEnds != null) 'warrantyEnds': warrantyEnds,
      };
}
